# -*- coding: utf-8 -*-
# 파일 이름: src/active_mode.py
# 역할: '일반 모드'의 모든 핵심 로직을 담당하는 최종 엔진.

import pyautogui
import time
import os
import sys
import cv2
import numpy as np
import random
import gc
import win32api
import win32gui
import win32print
import win32con

# 공통 유틸리티 (중복 코드 통합)
from utils.screenshot_utils import screenshot_pywin32, imread_korean_path

# 편리모드 (모니터 밖 이동 방식)
try:
    from utils.virtual_desktop import (
        capture_window, click_in_virtual_desktop,
        get_convenience_mode, is_available as vd_available
    )
    CONVENIENCE_MODE_AVAILABLE = vd_available()
except ImportError:
    CONVENIENCE_MODE_AVAILABLE = False
    def capture_window(hwnd, output_format='cv2'): return None
    def click_in_virtual_desktop(hwnd, x, y, method='post_message'): return False
    def get_convenience_mode(): return None

# AI 퀴즈 풀이 모듈 (분리됨)
from quiz_solver import solve_quiz_with_ai, is_ai_available

# 이미지 매칭 함수
from web_login import find_image_gray

# 로거 임포트
try:
    from logger import log_info, log_error, log_debug, log_warning
except ImportError:
    # 로거 없으면 print로 대체
    def log_info(msg): print(f"[INFO] {msg}")
    def log_error(msg, exc_info=False): print(f"[ERROR] {msg}")
    def log_debug(msg): print(f"[DEBUG] {msg}")
    def log_warning(msg): print(f"[WARN] {msg}")


def _is_compiled():
    """Nuitka 또는 PyInstaller 빌드 여부"""
    return getattr(sys, 'frozen', False) or "__compiled__" in globals()

def get_base_path():
    """Nuitka/PyInstaller exe 빌드와 일반 Python 실행 모두 지원하는 기본 경로 반환"""
    if _is_compiled():
        return os.path.dirname(sys.executable)
    else:
        # 일반 Python 스크립트 실행 시 (src 폴더의 상위 = 프로젝트 루트)
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# --- 설정 ---
TARGET_WINDOW_TITLE = "강의실"
# ref 폴더 경로: exe 빌드 시에도 정상 작동
REF_FOLDER = os.path.join(get_base_path(), 'ref')
SUPPORTED_SCALES = [100, 125, 150]
CONFIDENCE_THRESHOLD = 0.8
CONFIDENCE_THRESHOLD_TEXT = 0.65  # 텍스트 이미지용 (1.png, limit.png 등)
IMAGE_FILES = ['1.png', '2.png', '3.png', '4.png', '5.png', '7.png', '8.png', '9.png', 'limit.png', 'complete.png']

# --- 메모리 최적화: 템플릿 이미지 캐시 ---
_template_cache = {}
GC_INTERVAL = 50  # 가비지 컬렉션 주기 (루프 횟수)


def get_cached_template(filepath):
    """템플릿 이미지를 캐시에서 가져오거나 로드하여 캐시에 저장"""
    if filepath not in _template_cache:
        if os.path.exists(filepath):
            _template_cache[filepath] = imread_korean_path(filepath)
        else:
            _template_cache[filepath] = None
    return _template_cache[filepath]


def clear_template_cache():
    """템플릿 캐시 초기화 (배율 변경 시 등)"""
    global _template_cache
    _template_cache.clear()
    gc.collect()

# --- 핵심 기능 함수들 ---

def get_display_scaling(point=None, logging_queue=None):
    """pywin32를 사용하여 주어진 좌표가 속한 모니터의 배율을 감지합니다.

    Args:
        point: 모니터 좌표 (기본값: (0, 0))
        logging_queue: 로그 큐 (경고 메시지 전송용)

    Returns:
        tuple: (배율, 성공여부) - 예: (125, True) 또는 (100, False)
    """
    try:
        if point is None: point = (0, 0)
        hMonitor = win32api.MonitorFromPoint(point, win32con.MONITOR_DEFAULTTONEAREST)
        monitor_info = win32api.GetMonitorInfo(hMonitor)
        hDC = win32gui.CreateDC(monitor_info['Device'], None, None)
        dpi_x = win32print.GetDeviceCaps(hDC, win32con.LOGPIXELSX)
        win32gui.DeleteDC(hDC)
        scale = int(float(dpi_x) / 96 * 100)
        return (scale, True)
    except Exception as e:
        log_warning(f"화면 배율 감지 중 오류: {e}. 기본값 100으로 설정.")
        if logging_queue:
            logging_queue.put(f"[경고] 화면 배율 감지 실패. 100%로 가정합니다.")
        return (100, False)

def find_image_in_haystack(target_image_filename, scale_folder, haystack_img, search_region):
    """(수정됨) 전체 스크린샷에서 이미지를 찾고, 그 위치가 search_region 안에 있는지 확인합니다."""
    needle_path = os.path.join(REF_FOLDER, str(scale_folder), target_image_filename)

    try:
        # 캐시에서 템플릿 이미지 가져오기 (메모리 최적화)
        needle_img = get_cached_template(needle_path)

        # 해당 배율에 이미지 없으면 100%에서 로드 후 스케일링
        if needle_img is None and scale_folder != 100:
            base_path = os.path.join(REF_FOLDER, '100', target_image_filename)
            base_img = get_cached_template(base_path)
            if base_img is not None:
                # 100% 이미지를 현재 배율로 스케일링
                scale_ratio = scale_folder / 100.0
                new_w = int(base_img.shape[1] * scale_ratio)
                new_h = int(base_img.shape[0] * scale_ratio)
                needle_img = cv2.resize(base_img, (new_w, new_h), interpolation=cv2.INTER_LANCZOS4)
                # 스케일링된 이미지도 캐시에 저장
                _template_cache[needle_path] = needle_img

        if needle_img is None:
            return None

        # 1. 전체 스크린샷(haystack_img)에서 이미지 검색
        result = cv2.matchTemplate(haystack_img, needle_img, cv2.TM_CCOEFF_NORMED)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)

        # 결과 매트릭스 명시적 해제
        del result

        # 텍스트 이미지(1.png, limit.png, complete.png)는 낮은 임계값 적용
        threshold = CONFIDENCE_THRESHOLD_TEXT if target_image_filename in ['1.png', 'limit.png', 'complete.png'] else CONFIDENCE_THRESHOLD

        if max_val >= threshold:
            # 2. 이미지를 찾았다면, 그 중심 좌표를 계산합니다.
            needle_w, needle_h = needle_img.shape[1], needle_img.shape[0]
            found_x = max_loc[0] + needle_w / 2
            found_y = max_loc[1] + needle_h / 2

            # 3. (핵심) 그 중심 좌표가 '강의실' 창 영역(search_region) 안에 있는지 확인합니다.
            region_x, region_y, region_w, region_h = search_region
            if (region_x < found_x < region_x + region_w) and \
               (region_y < found_y < region_y + region_h):

                print(f" (콘솔로그: {scale_folder}% '{target_image_filename}' 찾음, 유사도 {max_val:.2f}) ", end='')
                # 최종 위치 정보 반환
                return (max_loc[0], max_loc[1], needle_w, needle_h)
            else:
                # 찾았지만, '강의실' 창 밖에 있으므로 무시
                return None

    except Exception as e:
        print(f"  (콘솔로그: '{target_image_filename}' 탐색 중 오류 - {e})")
        return None
    return None


def find_text_start_x(haystack_img, y_coord, start_x, end_x, brightness_threshold=200):
    """해당 Y좌표 행에서 텍스트(어두운 픽셀)가 시작되는 X좌표 찾기

    Args:
        haystack_img: OpenCV 이미지 (BGR 형식)
        y_coord: 스캔할 Y좌표
        start_x: 스캔 시작 X좌표
        end_x: 스캔 종료 X좌표
        brightness_threshold: 이 값보다 어두우면 텍스트로 판단 (기본 200)

    Returns:
        텍스트 시작 X좌표, 못 찾으면 None
    """
    try:
        # 이미지 범위 체크
        img_height, img_width = haystack_img.shape[:2]
        if y_coord < 0 or y_coord >= img_height:
            return None

        start_x = max(0, start_x)
        end_x = min(img_width, end_x)

        for x in range(start_x, end_x):
            pixel = haystack_img[y_coord, x]  # BGR 형식
            b, g, r = int(pixel[0]), int(pixel[1]), int(pixel[2])

            # 밝기 계산 (R, G, B 평균)
            brightness = (r + g + b) / 3

            # 밝기가 threshold보다 낮으면 텍스트(어두운 픽셀)로 판단
            if brightness < brightness_threshold:
                return x

        return None
    except Exception as e:
        print(f"  (콘솔로그: 텍스트 시작 위치 탐색 오류 - {e})")
        return None


def perform_human_click(location, click_message, logging_queue, hwnd=None):
    """UI에 상태를 알리고, 실제 클릭을 수행합니다.

    Args:
        location: (x, y, w, h) 튜플
        click_message: UI에 표시할 메시지
        logging_queue: 로그 큐
        hwnd: 편리모드에서 사용할 창 핸들 (옵션)
    """
    ui_message = f"자동화 작업 수행중입니다. ({click_message})"
    logging_queue.put(ui_message)

    print(f"\n[콘솔로그] -> '{click_message}'에 해당하는 동작 수행.")
    center = pyautogui.center(location)

    # 편리모드 확인 - 창 위치로 판단 (화면 밖에 있으면 편리모드)
    is_convenience_active = False
    if hwnd and CONVENIENCE_MODE_AVAILABLE:
        try:
            window_rect = win32gui.GetWindowRect(hwnd)
            is_convenience_active = window_rect[1] < -2000
        except:
            convenience_mode = get_convenience_mode()
            is_convenience_active = convenience_mode and convenience_mode.is_active

    if is_convenience_active:
        # 편리모드: 가상 데스크톱에서 클릭
        print("  (콘솔로그: 편리모드 - 가상 데스크톱 클릭)")
        click_in_virtual_desktop(hwnd, center.x, center.y, method='move_window')
    else:
        # 일반 모드: 기존 방식
        original_position = pyautogui.position()
        pyautogui.moveTo(center)
        pyautogui.mouseDown()
        time.sleep(random.uniform(0.05, 0.15))
        pyautogui.mouseUp()
        pyautogui.moveTo(original_position)

    delay_options = [(0.5, 2.0), (1.0, 4.0), (2.0, 5.0), (0.0, 6.0)]
    weights = [50, 30, 10, 10]
    chosen_range = random.choices(delay_options, weights=weights, k=1)[0]
    random_delay = random.uniform(chosen_range[0], chosen_range[1])
    print(f"  (콘솔로그: 클릭 후 {random_delay:.2f}초 대기)")
    time.sleep(random_delay)


def start_active_mode_loop(logging_queue, stop_event, result_dict=None):
    """안정성을 최우선으로, 전체 화면 탐색 후 위치를 검증하는 최종 로직.

    Args:
        logging_queue: 로그 큐
        stop_event: 중지 이벤트
        result_dict: 결과 딕셔너리 (exit_reason 저장용, 옵션)
    """
    log_info("=== 자동화 루프 시작 ===")
    logging_queue.put("엔진 준비 완료. [F9] 또는 시작 버튼을 누르세요.")

    CLICK_MESSAGES = {
        '2.png': '퀴즈 버튼 클릭', '3.png': '확인버튼 클릭',
        '4.png': '다음 클릭', '5.png': '재생 클릭'
    }

    loop_count = 0
    prev_scale = None  # 이전 배율 기억 (캐시 무효화용)
    consecutive_no_match = 0  # 연속 매칭 실패 횟수
    last_status_update = 0  # 마지막 상태 업데이트 시간
    window_search_start = None  # 창 검색 시작 시간
    scale_warning_shown = False  # 배율 경고 중복 방지
    last_playing_time = time.time()  # 7.png(재생중)이 마지막으로 검출된 시간

    while not stop_event.is_set():
        loop_count += 1

        # 주기적 가비지 컬렉션 (메모리 최적화)
        if loop_count % GC_INTERVAL == 0:
            gc.collect()
            log_debug(f"[루프 {loop_count}] 가비지 컬렉션 실행")

        try:
            target_windows = pyautogui.getWindowsWithTitle(TARGET_WINDOW_TITLE)
            if not target_windows:
                # 창 검색 타임아웃 추적
                if window_search_start is None:
                    window_search_start = time.time()
                else:
                    elapsed = time.time() - window_search_start
                    if elapsed >= 30 and int(elapsed) % 30 == 0:  # 30초마다 경고
                        logging_queue.put(f"[주의] '{TARGET_WINDOW_TITLE}' 창을 {int(elapsed)}초째 찾지 못하고 있습니다. 창이 열려있는지 확인해주세요.")
                        log_warning(f"창 검색 {int(elapsed)}초 경과")

                logging_queue.put(f"'{TARGET_WINDOW_TITLE}' 창을 찾는 중...")
                log_debug(f"[루프 {loop_count}] 대상 창 미발견")
                time.sleep(1)
                continue

            # 창 발견 시 타임아웃 리셋
            window_search_start = None

            logging_queue.put("자동화 작업 수행중입니다.")
            target_window = target_windows[0]
            target_hwnd = target_window._hWnd  # 창 핸들 저장

            current_scale, scale_success = get_display_scaling(target_window.center, logging_queue)

            # 배율 감지 실패 시 한 번만 경고
            if not scale_success and not scale_warning_shown:
                logging_queue.put(f"[경고] 화면 배율 자동 감지 실패. ref/{current_scale}/ 폴더의 이미지를 사용합니다.")
                scale_warning_shown = True
            elif scale_success:
                scale_warning_shown = False  # 배율 감지 성공 시 리셋

            # 배율이 변경되면 템플릿 캐시 초기화
            if prev_scale is not None and prev_scale != current_scale:
                log_info(f"배율 변경 감지 ({prev_scale}% → {current_scale}%), 캐시 초기화")
                clear_template_cache()
            prev_scale = current_scale

            search_region = (target_window.left, target_window.top, target_window.width, target_window.height)
            log_debug(f"[루프 {loop_count}] 창 발견: {search_region}, 배율: {current_scale}%")

            print(f"\n화면 탐색 중...", end='')

            # 편리모드 확인 - 창 위치로 판단 (화면 밖에 있으면 편리모드)
            convenience_mode = get_convenience_mode() if CONVENIENCE_MODE_AVAILABLE else None
            try:
                window_rect = win32gui.GetWindowRect(target_hwnd)
                # 창이 화면 밖(Y < -2000)에 있으면 편리모드
                is_convenience_active = window_rect[1] < -2000
                if is_convenience_active:
                    log_debug(f"[루프 {loop_count}] 편리모드 감지 (창 위치: Y={window_rect[1]})")
            except:
                is_convenience_active = convenience_mode and convenience_mode.is_active

            # 창 위치 저장 (좌표 변환용)
            window_offset_x = target_window.left
            window_offset_y = target_window.top

            if is_convenience_active:
                # 편리모드: 창 직접 캡처 (PrintWindow API)
                haystack_img = capture_window(target_hwnd, output_format='cv2')
                if haystack_img is None:
                    log_warning(f"[루프 {loop_count}] 편리모드 창 캡처 실패")
                    time.sleep(1)
                    continue
                # 편리모드에서 search_region은 창 기준 (0,0부터)
                capture_search_region = (0, 0, target_window.width, target_window.height)
            else:
                # 일반 모드: 전체 화면 캡처
                haystack_img = screenshot_pywin32(output_format='cv2')
                capture_search_region = search_region

            locations = {img: find_image_in_haystack(img, current_scale, haystack_img, capture_search_region) for img in IMAGE_FILES}

            # 편리모드: 창 기준 좌표를 화면 좌표로 변환
            if is_convenience_active:
                for img_name, loc in locations.items():
                    if loc:
                        x, y, w, h = loc
                        # 화면 좌표로 변환 (창 위치 + 상대 좌표)
                        locations[img_name] = (x + window_offset_x, y + window_offset_y, w, h)

            # 스크린샷 메모리 해제
            del haystack_img

            print(" -> 탐색 완료.", end='')

            # 발견된 이미지 로깅
            found_images = [img for img, loc in locations.items() if loc]
            if found_images:
                log_debug(f"[루프 {loop_count}] 발견된 이미지: {found_images}")

            # 7.png(재생중) 검출 시 시간 업데이트
            if locations.get('7.png'):
                last_playing_time = time.time()

            # 조건부 로직
            # [최우선] 일일 한도(15차시) 감지 → 자동화 중지
            if locations.get('limit.png'):
                log_info(f"[루프 {loop_count}] 일일 한도(15차시) 도달 감지!")
                logging_queue.put("[완료] 오늘 연수 15차시를 모두 수강했습니다.")
                # 확인 버튼 클릭
                if locations.get('3.png'):
                    perform_human_click(locations['3.png'], '확인버튼 클릭 (한도 도달)', logging_queue, target_hwnd)
                logging_queue.put("자동화를 종료합니다. 내일 다시 시작해주세요.")
                logging_queue.put("@@AUTO_STOP@@")
                logging_queue.put("@@MSG_한도도달@@")  # GUI에서 메시지박스 표시
                # result_dict에 종료 원인 저장 (full_automation 연동용)
                if result_dict is not None:
                    result_dict['exit_reason'] = 'limit'
                stop_event.set()
                break

            # [우선] 강의 종료(마지막 목차) 감지 → 자동화 중지
            elif locations.get('complete.png'):
                log_info(f"[루프 {loop_count}] 강의 종료(마지막 목차) 감지!")
                logging_queue.put("[완료] 현재 강의의 마지막 목차입니다.")
                # 확인 버튼 클릭
                if locations.get('3.png'):
                    perform_human_click(locations['3.png'], '확인버튼 클릭 (강의 완료)', logging_queue, target_hwnd)
                logging_queue.put("이 강의가 완료되었습니다. 자동화를 종료합니다.")
                logging_queue.put("@@AUTO_STOP@@")
                logging_queue.put("@@MSG_강의완료@@")  # GUI에서 메시지박스 표시
                # result_dict에 종료 원인 저장 (full_automation 연동용)
                if result_dict is not None:
                    result_dict['exit_reason'] = 'complete'
                stop_event.set()
                break

            elif locations['1.png'] and locations['4.png'] and locations['5.png']:
                log_info(f"[루프 {loop_count}] 조건: 1+4+5 → 다음 클릭")
                perform_human_click(locations['4.png'], CLICK_MESSAGES['4.png'], logging_queue, target_hwnd)
                consecutive_no_match = 0  # 성공 시 리셋
            elif locations['2.png']:
                # 퀴즈 버튼 클릭만 수행 (문제 풀이는 퀴즈 풀이 탭에서 수동 실행)
                log_info(f"[루프 {loop_count}] 퀴즈 버튼 발견 → 클릭")
                perform_human_click(locations['2.png'], CLICK_MESSAGES['2.png'], logging_queue, target_hwnd)
                consecutive_no_match = 0
            elif locations['3.png']:
                log_info(f"[루프 {loop_count}] 확인 버튼 발견 → 클릭")
                perform_human_click(locations['3.png'], CLICK_MESSAGES['3.png'], logging_queue, target_hwnd)
                consecutive_no_match = 0  # 성공 시 리셋
            elif locations['4.png'] and locations['5.png'] and not locations['1.png']:
                log_debug(f"[루프 {loop_count}] 1.png 없음, 4+5 있음 → 재확인")
                print("\n  (콘솔로그: 1.png 없음, 4 & 5.png 있음. 0.5초 후 재확인...)")
                time.sleep(0.5)

                haystack_2nd = screenshot_pywin32(output_format='cv2')
                location_1_reread = find_image_in_haystack('1.png', current_scale, haystack_2nd, search_region)

                # 두 번째 스크린샷 메모리 해제
                del haystack_2nd

                if location_1_reread:
                    log_info(f"[루프 {loop_count}] 1.png 뒤늦게 발견 → 다음 클릭")
                    print("  (콘솔로그: 1.png가 뒤늦게 발견! -> '다음'을 클릭합니다.)")
                    if locations['4.png']: perform_human_click(locations['4.png'], CLICK_MESSAGES['4.png'], logging_queue, target_hwnd)
                    consecutive_no_match = 0  # 성공 시 리셋
                else:
                    log_info(f"[루프 {loop_count}] 1.png 여전히 없음 → 재생 클릭")
                    print("  (콘솔로그: 1.png 여전히 없음. -> '재생'을 클릭합니다.)")
                    perform_human_click(locations['5.png'], CLICK_MESSAGES['5.png'], logging_queue, target_hwnd)
                    consecutive_no_match = 0  # 성공 시 리셋
            elif locations['5.png'] and not locations['1.png']:
                log_info(f"[루프 {loop_count}] 재생 버튼만 발견 → 클릭")
                perform_human_click(locations['5.png'], CLICK_MESSAGES['5.png'], logging_queue, target_hwnd)
                consecutive_no_match = 0
            # [수정] 다음 차시 자동 클릭: 8.png(학습완료) 발견 시 바로 아래 9.png(학습전) 찾아서 클릭
            elif locations.get('8.png'):
                import random
                x8, y8, w8, h8 = locations['8.png']

                # 8.png 바로 아래에 9.png가 있는지 확인
                nine_location = locations.get('9.png')
                nine_below_eight = False

                if nine_location:
                    x9, y9, w9, h9 = nine_location
                    # 9.png가 8.png 아래에 있는지 확인 (Y좌표 차이가 적당한 범위)
                    y_diff = y9 - (y8 + h8)
                    if 0 <= y_diff <= 150:  # 8.png 바로 아래 150px 이내
                        nine_below_eight = True
                        log_debug(f"[루프 {loop_count}] 8.png 아래에 9.png 발견 (Y차이: {y_diff}px)")

                if not nine_below_eight:
                    # 9.png가 바로 아래에 없음 → 페이지다운 후 다시 스캔
                    log_debug(f"[루프 {loop_count}] 8.png 아래에 9.png 없음 → 페이지다운")
                    pyautogui.press('pagedown')
                    time.sleep(0.5)

                    # 다시 스캔
                    if is_convenience_active:
                        screen_img = capture_window(target_hwnd, output_format='cv2')
                    else:
                        screen_img = screenshot_pywin32(output_format='cv2')

                    if screen_img is not None:
                        # 8.png, 9.png 다시 찾기
                        new_8_loc = find_image_gray('8.png', current_scale, screen_img, confidence=CONFIDENCE_THRESHOLD)
                        new_9_loc = find_image_gray('9.png', current_scale, screen_img, confidence=CONFIDENCE_THRESHOLD)

                        if new_8_loc and new_9_loc:
                            x8, y8, w8, h8 = new_8_loc
                            x9, y9, w9, h9 = new_9_loc
                            # 화면 좌표로 변환
                            if is_convenience_active:
                                x9 += window_offset_x
                                y9 += window_offset_y
                            y_diff = y9 - (y8 + h8 + window_offset_y if is_convenience_active else y8 + h8)
                            if 0 <= y_diff <= 150:
                                nine_below_eight = True
                                nine_location = (x9, y9, w9, h9)
                                log_debug(f"[루프 {loop_count}] 페이지다운 후 9.png 발견")
                        del screen_img

                if not nine_below_eight:
                    # 페이지다운 후에도 없음 → 패스
                    log_debug(f"[루프 {loop_count}] 페이지다운 후에도 9.png 없음 → 패스")
                    consecutive_no_match += 1
                    time.sleep(1)
                    continue

                # 5~20초 랜덤 대기
                wait_time = random.randint(5, 20)
                log_info(f"[루프 {loop_count}] 다음 차시 발견 → {wait_time}초 대기 후 클릭")
                logging_queue.put(f"다음 차시 대기 중... ({wait_time}초)")

                for remaining in range(wait_time, 0, -1):
                    if stop_event.is_set():
                        break
                    if remaining % 5 == 0:
                        logging_queue.put(f"다음 차시 대기 중... ({remaining}초 후 이동)")
                    time.sleep(1)

                if stop_event.is_set():
                    continue

                logging_queue.put("다음 학습 차시로 이동합니다...")

                # 9.png(학습전)의 좌표 - 제목이 왼쪽 고정, 9.png가 오른쪽 고정
                # 왼쪽부터 스캔해서 텍스트 시작점 찾아서 클릭
                x, y, w, h = nine_location

                border_offset = int(10 * (current_scale / 100))

                if is_convenience_active:
                    scan_img = capture_window(target_hwnd, output_format='cv2')
                    scan_start_x = border_offset
                    scan_y = (y + h // 2) - window_offset_y
                else:
                    scan_img = screenshot_pywin32(output_format='cv2')
                    scan_start_x = window_offset_x + border_offset
                    scan_y = y + h // 2

                click_x = None
                if scan_img is not None:
                    text_start_x = find_text_start_x(
                        scan_img,
                        scan_y,
                        scan_start_x,
                        scan_start_x + target_window.width // 2,
                        brightness_threshold=180
                    )
                    if text_start_x is not None:
                        if is_convenience_active:
                            click_x = text_start_x + window_offset_x
                        else:
                            click_x = text_start_x
                        log_debug(f"텍스트 시작 X좌표 발견: {click_x}")
                    del scan_img

                click_y = y + h // 2

                # 텍스트 못 찾으면 창 왼쪽 100px 지점 (폴백)
                if click_x is None:
                    base_left_offset = 100
                    scaled_left_offset = int(base_left_offset * (current_scale / 100))
                    click_x = window_offset_x + scaled_left_offset
                    log_debug(f"텍스트 시작 위치 못 찾음, 폴백: {click_x}")

                click_location = (click_x, click_y, 1, 1)
                perform_human_click(click_location, '다음 학습 차시 클릭', logging_queue, target_hwnd)
                consecutive_no_match = 0
            else:
                consecutive_no_match += 1

                # 주기적 상태 업데이트 (5초마다)
                current_time = time.time()
                if current_time - last_status_update >= 5:
                    logging_queue.put(f"대기 중... (루프 {loop_count}회, 배율 {current_scale}%)")
                    last_status_update = current_time

                # 연속 30회 이상 매칭 실패 시 경고
                if consecutive_no_match == 30:
                    log_warning(f"[루프 {loop_count}] 30회 연속 매칭 실패")
                    logging_queue.put(f"[주의] 버튼을 찾지 못하고 있습니다. 강의실 창을 확인해주세요. (배율: {current_scale}%)")
                elif consecutive_no_match > 0 and consecutive_no_match % 60 == 0:
                    logging_queue.put(f"[주의] 계속 대기 중... ({consecutive_no_match}회 탐색, 배율: {current_scale}%)")

                time.sleep(1)

        except Exception as e:
            log_error(f"[루프 {loop_count}] 자동화 루프 오류: {e}", exc_info=True)
            time.sleep(2)  # 오류 발생 시 잠시 대기 후 재시도

    # 종료 시 메모리 정리
    clear_template_cache()
    gc.collect()

    log_info(f"=== 자동화 루프 종료 (총 {loop_count}회 실행) ===")
    logging_queue.put("자동화가 중지되었습니다.")
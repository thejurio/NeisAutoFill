# -*- coding: utf-8 -*-
# 파일 이름: src/logger.py
# 역할: 에러 로깅 및 디버깅 지원

import os
import sys
import logging
import logging.handlers
import tempfile
import atexit
from datetime import datetime

# 로그 파일 설정
MAX_LOG_SIZE = 5 * 1024 * 1024  # 5MB
MAX_LOG_FILES = 5  # 최대 5개 파일 유지


def get_log_dir():
    """로그 디렉토리 경로 반환"""
    # 1차 시도: 프로젝트 루트의 logs 폴더
    try:
        if getattr(sys, 'frozen', False) or "__compiled__" in globals():
            base = os.path.dirname(sys.executable)
        else:
            base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        log_dir = os.path.join(base, 'logs')

        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

        # 쓰기 테스트
        test_file = os.path.join(log_dir, '.write_test')
        with open(test_file, 'w') as f:
            f.write('test')
        os.remove(test_file)

        return log_dir

    except Exception:
        pass

    # 2차 시도: 임시 폴더의 DooClick 서브폴더
    try:
        log_dir = os.path.join(tempfile.gettempdir(), 'DooClick_logs')
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        return log_dir
    except Exception:
        return tempfile.gettempdir()


def setup_logger(name='dooclick'):
    """로거 설정 및 반환"""
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger  # 이미 설정됨

    logger.setLevel(logging.DEBUG)

    # 로그 파일 경로
    log_dir = get_log_dir()
    today = datetime.now().strftime('%Y-%m-%d')
    log_file = os.path.join(log_dir, f'{today}.log')

    # 파일 핸들러 (RotatingFileHandler로 자동 순환)
    try:
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=MAX_LOG_SIZE,
            backupCount=MAX_LOG_FILES,
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)
        file_format = logging.Formatter(
            '%(asctime)s [%(levelname)s] %(message)s',
            datefmt='%H:%M:%S'
        )
        file_handler.setFormatter(file_format)
        logger.addHandler(file_handler)
    except Exception as e:
        # 콘솔에 오류 출력 (개발 모드에서만)
        if not getattr(sys, 'frozen', False):
            print(f"[로거] 파일 핸들러 생성 실패: {e}")

    # 콘솔 핸들러 (개발용)
    if not getattr(sys, 'frozen', False):
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_format = logging.Formatter('[%(levelname)s] %(message)s')
        console_handler.setFormatter(console_format)
        logger.addHandler(console_handler)

    return logger


# 전역 로거
_logger = None


def get_logger():
    """전역 로거 반환"""
    global _logger
    if _logger is None:
        _logger = setup_logger()
    return _logger


def log_info(message):
    """정보 로그"""
    get_logger().info(message)


def log_error(message, exc_info=False):
    """에러 로그"""
    get_logger().error(message, exc_info=exc_info)


def log_debug(message):
    """디버그 로그"""
    get_logger().debug(message)


def log_warning(message):
    """경고 로그"""
    get_logger().warning(message)


def shutdown_logger():
    """로거 종료 및 파일 핸들러 정리"""
    global _logger
    if _logger:
        for handler in _logger.handlers[:]:
            handler.close()
            _logger.removeHandler(handler)
    logging.shutdown()


# 프로그램 종료 시 로거 정리
atexit.register(shutdown_logger)

# -*- coding: utf-8 -*-
# 파일 이름: src/course_navigator.py
# 역할: 강의 목록 탐색 및 강의실 진입 (이미지 매칭 방식)

import pyautogui
import time
import os
import sys

# web_login의 함수들 재사용
from web_login import (
    find_image_gray, find_image_gray_with_score, click_center, close_popup,
    screenshot_pywin32, get_base_path, REF_FOLDER,
    log_info, log_error, log_debug, log_warning,
    _get_screen_img, _activate_window, CONVENIENCE_AVAILABLE
)


def scroll_down(amount=3):
    """페이지 아래로 스크롤

    Args:
        amount: 스크롤 양 (클릭 수)
    """
    pyautogui.scroll(-amount)
    time.sleep(0.5)


def scroll_up(amount=3):
    """페이지 위로 스크롤"""
    pyautogui.scroll(amount)
    time.sleep(0.5)


def navigate_to_my_classroom(scale, log_queue=None, max_wait=15, hwnd=None):
    """나의 학습실(수강과정)로 이동

    페이지 로딩을 이미지 감지로 확인하고, 페이지다운 + 찾기 반복

    Args:
        scale: 화면 배율
        log_queue: 로그 큐
        max_wait: 최대 대기 시간 (초)
        hwnd: 편리모드 창 핸들 (None이면 일반 모드)

    Returns:
        bool: 성공 여부
    """
    if log_queue:
        log_queue.put("수강과정 페이지로 이동 중...")

    log_info(f"[course_navigator] 수강과정 페이지 이동 시작, 편리모드: {hwnd is not None}")

    # 팝업 닫기
    close_popup(scale, log_queue, hwnd=hwnd)

    # 편리모드가 아닐 때만 브라우저 창 활성화
    if not hwnd:
        browser_window = None
        for title in ['jbstudy', '전북교육연수포털', '전북특별자치도교육청']:
            windows = pyautogui.getWindowsWithTitle(title)
            if windows:
                browser_window = windows[0]
                break

        if browser_window:
            try:
                browser_window.activate()
                time.sleep(0.2)
                log_debug(f"브라우저 창 활성화: {browser_window.title[:30]}")
            except:
                pass

    # 먼저 찾기 → 없으면 페이지다운 → 찾기 반복
    if log_queue:
        log_queue.put("수강과정 버튼 찾는 중...")

    max_page_down = 3

    for attempt in range(max_page_down + 1):  # 0, 1, 2, 3 (총 4번 찾기 시도)
        # 1. 수강과정 버튼 찾기
        screen_img = _get_screen_img(hwnd)
        lectures_btn = find_image_gray('lectures.png', scale, screen_img)

        if lectures_btn:
            if log_queue:
                log_queue.put("수강과정 버튼 발견, 클릭...")
            click_center(lectures_btn, hwnd=hwnd)

            # 수강과정 페이지 로딩 대기 - 이어보기/학습하기 버튼이 나타날 때까지
            if log_queue:
                log_queue.put("수강과정 페이지 로드 대기...")

            for _ in range(20):  # 최대 10초
                time.sleep(0.5)
                screen_img = _get_screen_img(hwnd)

                # 이어보기 또는 학습하기 버튼이 보이면 로딩 완료
                continue_btn = find_image_gray('study_continue.png', scale, screen_img)
                start_btn = find_image_gray('study_agree.png', scale, screen_img)

                if continue_btn or start_btn:
                    log_info("[course_navigator] 수강과정 페이지 이동 성공")
                    if log_queue:
                        log_queue.put("수강과정 페이지 로드 완료!")
                    return True

            # 버튼을 못 찾았지만 일단 성공으로 처리
            log_info("[course_navigator] 수강과정 페이지 이동 (버튼 미확인)")
            return True

        # 2. 못 찾았으면 페이지다운 (마지막 시도가 아닐 때만)
        if attempt < max_page_down:
            if log_queue:
                log_queue.put(f"페이지다운 ({attempt + 1}/{max_page_down})...")
            # 편리모드: 창 활성화 후 키 입력
            _activate_window(hwnd)
            pyautogui.press('pagedown')
            time.sleep(0.6)  # 스크롤 후 렌더링 대기

    # 모든 시도 실패
    if log_queue:
        log_queue.put("[오류] 수강과정 버튼을 찾을 수 없음 (3회 시도 실패)")
    log_error("수강과정 버튼 찾기 실패 (3회 시도)")
    return False


def find_available_course(scale, log_queue=None, hwnd=None):
    """수강 가능한 강의 찾기 (100%가 아닌 것)

    Args:
        scale: 화면 배율
        log_queue: 로그 큐
        hwnd: 편리모드 창 핸들

    Returns:
        tuple: (버튼 종류, 위치) 또는 (None, None)
        버튼 종류: 'continue' (이어보기) 또는 'start' (학습하기)
    """
    screen_img = _get_screen_img(hwnd)

    # 이어보기 버튼 모두 찾기 (Y좌표 정렬됨 - 위에서 아래로)
    continue_btns = find_all_images('study_continue.png', scale, screen_img)
    if continue_btns:
        log_debug(f"이어보기 버튼 {len(continue_btns)}개 발견, 첫 번째 선택")
        return ('continue', continue_btns[0])  # 가장 위에 있는 것 선택

    # 학습하기 버튼 모두 찾기
    start_btns = find_all_images('study_agree.png', scale, screen_img)
    if start_btns:
        log_debug(f"학습하기 버튼 {len(start_btns)}개 발견, 첫 번째 선택")
        return ('start', start_btns[0])  # 가장 위에 있는 것 선택

    return (None, None)


def enter_classroom(scale, log_queue=None, max_scroll=5):
    """강의실 입장

    Args:
        scale: 화면 배율
        log_queue: 로그 큐
        max_scroll: 최대 스크롤 횟수

    Returns:
        bool: 성공 여부
    """
    if log_queue:
        log_queue.put("수강 가능한 강의 찾는 중...")

    log_info("[course_navigator] 강의실 입장 시도")

    # 페이지 상단으로
    scroll_up(5)
    time.sleep(0.5)

    for scroll_count in range(max_scroll + 1):
        btn_type, location = find_available_course(scale, log_queue)

        if location:
            if log_queue:
                btn_name = "이어보기" if btn_type == 'continue' else "학습하기"
                log_queue.put(f"'{btn_name}' 버튼 발견, 클릭...")

            click_center(location)
            time.sleep(1)

            # 강의실 창 팝업 대기
            if log_queue:
                log_queue.put("강의실 창 대기 중...")

            # 강의실 창이 열릴 때까지 대기
            for _ in range(10):
                classroom_window = pyautogui.getWindowsWithTitle("강의실")
                if classroom_window:
                    if log_queue:
                        log_queue.put("강의실 창 열림!")
                    log_info("[course_navigator] 강의실 창 열림")
                    return True
                time.sleep(0.5)

            # 강의실 창이 안 열렸으면 팝업이나 다른 창 확인
            log_warning("강의실 창이 열리지 않음 - 팝업 확인")
            close_popup(scale, log_queue)
            time.sleep(1)

            # 다시 확인
            classroom_window = pyautogui.getWindowsWithTitle("강의실")
            if classroom_window:
                if log_queue:
                    log_queue.put("강의실 창 열림!")
                return True

        # 아래로 스크롤해서 더 찾기
        if scroll_count < max_scroll:
            scroll_down(3)
            time.sleep(0.5)

    if log_queue:
        log_queue.put("[알림] 수강 가능한 강의를 찾을 수 없음 (모두 완료됨)")
    log_info("[course_navigator] 수강 가능한 강의 없음")
    return False


def wait_for_classroom_window(timeout=30, hide_immediately=False, log_queue=None, hidden_windows_dict=None):
    """강의실 창 대기

    Args:
        timeout: 대기 시간 (초)
        hide_immediately: True면 발견 즉시 화면 밖으로 숨김
        log_queue: 로그 큐
        hidden_windows_dict: 숨긴 창 정보 저장용 딕셔너리 (복구용)

    Returns:
        창 객체 또는 None
    """
    import win32gui
    import win32con

    start_time = time.time()

    while time.time() - start_time < timeout:
        windows = pyautogui.getWindowsWithTitle("강의실")
        if windows:
            win = windows[0]

            # 편리모드: 발견 즉시 숨기기
            if hide_immediately:
                try:
                    hwnd = win._hWnd
                    rect = win32gui.GetWindowRect(hwnd)
                    original_pos = (rect[0], rect[1])
                    width = rect[2] - rect[0]
                    height = rect[3] - rect[1]

                    # 화면 밖으로 이동
                    win32gui.SetWindowPos(
                        hwnd, win32con.HWND_TOP,
                        0, -3000, width, height,
                        win32con.SWP_NOSIZE | win32con.SWP_NOZORDER
                    )

                    # 원래 위치 저장 (복구용)
                    if hidden_windows_dict is not None:
                        hidden_windows_dict[hwnd] = original_pos

                    log_debug(f"[wait_for_classroom] 강의실 창 즉시 숨김: hwnd={hwnd}")
                    if log_queue:
                        log_queue.put("[편리모드] 강의실 창 즉시 숨김")
                except Exception as e:
                    log_warning(f"강의실 창 즉시 숨기기 실패: {e}")

            return win
        time.sleep(0.1)  # 더 빠르게 체크 (0.5 → 0.1)

    return None


def click_classroom_button(scale, log_queue=None, max_attempts=10):
    """강의실 버튼 클릭

    Args:
        scale: 화면 배율
        log_queue: 로그 큐
        max_attempts: 최대 시도 횟수

    Returns:
        bool: 성공 여부
    """
    if log_queue:
        log_queue.put("강의실 버튼 찾는 중...")

    for _ in range(max_attempts):
        screen_img = screenshot_pywin32(output_format='cv2')
        classroom_btn = find_image_gray('classroom_btn.png', scale, screen_img)

        if classroom_btn:
            if log_queue:
                log_queue.put("강의실 버튼 클릭...")
            click_center(classroom_btn)
            time.sleep(1)
            return True

        time.sleep(0.5)

    log_warning("강의실 버튼 찾기 실패")
    return False


def handle_course_completion(scale, log_queue=None, max_wait=60):
    """강의 완료 후 처리 (강의실→설문→강의실→문제풀이→강의실→이수처리→나이스전송→창닫기)

    Args:
        scale: 화면 배율
        log_queue: 로그 큐
        max_wait: 최대 대기 시간

    Returns:
        bool: 성공 여부
    """
    if log_queue:
        log_queue.put("강의 완료 처리 시작...")

    log_info("[course_navigator] 강의 완료 후 처리 시작")

    # 1. 강의실 버튼 클릭 (강의 완료 후 첫 번째)
    click_classroom_button(scale, log_queue)
    time.sleep(0.5)

    # 2. 설문 처리
    if log_queue:
        log_queue.put("설문 처리 중...")
    handle_survey(scale, log_queue)

    # 3. 강의실 버튼 클릭 (설문 완료 후)
    click_classroom_button(scale, log_queue)
    time.sleep(0.5)

    # 4. 문제풀이 처리 (있는 경우)
    if log_queue:
        log_queue.put("문제풀이 확인 중...")
    test_done = handle_test(scale, log_queue)

    # 5. 문제풀이 끝났으면 강의실 버튼 다시 클릭
    if test_done:
        click_classroom_button(scale, log_queue)
        time.sleep(0.5)

    # 6. 이수처리 버튼 클릭
    if log_queue:
        log_queue.put("이수처리 버튼 찾는 중...")

    for _ in range(10):
        screen_img = screenshot_pywin32(output_format='cv2')

        complete_btn = find_image_gray('course_complete.png', scale, screen_img)
        if complete_btn:
            if log_queue:
                log_queue.put("이수처리 버튼 클릭...")
            click_center(complete_btn)
            time.sleep(0.5)
            # 확인 팝업 엔터
            pyautogui.press('enter')
            time.sleep(0.5)
            break

        time.sleep(0.3)

    # 7. 나이스 전송
    if log_queue:
        log_queue.put("나이스 전송 버튼 찾는 중...")

    for _ in range(10):
        screen_img = screenshot_pywin32(output_format='cv2')

        neis_btn = find_image_gray('neis_send.png', scale, screen_img)
        if neis_btn:
            if log_queue:
                log_queue.put("나이스 전송 버튼 클릭...")
            click_center(neis_btn)
            time.sleep(0.5)
            # 확인 팝업 엔터
            pyautogui.press('enter')
            time.sleep(0.5)

            if log_queue:
                log_queue.put("나이스 전송 완료!")
            log_info("[course_navigator] 나이스 전송 완료")
            break

        time.sleep(1)

    # 8. 현재 강의 창 닫기
    if log_queue:
        log_queue.put("강의 창 닫는 중...")

    # 전북교육연수포털 창 찾아서 닫기 (강의 상세 창)
    try:
        course_windows = pyautogui.getWindowsWithTitle("전북교육연수포털")
        # 강의실 창이 아닌 것 중에서 닫기
        for win in course_windows:
            # 메인 브라우저 창이 아닌 팝업 창 닫기
            if win.width < 1200:  # 작은 창은 팝업으로 간주
                try:
                    win.close()
                    log_debug(f"강의 창 닫음: {win.title[:30]}")
                except:
                    pass
    except Exception as e:
        log_warning(f"창 닫기 실패: {e}")

    # Alt+F4로 현재 창 닫기 시도
    pyautogui.hotkey('alt', 'F4')
    time.sleep(1)

    if log_queue:
        log_queue.put("강의 완료 처리 끝!")
    log_info("[course_navigator] 강의 완료 처리 완료")
    return True


def _find_any_image(templates, scale, screen_img, confidence=0.9):
    """여러 템플릿 중 하나라도 찾으면 반환 (가장 높은 신뢰도 선택)

    Args:
        templates: 템플릿 파일명 리스트
        scale: 화면 배율
        screen_img: 스크린샷
        confidence: 신뢰도 임계값

    Returns:
        (위치, 신뢰도, 템플릿명) 또는 (None, 0, None)
    """
    best_loc = None
    best_score = 0
    best_template = None

    for template in templates:
        loc, score = find_image_gray_with_score(template, scale, screen_img, confidence=confidence)
        if loc and score > best_score:
            best_loc = loc
            best_score = score
            best_template = template

    return (best_loc, best_score, best_template)


def handle_test(scale, log_queue=None):
    """문제풀이 처리 (있는 경우)

    Args:
        scale: 화면 배율
        log_queue: 로그 큐

    Returns:
        bool: 문제풀이 수행 여부
    """
    import random

    screen_img = screenshot_pywin32(output_format='cv2')

    # test.png 또는 test-1.png (응시가능) 버튼 찾기
    test_templates = ['test.png', 'test-1.png']
    test_btn, test_score, test_name = _find_any_image(test_templates, scale, screen_img, confidence=0.85)

    if not test_btn:
        log_debug("문제풀이 버튼 없음 - 스킵")
        return False

    if log_queue:
        log_queue.put(f"문제풀이 버튼 발견 ({test_name}), 클릭...")
    log_debug(f"테스트 버튼 발견: {test_name}, 신뢰도: {test_score:.2f}")

    click_center(test_btn)
    time.sleep(1)

    # start_test.png 또는 start-test-2.png (시험시작) 버튼 찾기
    start_templates = ['start_test.png', 'start-test-2.png']
    for _ in range(10):
        screen_img = screenshot_pywin32(output_format='cv2')
        start_btn, start_score, start_name = _find_any_image(start_templates, scale, screen_img, confidence=0.85)

        if start_btn:
            if log_queue:
                log_queue.put(f"시험시작 버튼 클릭 ({start_name})...")
            log_debug(f"시험시작 버튼 발견: {start_name}, 신뢰도: {start_score:.2f}")
            click_center(start_btn)
            time.sleep(1)
            break

        time.sleep(0.5)

    # 기존 quiz_solver 로직 사용
    if log_queue:
        log_queue.put("문제풀이 진행 중... (quiz_solver)")

    try:
        from quiz_solver import solve_all_quizzes
        # 퀴즈 창 찾기
        quiz_window = pyautogui.getWindowsWithTitle("전북교육연수포털")
        if quiz_window:
            search_region = (
                quiz_window[0].left,
                quiz_window[0].top,
                quiz_window[0].width,
                quiz_window[0].height
            )
            # AI 퀴즈 풀이 실행 (전체 문제)
            from queue import Queue
            temp_queue = log_queue if log_queue else Queue()
            solve_all_quizzes(search_region, temp_queue)
    except Exception as e:
        log_warning(f"quiz_solver 실행 실패: {e}")

    if log_queue:
        log_queue.put("문제풀이 완료")

    return True


def handle_survey(scale, log_queue=None, max_wait=60):
    """설문 처리

    1. survey_start.png 클릭
    2. 반복: checkbox/radio_button 선택 → survey_next 또는 survey_submit 클릭

    Args:
        scale: 화면 배율
        log_queue: 로그 큐
        max_wait: 최대 대기 시간

    Returns:
        bool: 성공 여부
    """
    import random

    if log_queue:
        log_queue.put("설문 처리 중...")

    log_info("[course_navigator] 설문 처리 시작")

    start_time = time.time()

    # 1. 설문 메뉴(survey.png - "참여가능") 찾기 및 클릭
    # 주의: test.png/test-1.png("응시가능")와 매우 유사하므로 신뢰도 비교 필수
    survey_menu_found = False
    for _ in range(10):
        screen_img = screenshot_pywin32(output_format='cv2')

        # survey와 test(여러 버전) 동시에 찾아서 신뢰도 비교
        survey_loc, survey_score = find_image_gray_with_score('survey.png', scale, screen_img, confidence=0.7)

        # test는 여러 버전 중 가장 높은 것 선택
        test_templates = ['test.png', 'test-1.png']
        test_loc, test_score, test_name = _find_any_image(test_templates, scale, screen_img, confidence=0.7)

        log_debug(f"[설문/테스트 구분] survey({survey_score:.3f}) vs test({test_score:.3f}, {test_name})")

        # survey가 test보다 확실히 높을 때만 설문 처리 (0.02 이상 차이)
        if survey_loc and survey_score >= 0.85:
            # test도 발견되면 신뢰도 비교
            if test_loc:
                if survey_score > test_score + 0.02:
                    if log_queue:
                        log_queue.put(f"설문 메뉴 클릭... (survey:{survey_score:.2f} > test:{test_score:.2f})")
                    click_center(survey_loc)
                    time.sleep(1)
                    survey_menu_found = True
                    break
                else:
                    # test가 비슷하거나 더 높으면 설문 아님 (테스트 버튼임)
                    log_debug(f"테스트 버튼으로 판단 ({test_name}) - 설문 없음")
                    return False
            else:
                # survey만 발견됨
                if log_queue:
                    log_queue.put(f"설문 메뉴 클릭... (신뢰도: {survey_score:.2f})")
                click_center(survey_loc)
                time.sleep(1)
                survey_menu_found = True
                break

        time.sleep(0.3)

    if not survey_menu_found:
        log_debug("설문 메뉴 없음 - 설문 없는 강의")
        return False

    # 2. 설문시작 버튼 찾기 및 클릭
    survey_started = False
    for _ in range(10):
        screen_img = screenshot_pywin32(output_format='cv2')
        survey_start = find_image_gray('survey_start.png', scale, screen_img, multiscale=False, confidence=0.95)

        if survey_start:
            if log_queue:
                log_queue.put("설문시작 버튼 클릭...")
            click_center(survey_start)
            time.sleep(1)
            survey_started = True
            break

        time.sleep(0.3)

    if not survey_started:
        log_debug("설문시작 버튼 없음")
        return False

    # 2. 설문 작성 반복
    while time.time() - start_time < max_wait:
        screen_img = screenshot_pywin32(output_format='cv2')

        # 체크박스 또는 라디오 버튼 찾기
        checkboxes = find_all_images('checkbox.png', scale, screen_img, confidence=0.85)
        radio_buttons = find_all_images('radio_button.png', scale, screen_img, confidence=0.85)

        # 선택지가 있으면 랜덤으로 1개 선택
        if checkboxes or radio_buttons:
            all_options = checkboxes + radio_buttons

            if all_options:
                # 랜덤으로 1개 선택
                selected = random.choice(all_options)
                if log_queue:
                    log_queue.put(f"설문 항목 선택 ({len(all_options)}개 중 1개)...")
                click_center(selected)
                time.sleep(0.5)

        # 다음으로/제출 버튼 동시 확인 (비슷한 이미지 구분을 위해 신뢰도 비교)
        screen_img = screenshot_pywin32(output_format='cv2')
        next_loc, next_score = find_image_gray_with_score('survey_next.png', scale, screen_img)
        submit_loc, submit_score = find_image_gray_with_score('survey_submit.png', scale, screen_img)

        log_debug(f"[설문] next 신뢰도: {next_score:.3f}, submit 신뢰도: {submit_score:.3f}")

        # 둘 다 발견된 경우 신뢰도가 높은 것 선택
        if next_loc and submit_loc:
            if submit_score > next_score:
                # 제출 버튼이 더 확실함
                if log_queue:
                    log_queue.put(f"설문 제출 버튼 클릭... (신뢰도: {submit_score:.2f})")
                click_center(submit_loc)
                time.sleep(1)
                close_popup(scale, log_queue)
                if log_queue:
                    log_queue.put("설문 완료!")
                log_info("[course_navigator] 설문 완료")
                return True
            else:
                # 다음 버튼이 더 확실함
                if log_queue:
                    log_queue.put(f"다음으로 버튼 클릭... (신뢰도: {next_score:.2f})")
                click_center(next_loc)
                time.sleep(1.5)
                continue

        # 제출 버튼만 있는 경우
        if submit_loc:
            if log_queue:
                log_queue.put(f"설문 제출 버튼 클릭... (신뢰도: {submit_score:.2f})")
            click_center(submit_loc)
            time.sleep(1)
            close_popup(scale, log_queue)
            if log_queue:
                log_queue.put("설문 완료!")
            log_info("[course_navigator] 설문 완료")
            return True

        # 다음 버튼만 있는 경우
        if next_loc:
            if log_queue:
                log_queue.put(f"다음으로 버튼 클릭... (신뢰도: {next_score:.2f})")
            click_center(next_loc)
            time.sleep(1.5)
            continue

        # 아무 버튼도 없으면 잠시 대기
        time.sleep(1)

    log_warning("설문 처리 타임아웃")
    return False


def find_all_images(template_name, scale, screen_img=None, confidence=0.8):
    """템플릿 이미지를 모두 찾기 (여러 개)

    Args:
        template_name: 템플릿 파일명
        scale: 화면 배율
        screen_img: 스크린샷
        confidence: 신뢰도

    Returns:
        list: [(x, y, w, h), ...] 위치 목록
    """
    import os
    import cv2
    import numpy as np

    REF_FOLDER = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'ref')
    template_path = os.path.join(REF_FOLDER, str(scale), template_name)

    if not os.path.exists(template_path):
        return []

    from utils.screenshot_utils import imread_korean_path

    template = imread_korean_path(template_path)
    if template is None:
        return []

    if screen_img is None:
        screen_img = screenshot_pywin32(output_format='cv2')

    if screen_img is None:
        return []

    result = cv2.matchTemplate(screen_img, template, cv2.TM_CCOEFF_NORMED)
    h, w = template.shape[:2]

    locations = []
    loc = np.where(result >= confidence)

    # 중복 제거를 위한 거리 임계값
    min_distance = min(w, h) // 2

    for pt in zip(*loc[::-1]):
        x, y = pt[0], pt[1]

        # 기존 위치와 너무 가까우면 스킵
        is_duplicate = False
        for ex, ey, _, _ in locations:
            if abs(x - ex) < min_distance and abs(y - ey) < min_distance:
                is_duplicate = True
                break

        if not is_duplicate:
            locations.append((x, y, w, h))

    # Y 좌표로 정렬 (위에서 아래로)
    locations.sort(key=lambda loc: loc[1])

    return locations


def handle_study_start_process(scale, log_queue=None):
    """학습하기 후 추가 과정 처리

    새 창에서 start_study.png (차시별 학습하기 버튼) 중 가장 위에 있는 것 클릭

    Args:
        scale: 화면 배율
        log_queue: 로그 큐

    Returns:
        bool: 성공 여부
    """
    if log_queue:
        log_queue.put("학습하기 추가 과정 처리 중...")

    log_info("[course_navigator] 학습하기 추가 과정 시작")

    # 새 창 로드 대기
    time.sleep(1)

    # 팝업 닫기
    close_popup(scale, log_queue)
    time.sleep(0.5)

    # start_study.png 찾기 (최대 10회 시도)
    for attempt in range(10):
        screen_img = screenshot_pywin32(output_format='cv2')

        # 모든 start_study.png 찾기
        locations = find_all_images('start_study.png', scale, screen_img)

        if locations:
            # 가장 위에 있는 것 (Y 좌표가 가장 작은 것) 선택
            top_location = locations[0]

            if log_queue:
                log_queue.put(f"차시 학습하기 버튼 발견 ({len(locations)}개), 첫 번째 클릭...")

            log_debug(f"start_study.png 발견: {len(locations)}개, 클릭: {top_location}")
            click_center(top_location)
            time.sleep(1)

            # 강의실 창 대기
            for _ in range(15):
                classroom_window = pyautogui.getWindowsWithTitle("강의실")
                if classroom_window:
                    log_info("[course_navigator] 강의실 창 열림 (학습하기)")
                    if log_queue:
                        log_queue.put("강의실 창 열림!")
                    return True

                # 팝업 확인
                close_popup(scale, log_queue)
                time.sleep(0.5)

            # 강의실 창이 안 열렸으면 재시도
            log_warning("강의실 창이 열리지 않음, 재시도...")
            continue

        # 못 찾으면 팝업 확인 후 재시도
        close_popup(scale, log_queue)
        time.sleep(1)

    log_error("start_study.png 찾기 실패")
    return False


# 테스트용
if __name__ == '__main__':
    print("=== course_navigator.py 테스트 ===")
    print(f"REF_FOLDER: {REF_FOLDER}")

    # 배율 감지
    import win32gui
    import win32print
    import win32con

    hDC = win32gui.GetDC(0)
    dpi = win32print.GetDeviceCaps(hDC, win32con.LOGPIXELSX)
    win32gui.ReleaseDC(0, hDC)
    scale = int(dpi / 96 * 100)
    print(f"화면 배율: {scale}%")

    # 수강 가능한 강의 찾기 테스트
    print("\n수강 가능한 강의 찾기...")
    btn_type, location = find_available_course(scale)
    if location:
        print(f"발견: {btn_type} at {location}")
    else:
        print("수강 가능한 강의 없음")

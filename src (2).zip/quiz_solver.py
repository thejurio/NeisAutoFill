# -*- coding: utf-8 -*-
# 파일: src/quiz_solver.py
# 역할: AI 기반 퀴즈 자동 풀이 모듈 (Gemini Vision 사용)
# 수정일: 2026-01-29 (메모리 관리 개선)

import re
import time
import os
import gc
import cv2
import numpy as np
import pyautogui
import threading

# 스크린샷 유틸리티
from utils.screenshot_utils import screenshot_pywin32, imread_korean_path

# Gemini 솔버 (이미지 분석 포함)
try:
    import gemini_solver
    AI_SOLVER_AVAILABLE = True
except ImportError as e:
    print(f"[경고] gemini_solver 모듈 로드 실패: {e}")
    AI_SOLVER_AVAILABLE = False

# 배율 감지 함수
try:
    from active_mode import get_display_scaling
except ImportError:
    def get_display_scaling(point=None, logging_queue=None):
        return (100, False)  # 기본값 100%

# 로거
try:
    from logger import log_info, log_error, log_debug, log_warning
except ImportError:
    def log_info(msg): print(f"[INFO] {msg}")
    def log_error(msg, exc_info=False): print(f"[ERROR] {msg}")
    def log_debug(msg): print(f"[DEBUG] {msg}")
    def log_warning(msg): print(f"[WARN] {msg}")

# 설정
SIDEBAR_WIDTH = 170  # 왼쪽 사이드바 너비
CLICK_DELAY = 0.5
CONFIDENCE_THRESHOLD = 0.9  # 이미지 매칭 신뢰도 (버튼용)

# 프로젝트 경로
try:
    from config import PROJECT_ROOT
    REF_FOLDER = os.path.join(PROJECT_ROOT, 'ref')
except ImportError:
    REF_FOLDER = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'ref')


def is_ai_available():
    """AI 문제 풀이 사용 가능 여부"""
    return AI_SOLVER_AVAILABLE


def _get_quiz_content_region(window_region):
    """퀴즈 콘텐츠 영역만 추출 (사이드바 제외)"""
    left, top, width, height = window_region
    content_left = left + SIDEBAR_WIDTH
    content_width = width - SIDEBAR_WIDTH - 30
    return (content_left, top, content_width, height)


def _call_gemini_with_progress(screenshot, logging_queue):
    """
    Gemini API 호출하면서 진행 상황 애니메이션 표시

    Returns:
        dict: Gemini 응답 결과
    """
    result = [None]
    done = threading.Event()

    def call_api():
        result[0] = gemini_solver.solve_quiz_from_image(screenshot)
        done.set()

    # 별도 스레드에서 API 호출
    thread = threading.Thread(target=call_api)
    thread.start()

    # 대기하면서 점 애니메이션 표시
    dots = 1

    while not done.wait(timeout=0.2):
        msg = "AI 응답 대기 중" + "." * dots
        logging_queue.put(msg)
        dots = (dots % 3) + 1

    return result[0]


def _click_answer_by_type(quiz_region, answer, answer_type, logging_queue):
    """
    정답 타입에 따라 클릭 위치 결정 후 클릭

    좌표는 100% 배율 기준 (quiz_region = 사이드바 제외 영역):
    - 라디오/체크박스 X: 154px
    - 1번 Y: 374px, 이후 46px 간격
    - OX: O=374, X=420
    배율에 따라 자동 스케일링됨.
    """
    left, top, width, height = quiz_region

    # 배율 감지 및 스케일 비율 계산
    scale, _ = get_display_scaling((left, top), logging_queue)
    scale_ratio = scale / 100.0

    # 100% 기준 좌표 (Page Down 후 위치, 배율에 따라 스케일링)
    base_x = 154
    base_y_first = 180  # 1번 보기 Y 좌표 (Page Down 후)
    base_interval = 46  # 보기 간격

    # 클릭 X 좌표: 라디오/체크박스 위치
    click_x = left + int(base_x * scale_ratio)

    if answer_type == 'ox':
        if answer == 'O':
            click_y = top + int(base_y_first * scale_ratio)
        else:
            click_y = top + int((base_y_first + base_interval) * scale_ratio)
        log_info(f"OX 클릭: {answer} at ({click_x}, {click_y}) [배율: {scale}%]")

    elif answer_type == 'number':
        # 객관식/복수선택: 1번부터 시작
        try:
            num = int(answer)
            click_y = top + int((base_y_first + (num - 1) * base_interval) * scale_ratio)
        except ValueError:
            click_y = top + int(base_y_first * scale_ratio)
        log_info(f"객관식 클릭: {answer}번 at ({click_x}, {click_y}) [배율: {scale}%]")

    else:
        # 기타: 첫 번째 보기 위치
        click_y = top + int(base_y_first * scale_ratio)
        log_info(f"기타 클릭: {answer} at ({click_x}, {click_y}) [배율: {scale}%]")

    # 클릭 실행
    pyautogui.click(click_x, click_y)
    logging_queue.put(f"정답 클릭: {answer}")
    return True


def _detect_radio_buttons(screenshot, logging_queue):
    """
    캡처 이미지에서 라디오 버튼(보기) 위치를 자동 검출
    실제 라디오 버튼 이미지(radio_button.png)로 템플릿 매칭

    Args:
        screenshot: PIL Image
        logging_queue: 로깅 큐
    Returns:
        list: [(x, y), ...] 라디오 버튼 중심 좌표 리스트 (Y 정렬)
    """
    img_cv = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)
    img_h, img_w = gray.shape

    # 실제 라디오 버튼 템플릿 로드
    template_path = os.path.join(REF_FOLDER, '100', 'radio_button.png')
    template = imread_korean_path(template_path)
    if template is None:
        log_error(f"라디오 버튼 템플릿 없음: {template_path}")
        return []

    template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY) if len(template.shape) == 3 else template
    t_h, t_w = template_gray.shape

    # 여러 스케일로 매칭 시도 (배율 대응)
    all_matches = []
    for scale in [0.8, 0.9, 1.0, 1.1, 1.2]:
        new_w = int(t_w * scale)
        new_h = int(t_h * scale)
        if new_w < 5 or new_h < 5:
            continue
        resized = cv2.resize(template_gray, (new_w, new_h))
        result = cv2.matchTemplate(gray, resized, cv2.TM_CCOEFF_NORMED)

        # 신뢰도 0.9 이상인 위치 찾기
        locations = np.where(result >= 0.9)
        for pt_y, pt_x in zip(*locations):
            cx = pt_x + new_w // 2
            cy = pt_y + new_h // 2
            score = float(result[pt_y, pt_x])
            all_matches.append((cx, cy, score))

    if not all_matches:
        log_warning("라디오 버튼 템플릿 매칭 실패")
        return []

    # NMS: 가까운 검출 중 가장 높은 점수만 남기기
    all_matches.sort(key=lambda m: -m[2])
    kept = []
    for m in all_matches:
        too_close = False
        for k in kept:
            if abs(m[0] - k[0]) < 25 and abs(m[1] - k[1]) < 25:
                too_close = True
                break
        if not too_close:
            kept.append(m)

    # Y좌표 기준 정렬
    kept.sort(key=lambda m: m[1])

    log_info(f"라디오 버튼 {len(kept)}개 검출")
    for i, (x, y, s) in enumerate(kept):
        log_debug(f"  버튼 {i+1}: ({x}, {y}), 신뢰도={s:.2f}")

    # 신뢰도 포함하여 반환
    return [(x, y, s) for x, y, s in kept]


def _detect_checkboxes(screenshot, logging_queue):
    """
    캡처 이미지에서 체크박스 위치를 자동 검출
    복수 정답 문제용 (모두 고르시오)

    Args:
        screenshot: PIL Image
        logging_queue: 로깅 큐
    Returns:
        list: [(x, y, score), ...] 체크박스 중심 좌표 리스트 (Y 정렬)
    """
    img_cv = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)
    img_h, img_w = gray.shape

    # 체크박스 템플릿 로드
    template_path = os.path.join(REF_FOLDER, '100', 'checkbox.png')
    template = imread_korean_path(template_path)
    if template is None:
        log_error(f"체크박스 템플릿 없음: {template_path}")
        return []

    template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY) if len(template.shape) == 3 else template
    t_h, t_w = template_gray.shape

    # 여러 스케일로 매칭 시도 (배율 대응)
    all_matches = []
    for scale in [0.8, 0.9, 1.0, 1.1, 1.2]:
        new_w = int(t_w * scale)
        new_h = int(t_h * scale)
        if new_w < 5 or new_h < 5:
            continue
        resized = cv2.resize(template_gray, (new_w, new_h))
        result = cv2.matchTemplate(gray, resized, cv2.TM_CCOEFF_NORMED)

        # 신뢰도 0.9 이상인 위치 찾기
        locations = np.where(result >= 0.9)
        for pt_y, pt_x in zip(*locations):
            cx = pt_x + new_w // 2
            cy = pt_y + new_h // 2
            score = float(result[pt_y, pt_x])
            all_matches.append((cx, cy, score))

    if not all_matches:
        log_warning("체크박스 템플릿 매칭 실패")
        return []

    # NMS: 가까운 검출 중 가장 높은 점수만 남기기
    all_matches.sort(key=lambda m: -m[2])
    kept = []
    for m in all_matches:
        too_close = False
        for k in kept:
            if abs(m[0] - k[0]) < 25 and abs(m[1] - k[1]) < 25:
                too_close = True
                break
        if not too_close:
            kept.append(m)

    # Y좌표 기준 정렬
    kept.sort(key=lambda m: m[1])

    log_info(f"체크박스 {len(kept)}개 검출")
    for i, (x, y, s) in enumerate(kept):
        log_debug(f"  체크박스 {i+1}: ({x}, {y}), 신뢰도={s:.2f}")

    return [(x, y, s) for x, y, s in kept]


def _click_answer_by_detection(screenshot, quiz_region, answer, answer_type, logging_queue):
    """
    이미지에서 라디오 버튼 또는 체크박스를 검출하여 정답 클릭

    Args:
        screenshot: PIL Image (캡처된 퀴즈 화면)
        quiz_region: (left, top, width, height) 퀴즈 영역
        answer: 정답 (O, X, 1, 2, 3, 4 또는 복수 정답 "1,3,4")
        answer_type: 'ox', 'number', 또는 'multiple'
        logging_queue: 로깅 큐
    Returns:
        True: 클릭 성공, False: 검출 실패
    """
    # 복수 정답인 경우 체크박스 검출
    if answer_type == 'multiple':
        buttons_with_score = _detect_checkboxes(screenshot, logging_queue)
        button_name = "체크박스"
    else:
        buttons_with_score = _detect_radio_buttons(screenshot, logging_queue)
        button_name = "라디오 버튼"

    if not buttons_with_score:
        log_warning(f"{button_name} 검출 실패")
        return False

    # 좌표만 추출
    buttons = [(x, y) for x, y, s in buttons_with_score]

    # 복수 정답 처리
    if answer_type == 'multiple':
        # 쉼표로 구분된 정답 파싱 (예: "1,3,4")
        try:
            target_indices = [int(a.strip()) - 1 for a in answer.split(',')]
        except ValueError:
            log_warning(f"복수 정답 파싱 실패: {answer}")
            return False

        clicked_count = 0
        for idx in target_indices:
            if idx >= len(buttons):
                log_warning(f"정답 인덱스 초과: {idx+1} > {len(buttons)}")
                continue

            btn_x, btn_y = buttons[idx]
            screen_x = quiz_region[0] + btn_x
            screen_y = quiz_region[1] + btn_y

            log_info(f"체크박스 클릭: {idx+1}번 at ({screen_x}, {screen_y})")
            pyautogui.click(screen_x, screen_y)
            time.sleep(0.2)  # 클릭 간 짧은 대기
            clicked_count += 1

        logging_queue.put(f"정답 클릭: {answer} ({clicked_count}개 선택)")
        return clicked_count > 0

    # 단일 정답 처리 (기존 로직)
    target_idx = 0
    if answer_type == 'ox':
        target_idx = 0 if answer == 'O' else 1
    elif answer_type == 'number':
        try:
            target_idx = int(answer) - 1
        except ValueError:
            target_idx = 0

    if target_idx >= len(buttons):
        log_warning(f"정답 인덱스 초과: {target_idx} >= {len(buttons)}")
        return False

    btn_x, btn_y = buttons[target_idx]
    screen_x = quiz_region[0] + btn_x
    screen_y = quiz_region[1] + btn_y

    log_info(f"정답 버튼 클릭: {answer} at 이미지({btn_x}, {btn_y}) → 화면({screen_x}, {screen_y})")
    pyautogui.click(screen_x, screen_y)
    logging_queue.put(f"정답 클릭: {answer}")
    return True


def _find_button_on_screen(template_name, window_region, confidence=CONFIDENCE_THRESHOLD):
    """
    화면에서 버튼 템플릿을 찾아 위치 반환

    Args:
        template_name: 템플릿 파일명 (예: 'next_button.png')
        window_region: 검색할 창 영역
        confidence: 매칭 신뢰도

    Returns:
        (x, y) 클릭 좌표 또는 None
    """
    loc, score = _find_button_with_score(template_name, window_region, confidence)
    return loc


def _find_button_with_score(template_name, window_region, confidence=CONFIDENCE_THRESHOLD):
    """
    화면에서 버튼 템플릿을 찾아 위치와 신뢰도 반환

    Args:
        template_name: 템플릿 파일명
        window_region: 검색할 창 영역
        confidence: 매칭 신뢰도 임계값

    Returns:
        ((x, y), score) 또는 (None, score)
    """
    screenshot = None
    template = None
    result = None

    try:
        # 화면 캡처
        screenshot = screenshot_pywin32(region=window_region, output_format='cv2')

        # 템플릿 로드 (100% 배율 기준)
        template_path = os.path.join(REF_FOLDER, '100', template_name)
        if not os.path.exists(template_path):
            log_warning(f"템플릿 없음: {template_path}")
            return (None, 0.0)

        template = imread_korean_path(template_path)
        if template is None:
            log_warning(f"템플릿 로드 실패: {template_path}")
            return (None, 0.0)

        # 템플릿 매칭
        result = cv2.matchTemplate(screenshot, template, cv2.TM_CCOEFF_NORMED)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)

        if max_val >= confidence:
            # 매칭 성공 - 버튼 중앙 좌표 계산
            h, w = template.shape[:2]
            center_x = window_region[0] + max_loc[0] + w // 2
            center_y = window_region[1] + max_loc[1] + h // 2
            log_info(f"버튼 '{template_name}' 발견: ({center_x}, {center_y}), 신뢰도: {max_val:.2f}")
            return ((center_x, center_y), max_val)
        else:
            log_debug(f"버튼 '{template_name}' 못 찾음 (신뢰도: {max_val:.2f})")
            return (None, max_val)

    finally:
        # 메모리 정리
        del screenshot, template, result


def _click_next_or_submit(window_region, logging_queue):
    """
    '다음으로' 또는 '답안제출' 버튼 찾아서 클릭 (신뢰도 비교 방식)

    Returns:
        'next': 다음 문제로 이동
        'submit': 마지막 문제, 답안 제출 완료
        None: 버튼 못 찾음
    """
    # 1. 두 버튼을 동시에 찾아서 신뢰도 비교
    next_loc, next_score = _find_button_with_score('next_button.png', window_region)
    submit_loc, submit_score = _find_button_with_score('submit.png', window_region)

    log_debug(f"[버튼] next 신뢰도: {next_score:.3f}, submit 신뢰도: {submit_score:.3f}")

    # 둘 다 발견된 경우 신뢰도가 높은 것 선택
    if next_loc and submit_loc:
        if submit_score > next_score:
            # 제출 버튼이 더 확실함
            log_info(f"[SUBMIT] 답안제출 버튼 발견 (신뢰도 우선): {submit_loc}, 신뢰도: {submit_score:.2f}")
            time.sleep(CLICK_DELAY)
            pyautogui.click(submit_loc[0], submit_loc[1])
            log_info("[SUBMIT] 답안제출 버튼 클릭 완료")
            logging_queue.put(f"답안 제출 중... (신뢰도: {submit_score:.2f})")
            time.sleep(0.5)
            pyautogui.press('enter')
            log_info("[SUBMIT] Enter로 확인 완료")
            logging_queue.put("답안 제출 완료!")
            return 'submit'
        else:
            # 다음 버튼이 더 확실함
            log_info(f"다음 버튼 클릭 (신뢰도 우선): {next_loc}, 신뢰도: {next_score:.2f}")
            time.sleep(CLICK_DELAY)
            pyautogui.click(next_loc[0], next_loc[1])
            logging_queue.put(f"다음 문제로 이동 (신뢰도: {next_score:.2f})")
            return 'next'

    # 제출 버튼만 있는 경우
    if submit_loc:
        log_info(f"[SUBMIT] 답안제출 버튼 발견: {submit_loc}, 신뢰도: {submit_score:.2f}")
        time.sleep(CLICK_DELAY)
        pyautogui.click(submit_loc[0], submit_loc[1])
        log_info("[SUBMIT] 답안제출 버튼 클릭 완료")
        logging_queue.put("답안 제출 중...")
        time.sleep(0.5)
        pyautogui.press('enter')
        log_info("[SUBMIT] Enter로 확인 완료")
        logging_queue.put("답안 제출 완료!")
        return 'submit'

    # 다음 버튼만 있는 경우
    if next_loc:
        log_info(f"다음 버튼 클릭: {next_loc}, 신뢰도: {next_score:.2f}")
        time.sleep(CLICK_DELAY)
        pyautogui.click(next_loc[0], next_loc[1])
        logging_queue.put("다음 문제로 이동")
        return 'next'

    # 2. 둘 다 없으면 Page Down 후 재시도
    log_info("버튼 못 찾음 → Page Down 후 재시도")
    pyautogui.press('pagedown')
    time.sleep(0.5)

    next_loc2, next_score2 = _find_button_with_score('next_button.png', window_region)
    submit_loc2, submit_score2 = _find_button_with_score('submit.png', window_region)

    log_debug(f"[버튼 PageDown 후] next 신뢰도: {next_score2:.3f}, submit 신뢰도: {submit_score2:.3f}")

    # 둘 다 발견된 경우 신뢰도 비교
    if next_loc2 and submit_loc2:
        if submit_score2 > next_score2:
            log_info(f"답안제출 버튼 클릭 (PageDown 후, 신뢰도 우선): {submit_loc2}")
            pyautogui.click(submit_loc2[0], submit_loc2[1])
            logging_queue.put("답안 제출 중...")
            time.sleep(0.5)
            pyautogui.press('enter')
            logging_queue.put("답안 제출 완료!")
            return 'submit'
        else:
            log_info(f"다음 버튼 클릭 (PageDown 후, 신뢰도 우선): {next_loc2}")
            pyautogui.click(next_loc2[0], next_loc2[1])
            logging_queue.put("다음 문제로 이동")
            return 'next'

    if submit_loc2:
        log_info(f"답안제출 버튼 클릭 (PageDown 후): {submit_loc2}")
        pyautogui.click(submit_loc2[0], submit_loc2[1])
        logging_queue.put("답안 제출 중...")
        time.sleep(0.5)
        pyautogui.press('enter')
        log_info("[SUBMIT] Enter로 확인 완료 (PageDown 후)")
        logging_queue.put("답안 제출 완료!")
        return 'submit'

    if next_loc2:
        log_info(f"다음 버튼 클릭 (PageDown 후): {next_loc2}")
        pyautogui.click(next_loc2[0], next_loc2[1])
        logging_queue.put("다음 문제로 이동")
        return 'next'

    log_warning("다음/제출 버튼을 찾지 못함")
    return None


def _click_next_button(window_region, logging_queue):
    """기존 호환성 유지용 - _click_next_or_submit 호출"""
    result = _click_next_or_submit(window_region, logging_queue)
    return result is not None


def solve_single_quiz(window_region, logging_queue):
    """
    단일 퀴즈 문제 풀이 (Gemini Vision 사용)

    Args:
        window_region: (left, top, width, height) - 퀴즈 창 영역
        logging_queue: UI 로깅을 위한 큐
    Returns:
        tuple: (성공 여부, 마지막 문제 여부)
               - (True, False): 성공, 다음 문제 있음
               - (True, True): 성공, 마지막 문제 (답안 제출 완료)
               - (False, False): 실패
    """
    if not AI_SOLVER_AVAILABLE:
        logging_queue.put("[오류] AI 모듈을 사용할 수 없습니다.")
        return (False, False)

    try:
        logging_queue.put("퀴즈 화면 캡처 중...")
        log_info("=== 퀴즈 풀이 시작 ===")

        # 0. 팝업("답변후 이동 가능합니다") 있으면 확인 클릭
        try:
            popup_btn = pyautogui.locateOnScreen(
                os.path.join(REF_FOLDER, '100', 'confirm_popup.png'),
                confidence=0.7
            )
            if popup_btn:
                center = pyautogui.center(popup_btn)
                pyautogui.click(center)
                log_info("팝업 확인 버튼 클릭")
                time.sleep(0.5)
        except Exception:
            pass  # 팝업 없으면 무시
        # 브라우저 팝업 (alert) 처리: Enter로 닫기
        pyautogui.press('enter')
        time.sleep(0.3)

        # 1. 퀴즈 영역 캡처
        quiz_region = _get_quiz_content_region(window_region)
        log_info(f"퀴즈 영역: {quiz_region}")

        # Page Down으로 문제 전체 보이게 스크롤 (Gemini가 전체 문제 볼 수 있도록)
        pyautogui.press('pagedown')
        time.sleep(0.15)  # 스크롤 후 화면 안정화 대기

        # 스크린샷 캡처 (Page Down 후 상태)
        screenshot = screenshot_pywin32(region=quiz_region)
        log_info("스크린샷 캡처 완료")

        # 2. Gemini에게 이미지 전송하여 정답 받기 (진행 애니메이션 표시)
        result = _call_gemini_with_progress(screenshot, logging_queue)

        if not result['success']:
            error_msg = result.get('error', '알 수 없는 오류')
            logging_queue.put(f"[오류] {error_msg}")
            log_error(f"Gemini 오류: {error_msg}")
            return (False, False)

        answer = result['answer']
        answer_type = result['answer_type']
        log_info(f"Gemini 응답: {answer} (타입: {answer_type})")
        logging_queue.put(f"AI 정답: {answer}")

        # 3. 정답 클릭 - OpenCV 라디오 버튼 검출 방식
        time.sleep(CLICK_DELAY)

        # 디버그: 검출된 버튼 위치 + 신뢰도 표시한 이미지 저장
        buttons_with_score = _detect_radio_buttons(screenshot, logging_queue)
        try:
            debug_img = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
            for i, (bx, by, score) in enumerate(buttons_with_score):
                color = (0, 255, 0)  # 녹색
                cv2.circle(debug_img, (bx, by), 15, color, 2)
                cv2.putText(debug_img, f"{i+1} ({score:.2f})", (bx + 18, by + 5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            debug_path = os.path.join(os.path.dirname(REF_FOLDER), 'debug_click.png')
            is_success, buf = cv2.imencode('.png', debug_img)
            if is_success:
                buf.tofile(debug_path)
                log_info(f"[디버그] 이미지 저장: {debug_path}")
        except Exception as e:
            log_debug(f"디버그 이미지 저장 실패: {e}")

        # OpenCV 템플릿 매칭으로 라디오 버튼 검출 후 클릭
        clicked = _click_answer_by_detection(screenshot, quiz_region, answer, answer_type, logging_queue)
        if not clicked:
            log_error("라디오 버튼 검출 실패 - 클릭하지 못함")
            logging_queue.put("[경고] 라디오 버튼을 찾지 못했습니다.")

        # 4. 다음/제출 버튼 클릭
        time.sleep(CLICK_DELAY)
        log_info("[FLOW] _click_next_or_submit 호출")
        button_result = _click_next_or_submit(window_region, logging_queue)
        log_info(f"[FLOW] button_result = {button_result}")

        if button_result == 'submit':
            log_info("[FLOW] >>> return (True, True) - 퀴즈 완료!")
            return (True, True)
        elif button_result == 'next':
            log_info("[FLOW] >>> return (True, False) - 다음 문제")
            return (True, False)
        else:
            log_warning("[FLOW] >>> return (False, False) - 버튼 못 찾음")
            logging_queue.put("[경고] 다음/제출 버튼을 찾지 못했습니다.")
            return (False, False)

    except Exception as e:
        log_error(f"퀴즈 풀이 오류: {e}", exc_info=True)
        logging_queue.put(f"[오류] {str(e)}")
        return (False, False)

    finally:
        # 메모리 정리 (스크린샷, 이미지 객체 해제)
        try:
            # locals()로 변수 존재 확인 후 삭제
            local_vars = locals()
            for var_name in ['screenshot', 'debug_img', 'buttons_with_score', 'result', 'buf']:
                if var_name in local_vars and local_vars[var_name] is not None:
                    del local_vars[var_name]
            gc.collect()
        except Exception:
            pass


def solve_all_quizzes(window_region, logging_queue, total_questions=30):
    """
    모든 퀴즈 문제 풀이 (완료될 때까지 반복)

    Args:
        window_region: 퀴즈 창 영역
        logging_queue: 로깅 큐
        total_questions: 최대 문제 수 (안전장치)
    Returns:
        int: 풀이 완료한 문제 수
    """
    solved_count = 0

    for i in range(total_questions):
        log_info(f"--- 문제 {i+1} 풀이 시작 ---")
        logging_queue.put(f"--- 문제 {i+1} ---")

        result = solve_single_quiz(window_region, logging_queue)

        if isinstance(result, tuple):
            success, is_complete = result
        else:
            success = result
            is_complete = False

        if success:
            solved_count += 1
            log_info(f"문제 {i+1} 풀이 성공")

            # 마지막 문제면 종료
            if is_complete:
                log_info(f"=== 퀴즈 완료! 총 {solved_count}문제 풀이 ===")
                logging_queue.put(f"퀴즈 완료! {solved_count}문제 풀이")
                break
        else:
            log_warning(f"문제 {i+1} 풀이 실패")
            logging_queue.put(f"문제 {i+1} 풀이 실패")
            # 실패해도 다음으로 시도
            _click_next_button(window_region, logging_queue)

        time.sleep(0.8)  # 다음 문제 로드 대기

    return solved_count


# 기존 호환성 유지
def solve_quiz_with_ai(search_region, logging_queue, retry_count=0):
    """기존 인터페이스 호환용"""
    return solve_single_quiz(search_region, logging_queue)

# -*- coding: utf-8 -*-
# 파일 이름: src/hotkey_manager.py
# 역할: 전역 단축키 관리 (F9 시작, F10 중지)

import keyboard

# 전역 콜백 저장
_callbacks = {
    'start': None,
    'stop': None,
    'app': None  # App 인스턴스 (UI 스레드 안전 호출용)
}


def _safe_call(callback_name):
    """Tkinter 메인 스레드에서 안전하게 콜백 실행"""
    callback = _callbacks.get(callback_name)
    app = _callbacks.get('app')

    if callback and app:
        # Tkinter의 after()를 사용하여 메인 스레드에서 실행
        app.after(0, callback)
    elif callback:
        # app이 없으면 직접 호출 (fallback)
        callback()


def setup_hotkeys(start_func, stop_func, app_instance=None):
    """
    전역 단축키를 설정합니다.
    F9 키에는 start_func를, F10 키에는 stop_func를 연결합니다.

    Args:
        start_func: 자동화 시작 함수
        stop_func: 자동화 중지 함수
        app_instance: Tkinter App 인스턴스 (UI 스레드 안전 호출용)
    """
    _callbacks['start'] = start_func
    _callbacks['stop'] = stop_func
    _callbacks['app'] = app_instance

    # 이전 단축키 제거 (중복 방지)
    try:
        keyboard.remove_hotkey('f9')
        keyboard.remove_hotkey('f10')
    except KeyError:
        pass  # 처음 설정 시 제거할 것이 없음

    # 람다로 래핑하여 스레드 안전 호출
    keyboard.add_hotkey('f9', lambda: _safe_call('start'))
    keyboard.add_hotkey('f10', lambda: _safe_call('stop'))
    print("단축키 설정 완료: [F9] 시작, [F10] 중지")


def cleanup_hotkeys():
    """단축키 정리 (프로그램 종료 시)"""
    try:
        keyboard.remove_hotkey('f9')
        keyboard.remove_hotkey('f10')
    except KeyError:
        pass

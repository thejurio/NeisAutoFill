# -*- coding: utf-8 -*-
# 파일 이름: src/gemini_solver.py
# 역할: Google Gemini API 통신 (텍스트 + 이미지 지원)
# 수정일: 2026-01-29 (API 키 관리자 연동)

import os
import io
import base64
import time
import requests

# 재시도 설정
MAX_RETRIES = 3
RETRY_DELAY = 2  # 초
RETRYABLE_STATUS_CODES = {429, 500, 503}  # 재시도 가능한 HTTP 상태 코드

# --- API 키 관리자 ---
try:
    from api_manager import get_api_key, mark_key_exhausted
    API_MANAGER_AVAILABLE = True
except ImportError:
    API_MANAGER_AVAILABLE = False
    def get_api_key(): return None
    def mark_key_exhausted(): pass

# --- API 설정 ---
try:
    from config import GEMINI_API_KEY, GEMINI_MODEL, GEMINI_API_URL
except ImportError:
    GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY')
    GEMINI_MODEL = 'gemini-2.5-flash'
    GEMINI_API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"


def _get_active_api_key(provided_key=None):
    """
    사용할 API 키 결정

    우선순위:
    1. 함수에 직접 전달된 키
    2. API 관리자에서 제공하는 키
    3. 환경변수/config의 키 (레거시)
    """
    if provided_key:
        return provided_key

    if API_MANAGER_AVAILABLE:
        managed_key = get_api_key()
        if managed_key:
            return managed_key

    return GEMINI_API_KEY


def get_answer_from_gemini(api_key, question_text):
    """
    텍스트 질문을 Gemini에게 보내고 답변을 받습니다.
    """
    actual_key = _get_active_api_key(api_key)
    if not actual_key:
        return "오류 발생: GEMINI_API_KEY 환경변수가 설정되지 않았습니다."

    url = f"{GEMINI_API_URL}?key={actual_key}"
    headers = {'Content-Type': 'application/json'}

    data = {"contents": [{"parts": [{"text": question_text}]}]}

    try:
        response = requests.post(url, headers=headers, json=data, timeout=(5, 30))
        response.raise_for_status()
        response_data = response.json()
        answer = response_data['candidates'][0]['content']['parts'][0]['text']
        return answer.strip()

    except requests.exceptions.Timeout as e:
        return f"오류 발생: API 요청 타임아웃: {e}"
    except requests.exceptions.RequestException as e:
        return f"오류 발생: 네트워크 오류: {e}"
    except (KeyError, IndexError) as e:
        return f"오류 발생: 응답 파싱 실패: {e}"
    except Exception as e:
        return f"오류 발생: {e}"


def solve_quiz_from_image(pil_image, api_key=None):
    """
    이미지를 Gemini에게 보내서 퀴즈 정답과 클릭 위치를 받습니다.

    Args:
        pil_image: PIL.Image 객체 (퀴즈 화면 캡처)
        api_key: API 키 (None이면 환경변수 사용)

    Returns:
        dict: {
            'success': bool,
            'answer': str,  # 정답 (O, X, 1, 2, 3, 4 등)
            'answer_type': str,  # 'ox' 또는 'number'
            'click_position': tuple,  # (x, y) 상대 좌표 (있으면)
            'error': str  # 에러 메시지 (실패시)
        }
    """
    actual_key = _get_active_api_key(api_key)
    if not actual_key:
        return {
            'success': False,
            'error': 'API 키가 설정되지 않았습니다. 설정에서 API 키를 입력해주세요.'
        }

    # 이미지 크기 저장
    img_width, img_height = pil_image.size

    # 이미지를 base64로 인코딩
    img_byte_arr = io.BytesIO()
    pil_image.save(img_byte_arr, format='PNG')
    img_base64 = base64.b64encode(img_byte_arr.getvalue()).decode('utf-8')

    url = f"{GEMINI_API_URL}?key={actual_key}"
    headers = {'Content-Type': 'application/json'}

    # 프롬프트: 정답 + 클릭 위치 요청 (단일/복수 정답 지원)
    prompt = f"""이 이미지는 교원연수 퀴즈 화면입니다. 이미지 크기는 {img_width}x{img_height} 픽셀입니다.

문제를 분석하고 다음 형식으로 정확히 답해주세요:

[응답 형식]
정답: (O 또는 X 또는 번호)
유형: (single 또는 multiple)

[예시 - OX문제]
정답: X
유형: single

[예시 - 객관식 단일 정답]
정답: 2
유형: single

[예시 - 객관식 복수 정답 (모두 고르시오)]
정답: 1,3,4
유형: multiple

중요:
- "모두 고르시오", "모두 선택", "해당하는 것을 모두" 등의 문구가 있으면 복수 정답(multiple)입니다.
- 복수 정답인 경우 정답 번호를 쉼표로 구분하세요 (예: 1,3,4)
- 단일 정답인 경우 유형은 single입니다."""

    data = {
        "contents": [{
            "parts": [
                {"text": prompt},
                {
                    "inline_data": {
                        "mime_type": "image/png",
                        "data": img_base64
                    }
                }
            ]
        }]
    }

    # 재시도 로직 (429 에러 시 자동 키 전환)
    last_error = None
    answer_text = None

    while True:
        for attempt in range(MAX_RETRIES):
            try:
                response = requests.post(url, headers=headers, json=data, timeout=(5, 30))

                # 429 에러: 키 한도 초과 → 자동 키 전환
                if response.status_code == 429:
                    if API_MANAGER_AVAILABLE:
                        mark_key_exhausted()
                        new_key = get_api_key()
                        if new_key:
                            # 새 키로 URL 재구성 후 재시도
                            actual_key = new_key
                            url = f"{GEMINI_API_URL}?key={actual_key}"
                            time.sleep(RETRY_DELAY)
                            break  # 내부 for 루프 탈출, while로 돌아가서 새 키로 재시도
                        else:
                            # 사용 가능한 키 없음
                            return {'success': False, 'error': 'API 키가 모두 한도 초과되었습니다. 내일 다시 시도하거나 설정에서 개인 API 키를 등록해주세요.'}
                    else:
                        return {'success': False, 'error': 'API 사용량 초과'}

                # 500, 503 에러: 서버 문제 → 재시도
                if response.status_code in {500, 503}:
                    if attempt < MAX_RETRIES - 1:
                        time.sleep(RETRY_DELAY * (attempt + 1))
                        continue
                    else:
                        response.raise_for_status()

                response.raise_for_status()
                response_data = response.json()
                answer_text = response_data['candidates'][0]['content']['parts'][0]['text'].strip()
                break  # 성공 시 for 루프 탈출

            except requests.exceptions.Timeout as e:
                last_error = e
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY)
                    continue
                return {'success': False, 'error': f'타임아웃 ({MAX_RETRIES}회 재시도 실패)'}

            except requests.exceptions.HTTPError as e:
                if e.response is not None and e.response.status_code not in RETRYABLE_STATUS_CODES:
                    return _handle_http_error(e)
                last_error = e
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY * (attempt + 1))
                    continue
                return _handle_http_error(e)

            except requests.exceptions.RequestException as e:
                last_error = e
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY)
                    continue
                return {'success': False, 'error': f'네트워크 오류 ({MAX_RETRIES}회 재시도 실패): {e}'}

        else:
            # for 루프가 break 없이 끝남 (모든 재시도 실패)
            return {'success': False, 'error': f'API 호출 실패 ({MAX_RETRIES}회 재시도): {last_error}'}

        # answer_text가 있으면 성공, while 루프 탈출
        if answer_text:
            break

    # 응답 파싱 (단일/복수 정답 지원)
    try:
        import re

        # 정답 파싱 (쉼표로 구분된 복수 정답 지원)
        answer_match = re.search(r'정답[:\s]*([OXox0-9,\s]+)', answer_text)
        # 유형 파싱 (single/multiple)
        type_match = re.search(r'유형[:\s]*(single|multiple)', answer_text, re.IGNORECASE)

        is_multiple = False
        if type_match:
            is_multiple = type_match.group(1).lower() == 'multiple'

        if not answer_match:
            answer_upper = answer_text.upper()
            if 'O' in answer_upper and 'X' not in answer_upper:
                answer = 'O'
                answer_type = 'ox'
            elif 'X' in answer_upper:
                answer = 'X'
                answer_type = 'ox'
            else:
                number_match = re.search(r'(\d+)', answer_text)
                if number_match:
                    answer = number_match.group(1)
                    answer_type = 'multiple' if is_multiple else 'number'
                else:
                    return {
                        'success': False,
                        'error': '정답을 파싱할 수 없습니다.',
                        'raw_response': answer_text
                    }
        else:
            raw_answer = answer_match.group(1).upper().strip()
            if raw_answer in ['O', 'X']:
                answer = raw_answer
                answer_type = 'ox'
            elif ',' in raw_answer or is_multiple:
                # 복수 정답: "1,3,4" 또는 "1, 3, 4" 형식
                answers = [a.strip() for a in raw_answer.replace(' ', '').split(',') if a.strip().isdigit()]
                answer = ','.join(answers)
                answer_type = 'multiple'
            else:
                answer = raw_answer
                answer_type = 'number'

        result = {
            'success': True,
            'answer': answer,
            'answer_type': answer_type,
            'raw_response': answer_text
        }

        return result

    except (KeyError, IndexError) as e:
        return {'success': False, 'error': f'응답 파싱 실패: {e}'}
    except Exception as e:
        return {'success': False, 'error': f'파싱 오류: {e}'}


def _handle_http_error(e):
    """HTTP 에러를 사용자 친화적 메시지로 변환"""
    if e.response is not None:
        status_code = e.response.status_code
        error_messages = {
            429: ('API 사용량 초과: 다른 키로 전환합니다', 429),
            403: ('API 접근 권한 오류: API 키를 확인해주세요', 403),
            401: ('API 인증 실패: API 키가 유효하지 않습니다', 401),
            503: ('Gemini 서버 점검 중: 잠시 후 다시 시도해주세요', 503),
            500: ('Gemini 서버 오류: 잠시 후 다시 시도해주세요', 500),
        }

        # 429 에러 시 현재 키를 한도 초과로 표시
        if status_code == 429 and API_MANAGER_AVAILABLE:
            mark_key_exhausted()

        if status_code in error_messages:
            msg, code = error_messages[status_code]
            return {'success': False, 'error': msg, 'error_code': code}
    return {'success': False, 'error': f'HTTP 오류: {e}'}


# --- 테스트 코드 ---
if __name__ == '__main__':
    print("Gemini 솔버 모듈 테스트")
    print("=" * 40)

    if not GEMINI_API_KEY:
        print("[오류] GEMINI_API_KEY가 설정되지 않았습니다.")
    else:
        masked_key = GEMINI_API_KEY[:8] + "..." + GEMINI_API_KEY[-4:]
        print(f"API 키: {masked_key}")

        # 텍스트 테스트
        print("\n[텍스트 테스트]")
        sample = "대한민국의 수도는?\n1. 부산\n2. 서울\n3. 인천\n4. 대전"
        answer = get_answer_from_gemini(None, f"다음 문제의 정답 번호만 답하세요:\n{sample}")
        print(f"응답: {answer}")

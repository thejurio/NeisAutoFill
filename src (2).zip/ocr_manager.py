# -*- coding: utf-8 -*-
# 파일 이름: src/ocr_manager.py
# 역할: OCR 처리 통합 모듈 (Google Vision + Tesseract 폴백)

import os
import io
import numpy as np
import cv2
from PIL import Image

# 공통 유틸리티 (중복 코드 통합)
from utils.screenshot_utils import screenshot_pywin32

# --- Google Cloud Vision 설정 ---
GOOGLE_VISION_AVAILABLE = False
try:
    from google.cloud import vision
    GOOGLE_VISION_AVAILABLE = True
except ImportError:
    print("[경고] google-cloud-vision 미설치. pip install google-cloud-vision")

# --- Tesseract 설정 (폴백) ---
TESSERACT_AVAILABLE = False
try:
    import pytesseract
    # Windows에서 Tesseract 경로 설정
    tesseract_paths = [
        r'C:\Program Files\Tesseract-OCR\tesseract.exe',
        r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
        r'C:\Tesseract-OCR\tesseract.exe'
    ]
    for path in tesseract_paths:
        if os.path.exists(path):
            pytesseract.pytesseract.tesseract_cmd = path
            TESSERACT_AVAILABLE = True
            break

    if not TESSERACT_AVAILABLE:
        # PATH에서 찾기
        import shutil
        if shutil.which('tesseract'):
            TESSERACT_AVAILABLE = True
except ImportError:
    print("[경고] pytesseract 미설치. pip install pytesseract")

# --- Google Cloud 인증 설정 ---
if GOOGLE_VISION_AVAILABLE:
    try:
        from config import GOOGLE_CREDENTIALS_PATH
        if GOOGLE_CREDENTIALS_PATH:
            os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = GOOGLE_CREDENTIALS_PATH
    except ImportError:
        if not os.environ.get('GOOGLE_APPLICATION_CREDENTIALS'):
            print("[경고] GOOGLE_APPLICATION_CREDENTIALS 환경변수가 설정되지 않았습니다.")
            GOOGLE_VISION_AVAILABLE = False  # 인증 없으면 사용 불가

# OCR 방식 선택 로그
if GOOGLE_VISION_AVAILABLE:
    print("[OCR] Google Cloud Vision 사용 가능")
if TESSERACT_AVAILABLE:
    print("[OCR] Tesseract 폴백 사용 가능")
if not GOOGLE_VISION_AVAILABLE and not TESSERACT_AVAILABLE:
    print("[경고] OCR 엔진이 없습니다. Google Vision 또는 Tesseract를 설치해주세요.")


def _extract_text_with_vision(pil_image):
    """Google Cloud Vision API를 사용하여 이미지에서 텍스트를 추출합니다."""
    if not GOOGLE_VISION_AVAILABLE:
        return None

    try:
        client = vision.ImageAnnotatorClient()
        img_byte_arr = io.BytesIO()
        pil_image.save(img_byte_arr, format='PNG')
        content = img_byte_arr.getvalue()

        image = vision.Image(content=content)
        response = client.document_text_detection(image=image)

        if response.error.message:
            raise Exception(response.error.message)

        if response.full_text_annotation:
            return response.full_text_annotation.text.strip()
        return ""
    except Exception as e:
        print(f"[OCR] Vision API 오류: {e}")
        return None  # None 반환 시 폴백 시도


def _extract_text_with_tesseract(pil_image):
    """Tesseract를 사용하여 이미지에서 텍스트를 추출합니다."""
    if not TESSERACT_AVAILABLE:
        return None

    try:
        # 이미지 전처리 (OCR 정확도 향상)
        img_cv = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
        gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)

        # 대비 향상
        gray = cv2.convertScaleAbs(gray, alpha=1.5, beta=0)

        # 노이즈 제거
        gray = cv2.GaussianBlur(gray, (3, 3), 0)

        # 이진화
        _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        # Tesseract OCR 실행 (한국어 + 영어)
        # -l kor+eng: 한국어와 영어 인식
        # --psm 6: 단일 텍스트 블록 가정
        text = pytesseract.image_to_string(
            binary,
            lang='kor+eng',
            config='--psm 6'
        )
        return text.strip()
    except Exception as e:
        print(f"[OCR] Tesseract 오류: {e}")
        return None


def extract_text_from_image(pil_image):
    """
    이미지에서 텍스트를 추출합니다.
    Google Vision API 우선, 실패 시 Tesseract 폴백.
    """
    # 1. Google Vision 시도
    if GOOGLE_VISION_AVAILABLE:
        result = _extract_text_with_vision(pil_image)
        if result is not None and len(result) > 0:
            return result
        print("[OCR] Vision API 실패, Tesseract로 폴백...")

    # 2. Tesseract 폴백
    if TESSERACT_AVAILABLE:
        result = _extract_text_with_tesseract(pil_image)
        if result is not None:
            return result

    # 3. 모든 OCR 실패
    print("[OCR 오류] 사용 가능한 OCR 엔진이 없습니다.")
    return ""


def extract_text_from_region(region):
    """
    지정된 화면 영역에서 텍스트를 추출합니다.

    Args:
        region: (left, top, width, height) 튜플
    Returns:
        추출된 텍스트 문자열
    """
    screenshot_pil = screenshot_pywin32(region=region)
    return extract_text_from_image(screenshot_pil)


def _find_text_with_vision(screenshot_pil, region, target_text):
    """Google Vision API로 텍스트 위치 찾기"""
    if not GOOGLE_VISION_AVAILABLE:
        return None

    try:
        client = vision.ImageAnnotatorClient()
        img_byte_arr = io.BytesIO()
        screenshot_pil.save(img_byte_arr, format='PNG')
        content = img_byte_arr.getvalue()

        image = vision.Image(content=content)
        response = client.document_text_detection(image=image)

        if response.error.message:
            raise Exception(response.error.message)

        target_lower = target_text.lower().strip()

        # 단어 단위로 검색
        for page in response.full_text_annotation.pages:
            for block in page.blocks:
                for paragraph in block.paragraphs:
                    for word in paragraph.words:
                        word_text = ''.join([symbol.text for symbol in word.symbols])
                        word_lower = word_text.lower().strip()

                        # 부분 일치 확인
                        if target_lower in word_lower or word_lower in target_lower:
                            # 바운딩 박스 좌표 추출
                            vertices = word.bounding_box.vertices
                            x = vertices[0].x
                            y = vertices[0].y
                            width = vertices[2].x - vertices[0].x
                            height = vertices[2].y - vertices[0].y

                            # region의 left, top을 더해 절대 좌표로 변환
                            abs_x = region[0] + x
                            abs_y = region[1] + y

                            print(f"[OCR] Vision: 텍스트 '{target_text}' 발견 위치: ({abs_x}, {abs_y})")
                            return (abs_x, abs_y, width, height)

        return None  # 찾지 못함

    except Exception as e:
        print(f"[OCR] Vision API 텍스트 검색 오류: {e}")
        return None


def _find_text_with_tesseract(screenshot_pil, region, target_text):
    """Tesseract로 텍스트 위치 찾기"""
    if not TESSERACT_AVAILABLE:
        return None

    try:
        # 이미지 전처리
        img_cv = cv2.cvtColor(np.array(screenshot_pil), cv2.COLOR_RGB2BGR)
        gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)
        gray = cv2.convertScaleAbs(gray, alpha=1.5, beta=0)

        # Tesseract로 바운딩 박스 포함 데이터 추출
        data = pytesseract.image_to_data(
            gray,
            lang='kor+eng',
            config='--psm 6',
            output_type=pytesseract.Output.DICT
        )

        target_lower = target_text.lower().strip()

        # 각 단어별로 검색
        for i, text in enumerate(data['text']):
            if not text.strip():
                continue

            text_lower = text.lower().strip()

            # 부분 일치 확인
            if target_lower in text_lower or text_lower in target_lower:
                x = data['left'][i]
                y = data['top'][i]
                width = data['width'][i]
                height = data['height'][i]

                # region의 left, top을 더해 절대 좌표로 변환
                abs_x = region[0] + x
                abs_y = region[1] + y

                print(f"[OCR] Tesseract: 텍스트 '{target_text}' 발견 위치: ({abs_x}, {abs_y})")
                return (abs_x, abs_y, width, height)

        return None  # 찾지 못함

    except Exception as e:
        print(f"[OCR] Tesseract 텍스트 검색 오류: {e}")
        return None


def find_text_location_in_region(region, target_text, threshold=0.7):
    """
    지정된 화면 영역에서 특정 텍스트의 위치를 찾습니다.
    Google Vision API 우선, 실패 시 Tesseract 폴백.

    Args:
        region: (left, top, width, height) 튜플
        target_text: 찾을 텍스트
        threshold: 매칭 임계값 (0~1)
    Returns:
        찾은 경우: (x, y, width, height) 절대 좌표
        못 찾은 경우: None
    """
    screenshot_pil = screenshot_pywin32(region=region)

    # 1. Google Vision 시도
    if GOOGLE_VISION_AVAILABLE:
        result = _find_text_with_vision(screenshot_pil, region, target_text)
        if result is not None:
            return result
        print("[OCR] Vision API에서 찾지 못함, Tesseract로 폴백...")

    # 2. Tesseract 폴백
    if TESSERACT_AVAILABLE:
        result = _find_text_with_tesseract(screenshot_pil, region, target_text)
        if result is not None:
            return result

    # 3. 모든 방법 실패
    print(f"[OCR] 텍스트 '{target_text}'를 찾지 못했습니다.")
    return None


def find_problem_area_and_ocr(window_region):
    """
    창 스크린샷에서 문제 영역을 찾아 OCR을 수행하고, 텍스트를 반환합니다.
    """
    screenshot_pil = screenshot_pywin32(region=window_region)
    screenshot_cv = cv2.cvtColor(np.array(screenshot_pil), cv2.COLOR_RGB2BGR)

    gray = cv2.cvtColor(screenshot_cv, cv2.COLOR_BGR2GRAY)
    binary = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 11, 2)

    contours, _ = cv2.findContours(binary, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None

    candidate_contours = []
    window_area = window_region[2] * window_region[3]
    for c in contours:
        area = cv2.contourArea(c)
        if area < (window_area * 0.05) or area > (window_area * 0.95):
            continue
        candidate_contours.append(c)

    if not candidate_contours:
        problem_contour = np.array([[0, 0], [window_region[2], 0], [window_region[2], window_region[3]], [0, window_region[3]]])
    else:
        problem_contour = max(candidate_contours, key=cv2.contourArea)

    x, y, w, h = cv2.boundingRect(problem_contour)
    cropped_image_pil = screenshot_pil.crop((x, y, x + w, y + h))

    extracted_text = extract_text_from_image(cropped_image_pil)
    return extracted_text


# --- 독립 테스트용 코드 ---
if __name__ == '__main__':
    import time
    import pyautogui

    print("Google Vision OCR 통합 모듈 테스트를 시작합니다.")

    creds_path = os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')
    if not creds_path:
        print("\n[오류] GOOGLE_APPLICATION_CREDENTIALS 환경변수가 설정되지 않았습니다.")
        exit()

    print(f"인증 파일: {creds_path}")

    TARGET_WINDOW_TITLE = "전북교육연수포털"
    print(f"5초 후에 '{TARGET_WINDOW_TITLE}' 창을 감지하고 텍스트를 읽습니다...")
    time.sleep(5)

    active_window = pyautogui.getActiveWindow()
    if active_window and TARGET_WINDOW_TITLE in active_window.title:
        window_region = (active_window.left, active_window.top, active_window.width, active_window.height)
        print(f"'{active_window.title}' 창을 확인했습니다.")

        text = extract_text_from_region(window_region)

        print("\n--- OCR 인식 결과 ---")
        if text:
            print(text)
        else:
            print("텍스트를 인식하지 못했습니다.")
        print("--------------------")
    else:
        print("활성화된 창이 목표가 아닙니다.")

# -*- coding: utf-8 -*-
# 파일 이름: src/web_login.py
# 역할: 전북교육연수포털 로그인 자동화 (이미지 매칭 방식)

import pyautogui
import time
import os
import sys
import cv2
import numpy as np

# 공통 유틸리티
from utils.screenshot_utils import screenshot_pywin32, imread_korean_path

# 편리모드 지원 (PrintWindow 캡처 + SendMessage 클릭)
try:
    from utils.virtual_desktop import capture_window
    from utils.convenience_mode import post_click, screen_to_client
    import win32gui
    import win32api
    import win32con
    CONVENIENCE_AVAILABLE = True
except ImportError:
    CONVENIENCE_AVAILABLE = False
    def capture_window(hwnd, output_format='cv2'): return None

# 로거
try:
    from logger import log_info, log_error, log_debug, log_warning
except ImportError:
    def log_info(msg): print(f"[INFO] {msg}")
    def log_error(msg, exc_info=False): print(f"[ERROR] {msg}")
    def log_debug(msg): print(f"[DEBUG] {msg}")
    def log_warning(msg): print(f"[WARN] {msg}")


def _is_compiled():
    """Nuitka 또는 PyInstaller 빌드 여부"""
    return getattr(sys, 'frozen', False) or "__compiled__" in globals()


def get_base_path():
    """프로젝트 루트 경로"""
    if _is_compiled():
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# 설정
REF_FOLDER = os.path.join(get_base_path(), 'ref')
CONFIDENCE_THRESHOLD = 0.8
CONFIDENCE_THRESHOLD_GRAY = 0.85  # 그레이스케일 매칭용

# 템플릿 캐시
_template_cache = {}


def get_cached_template(filepath):
    """템플릿 이미지 캐싱"""
    if filepath not in _template_cache:
        if os.path.exists(filepath):
            _template_cache[filepath] = imread_korean_path(filepath)
        else:
            _template_cache[filepath] = None
    return _template_cache[filepath]


def find_image_gray(template_name, scale, screen_img=None, region=None, confidence=None, multiscale=False):
    """그레이스케일 이미지 매칭 (배경색 무시, 멀티스케일 지원)

    Args:
        template_name: 템플릿 파일명 (예: 'popup_x.png')
        scale: 화면 배율 (100, 125, 150) - 템플릿 폴더 선택용
        screen_img: 스크린샷 (None이면 새로 캡처)
        region: 검색 영역 (x, y, w, h) - None이면 전체 화면
        confidence: 신뢰도 임계값 (None이면 기본값)
        multiscale: True면 여러 크기로 시도 (해상도 차이 대응)

    Returns:
        (x, y, w, h) 또는 None
    """
    if confidence is None:
        confidence = CONFIDENCE_THRESHOLD_GRAY

    # 템플릿 로드 (100% 폴더 우선, 없으면 지정 배율)
    template_path = os.path.join(REF_FOLDER, '100', template_name)
    if not os.path.exists(template_path):
        template_path = os.path.join(REF_FOLDER, str(scale), template_name)

    template = get_cached_template(template_path)

    if template is None:
        log_warning(f"템플릿 없음: {template_path}")
        return None

    # 스크린샷
    if screen_img is None:
        screen_img = screenshot_pywin32(output_format='cv2')

    if screen_img is None:
        return None

    # 검색 영역 적용
    if region:
        rx, ry, rw, rh = region
        search_img = screen_img[ry:ry+rh, rx:rx+rw]
        offset_x, offset_y = rx, ry
    else:
        search_img = screen_img
        offset_x, offset_y = 0, 0

    # 그레이스케일 변환
    gray_screen = cv2.cvtColor(search_img, cv2.COLOR_BGR2GRAY)
    gray_template = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)

    # 멀티스케일 매칭
    if multiscale:
        # 다양한 스케일로 시도 (0.7x ~ 1.4x)
        scales_to_try = [0.7, 0.8, 0.85, 0.9, 0.95, 1.0, 1.05, 1.1, 1.15, 1.2, 1.3, 1.4]
        best_match = None
        best_val = 0
        best_scale = 1.0

        for s in scales_to_try:
            # 템플릿 리사이즈
            new_w = int(gray_template.shape[1] * s)
            new_h = int(gray_template.shape[0] * s)

            # 너무 작거나 화면보다 크면 스킵
            if new_w < 10 or new_h < 10:
                continue
            if new_w > gray_screen.shape[1] or new_h > gray_screen.shape[0]:
                continue

            resized = cv2.resize(gray_template, (new_w, new_h), interpolation=cv2.INTER_AREA)

            # 매칭
            result = cv2.matchTemplate(gray_screen, resized, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)

            del result

            if max_val > best_val:
                best_val = max_val
                best_match = (max_loc[0], max_loc[1], new_w, new_h)
                best_scale = s

        if best_match and best_val >= confidence:
            x, y, w, h = best_match
            x += offset_x
            y += offset_y
            log_debug(f"[find_image_gray] {template_name} 발견: ({x}, {y}), 스케일: {best_scale:.2f}x, 신뢰도: {best_val:.2f} (임계값: {confidence:.2f})")
            return (x, y, w, h)

        # 못 찾음 - 자세한 로그
        log_debug(f"[find_image_gray] {template_name} 미발견: 최고신뢰도 {best_val:.2f} < 임계값 {confidence:.2f} (스케일: {best_scale:.2f}x, 부족: {confidence - best_val:.2f})")
        return None

    # 단일 스케일 매칭 (기존 방식)
    result = cv2.matchTemplate(gray_screen, gray_template, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)

    del result

    if max_val >= confidence:
        h, w = template.shape[:2]
        x = max_loc[0] + offset_x
        y = max_loc[1] + offset_y
        log_debug(f"[find_image_gray] {template_name} 발견: ({x}, {y}), 신뢰도: {max_val:.2f} (임계값: {confidence:.2f})")
        return (x, y, w, h)

    # 못 찾음 - 자세한 로그
    log_debug(f"[find_image_gray] {template_name} 미발견: 최고신뢰도 {max_val:.2f} < 임계값 {confidence:.2f} (부족: {confidence - max_val:.2f})")
    return None


def find_image_gray_with_score(template_name, scale, screen_img=None, region=None, confidence=None):
    """그레이스케일 이미지 매칭 - 신뢰도 점수도 반환

    Args:
        template_name: 템플릿 파일명
        scale: 화면 배율
        screen_img: 스크린샷 (None이면 새로 캡처)
        region: 검색 영역
        confidence: 신뢰도 임계값 (None이면 기본값)

    Returns:
        ((x, y, w, h), score) 또는 (None, 0.0)
    """
    if confidence is None:
        confidence = CONFIDENCE_THRESHOLD_GRAY

    # 템플릿 로드
    template_path = os.path.join(REF_FOLDER, '100', template_name)
    if not os.path.exists(template_path):
        template_path = os.path.join(REF_FOLDER, str(scale), template_name)

    template = get_cached_template(template_path)

    if template is None:
        return (None, 0.0)

    # 스크린샷
    if screen_img is None:
        screen_img = screenshot_pywin32(output_format='cv2')

    if screen_img is None:
        return (None, 0.0)

    # 검색 영역 적용
    if region:
        rx, ry, rw, rh = region
        search_img = screen_img[ry:ry+rh, rx:rx+rw]
        offset_x, offset_y = rx, ry
    else:
        search_img = screen_img
        offset_x, offset_y = 0, 0

    # 그레이스케일 변환
    gray_screen = cv2.cvtColor(search_img, cv2.COLOR_BGR2GRAY)
    gray_template = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)

    # 매칭
    result = cv2.matchTemplate(gray_screen, gray_template, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)

    del result

    if max_val >= confidence:
        h, w = template.shape[:2]
        x = max_loc[0] + offset_x
        y = max_loc[1] + offset_y
        return ((x, y, w, h), max_val)

    return (None, max_val)


def find_image(template_name, scale, screen_img=None, region=None, confidence=None):
    """컬러 이미지 매칭

    Args:
        template_name: 템플릿 파일명
        scale: 화면 배율
        screen_img: 스크린샷 (None이면 새로 캡처)
        region: 검색 영역 (x, y, w, h)
        confidence: 신뢰도 임계값

    Returns:
        (x, y, w, h) 또는 None
    """
    if confidence is None:
        confidence = CONFIDENCE_THRESHOLD

    template_path = os.path.join(REF_FOLDER, str(scale), template_name)
    template = get_cached_template(template_path)

    if template is None:
        log_warning(f"템플릿 없음: {template_path}")
        return None

    if screen_img is None:
        screen_img = screenshot_pywin32(output_format='cv2')

    if screen_img is None:
        return None

    # 검색 영역 적용
    if region:
        rx, ry, rw, rh = region
        search_img = screen_img[ry:ry+rh, rx:rx+rw]
        offset_x, offset_y = rx, ry
    else:
        search_img = screen_img
        offset_x, offset_y = 0, 0

    result = cv2.matchTemplate(search_img, template, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)

    del result

    if max_val >= confidence:
        h, w = template.shape[:2]
        x = max_loc[0] + offset_x
        y = max_loc[1] + offset_y
        log_debug(f"[find_image] {template_name} 발견: ({x}, {y}), 신뢰도: {max_val:.2f}")
        return (x, y, w, h)

    return None


def click_center(location, delay=0.3, hwnd=None):
    """위치의 중앙 클릭

    Args:
        location: (x, y, w, h) 튜플
        delay: 클릭 후 대기 시간
        hwnd: 편리모드 창 핸들 (None이면 일반 pyautogui 클릭)
    """
    x, y, w, h = location
    center_x = x + w // 2
    center_y = y + h // 2

    if hwnd and CONVENIENCE_AVAILABLE:
        # 편리모드: 창 이미지 좌표 → 클라이언트 좌표 변환 후 SendMessage 클릭
        try:
            client_rect = win32gui.GetClientRect(hwnd)
            window_rect = win32gui.GetWindowRect(hwnd)

            # 테두리 두께
            border_x = ((window_rect[2] - window_rect[0]) - client_rect[2]) // 2
            # 타이틀바 높이 (창 높이 - 클라이언트 높이 - 하단 테두리)
            title_bar_y = (window_rect[3] - window_rect[1]) - client_rect[3] - border_x

            # 창 이미지 좌표 → 클라이언트 좌표
            client_x = center_x - border_x
            client_y = center_y - title_bar_y

            log_debug(f"[편리모드] 좌표 변환: ({center_x}, {center_y}) → 클라이언트({client_x}, {client_y})")
            post_click(hwnd, client_x, client_y)
        except Exception as e:
            log_warning(f"편리모드 클릭 좌표 변환 실패: {e}, 원래 좌표 사용")
            post_click(hwnd, center_x, center_y)
    else:
        # 일반 모드: pyautogui 클릭
        pyautogui.click(center_x, center_y)
        log_debug(f"클릭: ({center_x}, {center_y})")

    time.sleep(delay)


def close_popup(scale, log_queue=None, max_attempts=10, hwnd=None):
    """팝업 닫기 (그레이스케일 매칭으로 X 버튼 찾기)

    팝업이 여러 개 있을 수 있으므로 더 이상 없을 때까지 반복

    Args:
        scale: 화면 배율
        log_queue: 로그 큐
        max_attempts: 최대 시도 횟수
        hwnd: 편리모드 창 핸들

    Returns:
        int: 닫은 팝업 개수
    """
    # 페이지 로드 대기
    time.sleep(0.5)

    # 마우스를 화면 중앙으로 이동 (hover 상태 방지)
    screen_w, screen_h = pyautogui.size()
    center_x, center_y = screen_w // 2, screen_h // 2
    log_debug(f"[close_popup] 마우스 이동: ({center_x}, {center_y}), 화면크기: {screen_w}x{screen_h}")
    pyautogui.moveTo(center_x, center_y, duration=0.1)
    time.sleep(0.2)

    # 편리모드에서는 창 전체 영역 검색
    if hwnd and CONVENIENCE_AVAILABLE:
        try:
            rect = win32gui.GetWindowRect(hwnd)
            width = rect[2] - rect[0]
            height = rect[3] - rect[1]
            center_region = (width // 4, height // 4, width // 2, height // 2)
        except:
            center_region = None
    else:
        screen_w, screen_h = pyautogui.size()
        center_region = (screen_w // 4, screen_h // 4, screen_w // 2, screen_h // 2)

    closed_count = 0
    consecutive_not_found = 0

    for attempt in range(max_attempts):
        screen_img = _get_screen_img(hwnd)

        # 그레이스케일 매칭으로 닫기 버튼 찾기 (배율 폴더 이미지만 사용, 멀티스케일 끔)
        location = find_image_gray('popup_x.png', scale, screen_img, region=None, confidence=0.75, multiscale=False)

        if location:
            if log_queue:
                log_queue.put(f"팝업 X 버튼 발견 ({closed_count + 1}번째), 닫는 중...")
            click_center(location, hwnd=hwnd)
            closed_count += 1
            consecutive_not_found = 0
            time.sleep(0.5)
        else:
            consecutive_not_found += 1
            # 연속 2번 못 찾으면 종료
            if consecutive_not_found >= 2:
                log_debug(f"팝업 모두 닫음 (총 {closed_count}개)")
                break
            time.sleep(0.3)

    if closed_count > 0 and log_queue:
        log_queue.put(f"팝업 {closed_count}개 닫음")

    return closed_count


def find_browser_window(title_keyword="전북교육연수포털"):
    """브라우저 창 찾기

    Args:
        title_keyword: 창 제목에 포함된 키워드

    Returns:
        창 객체 또는 None
    """
    windows = pyautogui.getWindowsWithTitle(title_keyword)
    if windows:
        return windows[0]

    # 대체 키워드로 검색
    alt_keywords = ['jbstudy', '전북특별자치도교육청', 'Chrome', 'Edge']
    for keyword in alt_keywords:
        windows = pyautogui.getWindowsWithTitle(keyword)
        if windows:
            return windows[0]

    return None


def _get_screen_img(hwnd=None):
    """화면 또는 창 캡처 (편리모드 지원)"""
    if hwnd and CONVENIENCE_AVAILABLE:
        return capture_window(hwnd, output_format='cv2')
    return screenshot_pywin32(output_format='cv2')


def _activate_window(hwnd):
    """창 활성화 (화면 밖에 있어도 키 입력 가능하게)

    Windows foreground 전환 제한을 우회하기 위해 여러 방법 시도
    """
    if not hwnd or not CONVENIENCE_AVAILABLE:
        return

    import ctypes

    try:
        # 방법 1: 현재 foreground 윈도우의 스레드에 연결
        current_hwnd = win32gui.GetForegroundWindow()
        current_thread = ctypes.windll.user32.GetWindowThreadProcessId(current_hwnd, None)
        target_thread = ctypes.windll.user32.GetWindowThreadProcessId(hwnd, None)

        if current_thread != target_thread:
            ctypes.windll.user32.AttachThreadInput(current_thread, target_thread, True)

        # 방법 2: 창을 최상위로 설정 후 활성화
        win32gui.SetWindowPos(
            hwnd, win32con.HWND_TOPMOST,
            0, 0, 0, 0,
            win32con.SWP_NOMOVE | win32con.SWP_NOSIZE
        )

        # 방법 3: ShowWindow로 복원
        win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)

        # 방법 4: SetForegroundWindow 시도
        win32gui.SetForegroundWindow(hwnd)

        # 최상위 해제 (다른 창과 정상 동작하도록)
        win32gui.SetWindowPos(
            hwnd, win32con.HWND_NOTOPMOST,
            0, 0, 0, 0,
            win32con.SWP_NOMOVE | win32con.SWP_NOSIZE
        )

        # 스레드 연결 해제
        if current_thread != target_thread:
            ctypes.windll.user32.AttachThreadInput(current_thread, target_thread, False)

        time.sleep(0.15)
        log_debug(f"[편리모드] 창 활성화: hwnd={hwnd}")
    except Exception as e:
        log_warning(f"창 활성화 실패: {e}")


def login(username, password, scale, log_queue=None, max_wait=30, hwnd=None):
    """로그인 수행

    Args:
        username: 아이디
        password: 비밀번호
        scale: 화면 배율
        log_queue: 로그 큐
        max_wait: 최대 대기 시간 (초)
        hwnd: 편리모드 창 핸들 (None이면 일반 모드)

    Returns:
        bool: 성공 여부
    """
    log_info(f"[web_login] 로그인 시작 - 배율: {scale}%, 편리모드: {hwnd is not None}")

    # 0. 페이지 로딩 대기 후 팝업 닫기 (logout.png 가릴 수 있음)
    if log_queue:
        log_queue.put("페이지 로딩 대기 중...")
    time.sleep(3)  # 페이지 완전히 로드될 때까지 대기

    if log_queue:
        log_queue.put("팝업 확인 중...")
    close_popup(scale, log_queue, hwnd=hwnd)
    time.sleep(0.5)

    # 1. 로그인 상태 확인 (팝업 닫은 후)
    if log_queue:
        log_queue.put("로그인 상태 확인 중...")

    screen_img = _get_screen_img(hwnd)

    # 디버그: 캡처 성공 여부 확인
    if screen_img is None:
        log_error("[web_login] 화면 캡처 실패!")
        if log_queue:
            log_queue.put("[오류] 화면 캡처 실패 - 편리모드 확인 필요")
        return False

    log_debug(f"[web_login] 캡처 성공: {screen_img.shape[1]}x{screen_img.shape[0]}")

    logout_btn = find_image_gray('logout.png', scale, screen_img, confidence=0.90)

    if logout_btn:
        # 이미 로그인됨 → 스킵
        if log_queue:
            log_queue.put("이미 로그인 되어있습니다. 로그인 과정 스킵.")
        log_info("[web_login] 이미 로그인 상태 - 스킵")
        return True

    if log_queue:
        log_queue.put("로그인 시작...")

    start_time = time.time()

    # 2. 로그인 버튼 찾기 (헤더)
    screen_img = _get_screen_img(hwnd)
    login_btn = find_image_gray('login_btn.png', scale, screen_img)

    if login_btn:
        if log_queue:
            log_queue.put("로그인 버튼 클릭...")
        click_center(login_btn, hwnd=hwnd)
        time.sleep(1.5)
    else:
        log_warning("로그인 버튼을 찾을 수 없음 - 이미 로그인 페이지일 수 있음")

    # 3. 로그인 폼 대기 및 입력
    # 템플릿 파일 존재 여부 확인
    id_field_template = os.path.join(REF_FOLDER, str(scale), 'login_id_field.png')
    log_debug(f"[web_login] 템플릿 경로: {id_field_template}")
    log_debug(f"[web_login] 템플릿 존재: {os.path.exists(id_field_template)}")

    search_attempt = 0
    while time.time() - start_time < max_wait:
        search_attempt += 1
        screen_img = _get_screen_img(hwnd)

        log_debug(f"[web_login] 로그인 폼 검색 중... (시도 {search_attempt})")

        # 아이디 입력란 찾기
        id_field = find_image_gray('login_id_field.png', scale, screen_img)

        if id_field is None:
            log_debug(f"[web_login] login_id_field.png 미발견 (배율: {scale}%)")

        if id_field:
            if log_queue:
                log_queue.put("아이디 입력 중...")

            # 아이디 입력란 클릭 (SendMessage)
            click_center(id_field, hwnd=hwnd)
            time.sleep(0.3)

            # 편리모드: 창 활성화 (화면 밖에 있어도 키 입력 가능)
            _activate_window(hwnd)

            # 기존 내용 지우고 입력
            pyautogui.hotkey('ctrl', 'a')
            time.sleep(0.1)
            pyautogui.typewrite(username, interval=0.05)
            time.sleep(0.3)

            # 비밀번호 입력란 (Tab으로 이동)
            pyautogui.press('tab')
            time.sleep(0.2)

            if log_queue:
                log_queue.put("비밀번호 입력 중...")

            pyautogui.hotkey('ctrl', 'a')
            time.sleep(0.1)
            pyautogui.typewrite(password, interval=0.05)
            time.sleep(0.3)

            # 엔터로 로그인
            if log_queue:
                log_queue.put("로그인 버튼 클릭...")
            pyautogui.press('enter')
            time.sleep(2)

            # 로그인 성공 확인 (logout.png가 보이는지 확인 - 더 확실한 방법)
            if log_queue:
                log_queue.put("로그인 결과 확인 중...")

            # 페이지 로딩 대기 후 여러 번 확인
            for check_attempt in range(5):
                time.sleep(1)
                screen_img = _get_screen_img(hwnd)

                if screen_img is None:
                    log_warning(f"[web_login] 로그인 확인 중 캡처 실패 (시도 {check_attempt+1})")
                    continue

                # 방법 1: logout.png가 보이면 성공 (가장 확실)
                logout_btn = find_image_gray('logout.png', scale, screen_img, confidence=0.90)
                if logout_btn:
                    if log_queue:
                        log_queue.put("로그인 성공! (로그아웃 버튼 확인)")
                    log_info("[web_login] 로그인 성공 - logout.png 확인됨")
                    return True

                # 방법 2: login_btn.png가 안 보이고 login_id_field.png도 안 보이면 성공
                login_btn_after = find_image_gray('login_btn.png', scale, screen_img)
                login_form = find_image_gray('login_id_field.png', scale, screen_img)

                if login_btn_after is None and login_form is None:
                    if log_queue:
                        log_queue.put("로그인 성공! (로그인 폼 사라짐)")
                    log_info("[web_login] 로그인 성공 - 로그인 폼 사라짐")
                    return True

                log_debug(f"[web_login] 로그인 확인 중... (시도 {check_attempt+1}/5)")

            # 5번 시도 후에도 확인 안 되면 실패
            if log_queue:
                log_queue.put("[경고] 로그인 실패 - 아이디/비밀번호 확인 필요")
            log_warning("로그인 실패 - 로그인 버튼이 여전히 보임")
            return False

        time.sleep(1)

    if log_queue:
        log_queue.put("[오류] 로그인 타임아웃")
    log_error("로그인 타임아웃")
    return False


# 테스트용
if __name__ == '__main__':
    print("=== web_login.py 테스트 ===")
    print(f"REF_FOLDER: {REF_FOLDER}")

    # 배율 감지
    import win32api
    import win32gui
    import win32print
    import win32con

    hDC = win32gui.GetDC(0)
    dpi = win32print.GetDeviceCaps(hDC, win32con.LOGPIXELSX)
    win32gui.ReleaseDC(0, hDC)
    scale = int(dpi / 96 * 100)
    print(f"화면 배율: {scale}%")

    # 팝업 닫기 테스트
    print("\n팝업 닫기 테스트...")
    close_popup(scale)
    print("완료")

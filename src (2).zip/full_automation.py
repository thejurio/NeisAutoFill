# -*- coding: utf-8 -*-
# 파일 이름: src/full_automation.py
# 역할: 완전 자동화 - 로그인 → 강의실 진입 → 자동 수강

import time
import threading
import subprocess
import os
import sys
import webbrowser

import pyautogui
import win32gui
import win32print
import win32con

# 로그인 및 강의 탐색 모듈
from web_login import login, close_popup, find_browser_window
from course_navigator import (
    navigate_to_my_classroom, enter_classroom, wait_for_classroom_window,
    find_available_course, handle_course_completion, handle_study_start_process,
    click_center, scroll_down, scroll_up
)

# 자동 수강 모듈
import active_mode

# 로거
try:
    from logger import log_info, log_error, log_debug, log_warning
except ImportError:
    def log_info(msg): print(f"[INFO] {msg}")
    def log_error(msg, exc_info=False): print(f"[ERROR] {msg}")
    def log_debug(msg): print(f"[DEBUG] {msg}")
    def log_warning(msg): print(f"[WARN] {msg}")


# 전북교육연수포털 URL
PORTAL_URL = "https://www.jbstudy.kr"

# 편리모드용 창 관리 - main.py와 공유
# main.py에서 import하여 사용
_hidden_windows = {}  # {hwnd: (original_x, original_y)}


def get_hidden_windows():
    """숨긴 창 딕셔너리 반환 (main.py와 공유용)"""
    return _hidden_windows


def _hide_window(hwnd, log_queue=None):
    """창을 화면 밖으로 숨기기"""
    global _hidden_windows
    try:
        if not win32gui.IsWindow(hwnd):
            return False

        # 이미 숨긴 창이면 스킵
        if hwnd in _hidden_windows:
            return True

        # 현재 위치 저장
        rect = win32gui.GetWindowRect(hwnd)
        original_pos = (rect[0], rect[1])
        width = rect[2] - rect[0]
        height = rect[3] - rect[1]

        # 이미 화면 밖에 있으면 기본 복구 위치 사용 (Chrome --window-position 플래그 대응)
        if original_pos[0] < -2000 or original_pos[1] < -2000:
            original_pos = (0, 0)
            log_debug(f"[편리모드] 이미 화면 밖 - 기본 복구 위치 사용: {original_pos}")

        # 화면 밖으로 이동 (위쪽으로)
        win32gui.SetWindowPos(
            hwnd, win32con.HWND_TOP,
            0, -3000, width, height,
            win32con.SWP_NOSIZE | win32con.SWP_NOZORDER
        )

        _hidden_windows[hwnd] = original_pos
        log_debug(f"[편리모드] 창 숨김: hwnd={hwnd}, 복구위치={original_pos}")
        if log_queue:
            log_queue.put(f"[편리모드] 창 숨김됨")
        return True
    except Exception as e:
        log_warning(f"창 숨기기 실패: {e}")
        return False


def _show_all_windows(log_queue=None):
    """숨긴 모든 창 복귀"""
    global _hidden_windows
    for hwnd, (x, y) in list(_hidden_windows.items()):
        try:
            if win32gui.IsWindow(hwnd):
                rect = win32gui.GetWindowRect(hwnd)
                width = rect[2] - rect[0]
                height = rect[3] - rect[1]
                win32gui.SetWindowPos(
                    hwnd, win32con.HWND_TOP,
                    x, y, width, height,
                    win32con.SWP_NOSIZE | win32con.SWP_NOZORDER
                )
                log_debug(f"[편리모드] 창 복귀: hwnd={hwnd}")
        except:
            pass
    _hidden_windows.clear()
    if log_queue:
        log_queue.put("[편리모드] 모든 창 복귀됨")


def _hide_related_windows(log_queue=None):
    """연수 관련 모든 창 숨기기 (Chrome, 강의실 등)"""
    keywords = ['jbstudy', '전북교육연수포털', '전북특별자치도교육청', '강의실', 'Chrome']

    def callback(hwnd, _):
        if win32gui.IsWindowVisible(hwnd):
            try:
                title = win32gui.GetWindowText(hwnd)
                for kw in keywords:
                    if kw.lower() in title.lower():
                        _hide_window(hwnd, log_queue)
                        break
            except:
                pass
        return True

    win32gui.EnumWindows(callback, None)


def _check_exit_reason(log_queue):
    """log_queue에서 종료 원인 메시지 확인

    active_mode에서 보낸 @@MSG_한도도달@@ 또는 @@MSG_강의완료@@ 메시지를 찾습니다.

    Args:
        log_queue: 로그 큐

    Returns:
        'limit': 일일 한도 도달
        'complete': 강의 완료
        'unknown': 알 수 없음
    """
    import queue

    # 큐의 모든 메시지를 임시로 가져와서 확인
    messages = []
    exit_reason = 'unknown'

    try:
        while True:
            try:
                msg = log_queue.get_nowait()
                messages.append(msg)

                # 종료 원인 확인
                if msg == "@@MSG_한도도달@@":
                    exit_reason = 'limit'
                elif msg == "@@MSG_강의완료@@":
                    exit_reason = 'complete'
            except queue.Empty:
                break
    except:
        pass

    # 메시지를 다시 큐에 넣기 (순서 유지)
    for msg in messages:
        # 내부 신호 메시지는 다시 넣지 않음
        if not msg.startswith("@@"):
            log_queue.put(msg)

    return exit_reason


def get_display_scale():
    """화면 배율 감지"""
    try:
        hDC = win32gui.GetDC(0)
        dpi = win32print.GetDeviceCaps(hDC, win32con.LOGPIXELSX)
        win32gui.ReleaseDC(0, hDC)
        scale = int(dpi / 96 * 100)

        # 지원하는 배율로 맞추기
        if scale <= 100:
            return 100
        elif scale <= 125:
            return 125
        else:
            return 150
    except Exception as e:
        log_warning(f"배율 감지 실패: {e}, 100% 사용")
        return 100


def open_browser_with_flags(url=PORTAL_URL, log_queue=None, start_hidden=False):
    """Chrome을 편리모드 플래그와 함께 열기

    Args:
        url: 열 URL
        log_queue: 로그 큐
        start_hidden: True면 처음부터 화면 밖에서 시작

    Returns:
        bool: 성공 여부
    """
    if log_queue:
        msg = f"Chrome 열기 (플래그 포함): {url}"
        if start_hidden:
            msg += " [화면 밖 시작]"
        log_queue.put(msg)

    log_info(f"[full_automation] Chrome 열기 (플래그 포함, hidden={start_hidden}): {url}")

    try:
        # Chrome 경로 찾기
        chrome_paths = [
            os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
        ]

        chrome_path = None
        log_debug("[open_browser_with_flags] Chrome 경로 탐색 시작")
        for path in chrome_paths:
            log_debug(f"[open_browser_with_flags] 확인: {path}")
            if os.path.exists(path):
                chrome_path = path
                log_debug(f"[open_browser_with_flags] Chrome 발견: {path}")
                break

        if not chrome_path:
            log_error("[open_browser_with_flags] Chrome을 찾을 수 없습니다.")
            if log_queue:
                log_queue.put("[오류] Chrome을 찾을 수 없습니다.")
            return False

        # 프로필 디렉토리 (완전 자동화 전용)
        profile_dir = os.path.join(os.path.expandvars("%TEMP%"), "DooClick_Chrome_Profile")
        log_debug(f"[open_browser_with_flags] 프로필 디렉토리: {profile_dir}")

        # 편리모드 플래그 (창 숨김 시에도 렌더링 유지)
        flags = [
            f"--user-data-dir={profile_dir}",
            "--disable-backgrounding-occluded-windows",
            "--disable-renderer-backgrounding",
            "--disable-features=CalculateNativeWinOcclusion",
            "--disable-background-timer-throttling",
        ]

        # 편리모드: 처음부터 화면 밖에서 시작
        if start_hidden:
            flags.append("--window-position=-3000,0")
            log_debug("[open_browser_with_flags] 화면 밖 시작 플래그 추가")

        # Chrome 실행
        cmd = [chrome_path] + flags + [url]
        log_debug(f"[open_browser_with_flags] 실행 명령: {' '.join(cmd)}")
        log_info(f"[full_automation] Chrome 실행 명령: {' '.join(cmd[:3])}...")

        process = subprocess.Popen(cmd)
        log_debug(f"[open_browser_with_flags] 프로세스 시작: PID={process.pid}")

        log_debug("[open_browser_with_flags] 브라우저 로드 대기 (4초)")
        time.sleep(4)  # 브라우저 로드 대기 (플래그 포함 시 더 오래 걸림)

        log_debug("[open_browser_with_flags] Chrome 열기 성공")
        return True

    except Exception as e:
        log_error(f"[open_browser_with_flags] Chrome 열기 실패: {e}")
        if log_queue:
            log_queue.put(f"[오류] Chrome 열기 실패: {e}")
        return False


def run_full_automation(username, password, log_queue, stop_event,
                        auto_next_course=False, url=None, use_convenience=False):
    """완전 자동화 실행

    Args:
        username: 로그인 아이디
        password: 로그인 비밀번호
        log_queue: 로그 큐
        stop_event: 중지 이벤트
        auto_next_course: 강의 완료 후 다음 강의 자동 시작
        url: 연수원 URL (기본값: PORTAL_URL)
        use_convenience: 편리모드 사용 여부
    """
    import datetime
    start_time = datetime.datetime.now()

    log_info("[full_automation] ========== 완전 자동화 시작 ==========")
    log_debug(f"[full_automation] 시작 시간: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    log_debug(f"[full_automation] 파라미터: username={username[:2]}***, auto_next={auto_next_course}, convenience={use_convenience}")
    log_queue.put("=== 완전 자동화 시작 ===")

    if use_convenience:
        log_queue.put("편리모드 활성화됨")
        log_debug("[full_automation] 편리모드 활성화 - 창 숨김 모드")

    # URL 기본값
    if not url:
        url = PORTAL_URL
    log_debug(f"[full_automation] 대상 URL: {url}")

    scale = get_display_scale()
    log_queue.put(f"화면 배율: {scale}%")
    log_debug(f"[full_automation] 화면 배율 감지: {scale}%")

    try:
        # 1. Chrome을 플래그와 함께 열기 (항상 새 창)
        log_debug("[full_automation] [단계 1/8] Chrome 브라우저 열기")
        if stop_event.is_set():
            log_debug("[full_automation] 중지 이벤트 감지 - 종료")
            return

        log_queue.put("Chrome 열기 (편리모드 플래그 포함)...")
        log_debug(f"[full_automation] open_browser_with_flags 호출: url={url}, start_hidden={use_convenience}")

        if not open_browser_with_flags(url, log_queue, start_hidden=use_convenience):
            log_queue.put("[오류] Chrome 열기 실패")
            log_error("[full_automation] Chrome 열기 실패 - 자동화 중단")
            return

        log_debug("[full_automation] Chrome 열기 성공, 2초 대기 후 창 탐색")
        time.sleep(2)
        browser_window = find_browser_window()
        log_debug(f"[full_automation] find_browser_window 결과: {browser_window}")

        # 편리모드: Chrome 창 숨기기
        if use_convenience and browser_window:
            log_debug(f"[full_automation] 편리모드 - 창 숨기기 시도: hwnd={browser_window._hWnd}")
            _hide_window(browser_window._hWnd, log_queue)
            log_queue.put("[편리모드] 브라우저 창 숨김")

        # 브라우저 창 핸들 (편리모드용)
        browser_hwnd = browser_window._hWnd if browser_window else None
        log_debug(f"[full_automation] 브라우저 hwnd: {browser_hwnd}")

        if browser_window:
            log_queue.put(f"브라우저 창 발견: {browser_window.title[:30]}...")
            log_debug(f"[full_automation] 브라우저 창 발견: title='{browser_window.title}'")
            # 편리모드가 아닐 때만 활성화
            if not use_convenience:
                try:
                    log_debug("[full_automation] 브라우저 창 활성화 시도")
                    browser_window.activate()
                    time.sleep(0.5)
                except Exception as e:
                    log_warning(f"[full_automation] 브라우저 활성화 실패: {e}")
        else:
            log_warning("[full_automation] 브라우저 창을 찾지 못함!")

        # 2. 로그인
        log_debug("[full_automation] [단계 2/8] 로그인 진행")
        if stop_event.is_set():
            log_debug("[full_automation] 중지 이벤트 감지 - 종료")
            return

        log_queue.put("로그인 진행 중...")
        # 편리모드일 때 hwnd 전달
        login_hwnd = browser_hwnd if use_convenience else None
        log_debug(f"[full_automation] login() 호출: hwnd={login_hwnd}, scale={scale}")

        login_start = time.time()
        login_result = login(username, password, scale, log_queue, hwnd=login_hwnd)
        login_elapsed = time.time() - login_start
        log_debug(f"[full_automation] login() 결과: {login_result}, 소요시간: {login_elapsed:.2f}초")

        if not login_result:
            log_queue.put("[오류] 로그인 실패")
            log_error("[full_automation] 로그인 실패 - 자동화 중단")
            return

        log_debug("[full_automation] 로그인 성공!")
        time.sleep(1)

        # 3. 수강과정 페이지로 이동
        log_debug("[full_automation] [단계 3/8] 수강과정 페이지 이동")
        if stop_event.is_set():
            log_debug("[full_automation] 중지 이벤트 감지 - 종료")
            return

        log_queue.put("수강과정 페이지로 이동 중...")
        nav_hwnd = browser_hwnd if use_convenience else None
        log_debug(f"[full_automation] navigate_to_my_classroom() 호출: hwnd={nav_hwnd}")

        nav_start = time.time()
        nav_result = navigate_to_my_classroom(scale, log_queue, hwnd=nav_hwnd)
        nav_elapsed = time.time() - nav_start
        log_debug(f"[full_automation] navigate_to_my_classroom() 결과: {nav_result}, 소요시간: {nav_elapsed:.2f}초")

        if not nav_result:
            log_queue.put("[오류] 수강과정 페이지 이동 실패")
            log_error("[full_automation] 수강과정 페이지 이동 실패 - 자동화 중단")
            return

        log_debug("[full_automation] 수강과정 페이지 이동 성공!")
        time.sleep(1)

        # 강의 반복 처리 (auto_next_course가 True면 계속)
        course_count = 0
        log_debug(f"[full_automation] 강의 반복 처리 시작 (auto_next_course={auto_next_course})")

        while not stop_event.is_set():
            course_count += 1
            log_queue.put(f"=== {course_count}번째 강의 처리 ===")
            log_debug(f"[full_automation] ===== 강의 #{course_count} 처리 시작 =====")

            # 4. 강의 찾기 및 선택
            log_debug("[full_automation] [단계 4/8] 수강 가능한 강의 탐색")
            log_queue.put("수강 가능한 강의 찾는 중...")

            # 페이지 상단으로 (편리모드: 창 활성화 필요)
            if use_convenience:
                import win32gui
                try:
                    log_debug(f"[full_automation] 편리모드 - 창 활성화: hwnd={browser_hwnd}")
                    win32gui.SetForegroundWindow(browser_hwnd)
                except Exception as e:
                    log_warning(f"[full_automation] 창 활성화 실패: {e}")

            log_debug("[full_automation] 페이지 상단으로 스크롤")
            scroll_up(5)
            time.sleep(0.5)

            log_debug("[full_automation] find_available_course() 호출")
            find_start = time.time()
            btn_type, location = find_available_course(scale, log_queue, hwnd=browser_hwnd if use_convenience else None)
            find_elapsed = time.time() - find_start
            log_debug(f"[full_automation] find_available_course() 결과: btn_type={btn_type}, location={location}, 소요시간: {find_elapsed:.2f}초")

            if location is None:
                log_queue.put("[알림] 수강 가능한 강의가 없습니다. (모두 완료)")
                log_debug("[full_automation] 수강 가능한 강의 없음 - 루프 종료")
                break

            # 5. 강의 버튼 클릭
            log_debug("[full_automation] [단계 5/8] 강의 버튼 클릭")
            btn_name = "이어보기" if btn_type == 'continue' else "학습하기"
            log_queue.put(f"'{btn_name}' 버튼 클릭...")
            log_debug(f"[full_automation] '{btn_name}' 버튼 클릭: location={location}")
            click_center(location, hwnd=browser_hwnd if use_convenience else None)
            log_debug("[full_automation] 클릭 후 2초 대기")
            time.sleep(2)

            # 6. 학습하기인 경우 추가 과정 처리
            if btn_type == 'start':
                log_debug("[full_automation] [단계 6/8] 학습하기 추가 과정 처리")
                log_queue.put("학습하기 추가 과정 처리 중...")
                log_debug("[full_automation] handle_study_start_process() 호출")
                handle_study_start_process(scale, log_queue, hwnd=browser_hwnd if use_convenience else None)
                log_debug("[full_automation] handle_study_start_process() 완료")
            else:
                log_debug("[full_automation] [단계 6/8] 이어보기 - 추가 과정 없음")

            # 7. 강의실 창 대기 (편리모드: 발견 즉시 숨김)
            log_debug("[full_automation] [단계 7/8] 강의실 창 대기")
            if stop_event.is_set():
                log_debug("[full_automation] 중지 이벤트 감지 - 종료")
                return

            log_queue.put("강의실 창 대기 중...")
            log_debug(f"[full_automation] wait_for_classroom_window() 호출: timeout=30, hide_immediately={use_convenience}")

            wait_start = time.time()
            classroom_window = wait_for_classroom_window(
                timeout=30,
                hide_immediately=use_convenience,  # 편리모드면 즉시 숨김
                log_queue=log_queue,
                hidden_windows_dict=_hidden_windows if use_convenience else None  # 복구용 저장
            )
            wait_elapsed = time.time() - wait_start
            log_debug(f"[full_automation] wait_for_classroom_window() 결과: {classroom_window}, 소요시간: {wait_elapsed:.2f}초")

            if classroom_window is None:
                log_queue.put("[오류] 강의실 창이 열리지 않음")
                log_warning("[full_automation] 강의실 창 미발견 - 팝업 확인 후 재시도")
                # 팝업 확인 후 재시도
                log_debug("[full_automation] close_popup() 호출")
                close_popup(scale, log_queue)
                time.sleep(1)

                log_debug("[full_automation] 강의실 창 재탐색 (timeout=10)")
                classroom_window = wait_for_classroom_window(
                    timeout=10,
                    hide_immediately=use_convenience,
                    log_queue=log_queue,
                    hidden_windows_dict=_hidden_windows if use_convenience else None
                )

                if classroom_window is None:
                    log_queue.put("[오류] 강의실 창 열기 실패, 다음 강의로...")
                    log_error("[full_automation] 강의실 창 열기 최종 실패 - 다음 강의로 이동")
                    continue

            log_queue.put("강의실 창 열림!")
            log_debug(f"[full_automation] 강의실 창 열림: {classroom_window}")

            # 편리모드: 관련 창 모두 숨기기 (강의실은 이미 숨겨짐, 나머지 처리)
            if use_convenience:
                log_debug("[full_automation] 편리모드 - 관련 창 숨기기")
                time.sleep(0.5)  # 짧은 대기
                _hide_related_windows(log_queue)
                log_debug(f"[full_automation] 숨긴 창 목록: {list(_hidden_windows.keys())}")
            else:
                log_debug("[full_automation] 일반모드 - 창 안정화 2초 대기")
                time.sleep(2)  # 일반 모드: 창 안정화 대기

            # 8. 자동 수강 시작
            log_debug("[full_automation] [단계 8/8] 자동 수강 시작")
            if stop_event.is_set():
                log_debug("[full_automation] 중지 이벤트 감지 - 종료")
                return

            log_queue.put("=== 자동 수강 시작 ===")
            log_info("[full_automation] ===== active_mode 시작 =====")

            # active_mode 실행용 별도 stop_event (완료 감지용)
            active_stop_event = threading.Event()
            log_debug("[full_automation] active_mode stop_event 생성")

            # 종료 원인 저장용 딕셔너리 (GUI log_queue 경쟁 문제 해결)
            result_dict = {'exit_reason': 'unknown'}

            # active_mode를 별도 스레드로 실행 (메인 stop_event 감시를 위해)
            active_start = time.time()
            log_debug("[full_automation] active_mode.start_active_mode_loop() 스레드 시작")

            active_thread = threading.Thread(
                target=active_mode.start_active_mode_loop,
                args=(log_queue, active_stop_event, result_dict),
                daemon=True
            )
            active_thread.start()

            # active_mode 완료 또는 사용자 중지까지 대기
            while active_thread.is_alive():
                # 0.5초마다 메인 stop_event 체크
                if stop_event.is_set():
                    log_debug("[full_automation] 사용자 중지 감지 - active_mode 중지")
                    active_stop_event.set()  # active_mode도 중지
                    active_thread.join(timeout=3)
                    break
                active_thread.join(timeout=0.5)

            active_elapsed = time.time() - active_start
            log_debug(f"[full_automation] active_mode 종료: 소요시간 {active_elapsed:.1f}초 ({active_elapsed/60:.1f}분)")

            # 9. 종료 원인 확인 (한도 도달 vs 강의 완료)
            log_debug("[full_automation] 종료 원인 확인")
            # result_dict에서 종료 원인 확인 (log_queue 경쟁 문제 해결)
            exit_reason = result_dict.get('exit_reason', 'unknown')
            log_info(f"[full_automation] active_mode 종료 원인: {exit_reason}")
            log_debug(f"[full_automation] exit_reason={exit_reason}")

            # 외부 stop_event 체크
            if stop_event.is_set():
                log_queue.put("사용자가 중지했습니다.")
                log_debug("[full_automation] 사용자 중지 - 자동화 종료")
                return

            # 일일 한도 도달 시 → 종료
            if exit_reason == 'limit':
                log_queue.put("=== 일일 한도 도달 - 자동화 종료 ===")
                log_info("[full_automation] 일일 한도 도달, 종료")
                log_debug("[full_automation] 한도 도달로 루프 종료")
                break

            # 강의 완료 시 → 설문/시험/이수처리 진행
            if exit_reason == 'complete':
                log_queue.put("=== 강의 완료 후 처리 ===")
                log_debug("[full_automation] 강의 완료 - 후처리 시작")

                # 강의실 창에서 바로 처리 (브라우저 전환 안 함)
                log_debug("[full_automation] 강의실 창에서 후처리 시작 (2초 대기)")
                time.sleep(2)

                # 강의 완료 처리 (강의실버튼 → 설문 → 강의실버튼 → 문제풀이 → 이수처리 → 나이스전송)
                log_debug("[full_automation] handle_course_completion() 호출")
                handle_course_completion(scale, log_queue)
                log_debug("[full_automation] handle_course_completion() 완료")

                # 다음 강의 진행 여부
                if not auto_next_course:
                    log_queue.put("강의 완료! (다음 강의 자동 시작 비활성화)")
                    log_debug("[full_automation] auto_next_course=False, 루프 종료")
                    break

                # 이미 강의 목록에 있으니 바로 다음 강의 찾기
                log_queue.put("다음 강의 확인 중...")
                log_debug("[full_automation] 이미 강의 목록 - 바로 다음 강의 찾기")
                time.sleep(1)

                # 루프 계속 → 4번(강의 찾기)으로
                continue

            else:
                # 알 수 없는 종료 (타임아웃 등)
                log_queue.put("[경고] 예상치 못한 종료. 다음 강의 시도...")
                log_warning(f"[full_automation] 알 수 없는 종료 원인: {exit_reason}")
                time.sleep(2)
                if not navigate_to_my_classroom(scale, log_queue):
                    log_error("[full_automation] 복구 실패 - 루프 종료")
                    break

    except Exception as e:
        log_error(f"완전 자동화 오류: {e}", exc_info=True)
        log_queue.put(f"[오류] {str(e)}")
        log_debug(f"[full_automation] 예외 발생: {type(e).__name__}: {e}")

    finally:
        import datetime
        end_time = datetime.datetime.now()
        total_elapsed = (end_time - start_time).total_seconds()

        # 편리모드: 숨긴 창들 모두 복귀
        if use_convenience and _hidden_windows:
            log_debug(f"[full_automation] 숨긴 창 복구: {len(_hidden_windows)}개")
            _show_all_windows(log_queue)

        log_queue.put("=== 완전 자동화 종료 ===")
        log_info("[full_automation] ========== 완전 자동화 종료 ==========")
        log_debug(f"[full_automation] 종료 시간: {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
        log_debug(f"[full_automation] 총 소요시간: {total_elapsed:.1f}초 ({total_elapsed/60:.1f}분)")


class FullAutomationManager:
    """완전 자동화 관리 클래스"""

    def __init__(self):
        self.thread = None
        self.stop_event = threading.Event()
        self.is_running = False

    def start(self, username, password, log_queue,
              auto_next_course=False, url=None, use_convenience=False):
        """완전 자동화 시작"""
        if self.is_running:
            log_queue.put("[알림] 이미 실행 중입니다.")
            return False

        self.stop_event.clear()
        self.is_running = True

        self.thread = threading.Thread(
            target=self._run,
            args=(username, password, log_queue, auto_next_course, url, use_convenience),
            daemon=True
        )
        self.thread.start()
        return True

    def _run(self, username, password, log_queue, auto_next_course, url, use_convenience):
        """내부 실행 함수"""
        try:
            run_full_automation(
                username, password, log_queue, self.stop_event,
                auto_next_course, url, use_convenience
            )
        finally:
            self.is_running = False

    def stop(self, log_queue=None):
        """완전 자동화 중지"""
        if not self.is_running:
            if log_queue:
                log_queue.put("[알림] 실행 중이 아닙니다.")
            return

        self.stop_event.set()
        if log_queue:
            log_queue.put("완전 자동화 중지 요청...")

        # 스레드 종료 대기
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=5)

        self.is_running = False


# 전역 매니저 인스턴스
_manager = None


def get_automation_manager():
    """전역 매니저 인스턴스 반환"""
    global _manager
    if _manager is None:
        _manager = FullAutomationManager()
    return _manager


# 테스트용
if __name__ == '__main__':
    from queue import Queue

    print("=== full_automation.py 테스트 ===")
    print(f"화면 배율: {get_display_scale()}%")

    # 테스트 실행 (실제 로그인 정보 필요)
    # log_queue = Queue()
    # stop_event = threading.Event()
    # run_full_automation("test_id", "test_pw", log_queue, stop_event)

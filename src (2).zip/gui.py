# -*- coding: utf-8 -*-
# 파일 이름: src/gui.py
# 역할: DooClick V4 GUI (탭 기반 UI)

import tkinter as tk
from tkinter import ttk, messagebox
from queue import Queue
import json
import os
import sys

# API 관리자
try:
    from api_manager import (
        get_api_manager, save_user_api_key, get_user_key_display
    )
    API_MANAGER_AVAILABLE = True
except ImportError:
    API_MANAGER_AVAILABLE = False

# 계정 관리자
try:
    from credential_manager import (
        get_credential_manager, save_credentials, get_credentials, has_credentials, clear_credentials
    )
    CREDENTIAL_MANAGER_AVAILABLE = True
except ImportError:
    CREDENTIAL_MANAGER_AVAILABLE = False
    def get_credentials(): return (None, None)
    def has_credentials(): return False
    def save_credentials(u, p): return False
    def clear_credentials(): return False

# 설정 파일 경로 (config.py의 경로 함수 사용)
from config import get_project_root
SETTINGS_FILE = str(get_project_root() / 'settings.json')

# 기본 설정값
DEFAULT_SETTINGS = {
    'confidence_threshold': 0.80,      # 일반 버튼 신뢰도
    'confidence_threshold_text': 0.65, # 텍스트 이미지 신뢰도
    'selected_site': '전북교육연수포털', # 선택된 연수원
    'custom_url': '',                   # 직접 입력 URL
    'skip_convenience_confirm': False   # 편리모드 안내 다시 보지 않기
}


def load_settings():
    """설정 파일 로드"""
    try:
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                settings = json.load(f)
                # 누락된 키에 기본값 적용
                for key, value in DEFAULT_SETTINGS.items():
                    if key not in settings:
                        settings[key] = value
                return settings
    except Exception as e:
        print(f"[경고] 설정 로드 실패: {e}")
    return DEFAULT_SETTINGS.copy()


def save_settings(settings):
    """설정 파일 저장"""
    try:
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump(settings, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"[오류] 설정 저장 실패: {e}")
        return False


class App(tk.Tk):
    def __init__(self, start_callback, stop_callback):
        super().__init__()
        self.start_callback = start_callback
        self.stop_callback = stop_callback
        self.quiz_callback = None  # 퀴즈 풀이 콜백
        self.quiz_stop_callback = None  # 퀴즈 중지 콜백
        self.convenience_start_callback = None  # 편리모드 시작 콜백 (일반 자동화 - 강의실만)
        self.convenience_start_all_callback = None  # 편리모드 시작 콜백 (완전자동화 - 모든 창)
        self.convenience_stop_callback = None  # 편리모드 종료 콜백
        self.is_convenience_mode = False  # 편리모드 상태
        self.full_auto_start_callback = None  # 완전 자동화 시작 콜백
        self.full_auto_stop_callback = None  # 완전 자동화 중지 콜백
        self.is_full_auto_running = False  # 완전 자동화 실행 상태

        # 예약 실행 관련 변수 (UI 생성 전 초기화)
        self.is_scheduled = False
        self.scheduled_time = None
        self.schedule_random_offset = 0
        self.schedule_check_id = None

        # 창 제목 설정
        self.title("DooClick")

        # 아이콘 설정 (제목표시줄 + 작업표시줄)
        self._set_app_icon()

        self.geometry("450x500")
        self.resizable(False, False)

        # 로그 큐
        self.log_queue = Queue()

        # 메인 프레임
        self.main_frame = ttk.Frame(self, padding="10")
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        # 하단 상태바 (먼저 생성해서 하단 공간 확보)
        self._create_status_bar()

        # 탭 컨트롤 생성
        self.notebook = ttk.Notebook(self.main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        # 탭 1: 자동화
        self.tab_automation = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.tab_automation, text="  자동화  ")
        self._create_automation_tab()

        # 탭 2: 완전 자동화
        self.tab_full_auto = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.tab_full_auto, text="  완전자동화  ")
        self._create_full_auto_tab()

        # 탭 3: 퀴즈 풀이
        self.tab_quiz = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.tab_quiz, text="  퀴즈 풀이  ")
        self._create_quiz_tab()

        # 탭 4: 설정
        self.tab_settings = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.tab_settings, text="  설정  ")
        self._create_settings_tab()

        # 로그 큐 처리 시작
        self.after(100, self.process_log_queue)

    def _set_app_icon(self):
        """앱 아이콘 설정 (제목표시줄 + 작업표시줄)"""
        try:
            import sys
            from pathlib import Path

            if getattr(sys, 'frozen', False) or "__compiled__" in globals():
                base = Path(sys.executable).parent
            else:
                base = Path(__file__).parent.parent

            # 1. ICO 파일 우선 (제목표시줄용)
            ico_path = base / 'DooClick.ico'
            if ico_path.exists():
                self.iconbitmap(str(ico_path))

            # 2. PNG로 작업표시줄 아이콘 설정
            png_path = base / 'DooClick_icon.png'
            if png_path.exists():
                icon_img = tk.PhotoImage(file=str(png_path))
                self.iconphoto(True, icon_img)
                self._icon_ref = icon_img  # GC 방지

            # 3. Windows 작업표시줄에 별도 아이콘 표시 (AppUserModelID)
            try:
                import ctypes
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('DooClick.V4')
            except Exception:
                pass

        except Exception as e:
            print(f"[경고] 아이콘 설정 실패: {e}")

    def _create_full_auto_tab(self):
        """완전 자동화 탭 UI 구성"""
        # ===== 설명 =====
        desc_frame = ttk.LabelFrame(self.tab_full_auto, text="완전 자동화", padding="10")
        desc_frame.pack(fill=tk.X, pady=(0, 10))

        desc_text = ("로그인부터 강의 수강까지 모든 과정을 자동화합니다.\n"
                     "• 브라우저 열기 → 로그인 → 강의 선택 → 자동 수강\n"
                     "• 강의 완료 시 설문/이수처리 후 다음 강의 진행\n"
                     "• 15차시 한도 또는 모든 강의 완료 시 자동 종료")
        ttk.Label(desc_frame, text=desc_text, font=("맑은 고딕", 9), justify=tk.LEFT).pack(anchor=tk.W)

        # ===== 제어 버튼 =====
        control_frame = ttk.LabelFrame(self.tab_full_auto, text="실행", padding="10")
        control_frame.pack(fill=tk.X, pady=(0, 10))

        button_frame = ttk.Frame(control_frame)
        button_frame.pack(fill=tk.X)

        self.btn_full_auto_start = ttk.Button(
            button_frame, text="🚀 완전 자동화 시작",
            width=20, command=self._on_full_auto_start
        )
        self.btn_full_auto_start.pack(side=tk.LEFT, padx=(0, 10))

        self.btn_full_auto_stop = ttk.Button(
            button_frame, text="■ 중지",
            width=10, state="disabled", command=self._on_full_auto_stop
        )
        self.btn_full_auto_stop.pack(side=tk.LEFT, padx=(0, 10))

        # 편리모드 토글 버튼 (완전자동화용 - 모든 창 숨김)
        self.btn_full_auto_convenience = ttk.Button(
            button_frame, text="🖥 편리모드 ON",
            width=14, command=self._on_full_auto_convenience_toggle
        )
        self.btn_full_auto_convenience.pack(side=tk.LEFT)

        # 옵션 프레임 (체크박스들)
        option_frame = ttk.Frame(control_frame)
        option_frame.pack(fill=tk.X, pady=(8, 0))

        # 편리모드로 시작 체크박스
        self.start_with_convenience_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            option_frame, text="편리모드로 시작 (처음부터 창 숨김)",
            variable=self.start_with_convenience_var
        ).pack(side=tk.LEFT)

        # ===== 예약 실행 =====
        schedule_frame = ttk.LabelFrame(self.tab_full_auto, text="예약 실행 (매일)", padding="10")
        schedule_frame.pack(fill=tk.X, pady=(0, 10))

        schedule_row = ttk.Frame(schedule_frame)
        schedule_row.pack(fill=tk.X)

        ttk.Label(schedule_row, text="실행 시간:").pack(side=tk.LEFT)

        # 시간 선택 (0~23시)
        self.schedule_hour_var = tk.StringVar(value="09")
        hour_combo = ttk.Combobox(
            schedule_row, textvariable=self.schedule_hour_var,
            values=[f"{h:02d}" for h in range(24)],
            width=4, state="readonly"
        )
        hour_combo.pack(side=tk.LEFT, padx=(5, 0))

        ttk.Label(schedule_row, text=":").pack(side=tk.LEFT)

        # 분 선택 (00, 10, 20, 30, 40, 50)
        self.schedule_min_var = tk.StringVar(value="00")
        min_combo = ttk.Combobox(
            schedule_row, textvariable=self.schedule_min_var,
            values=["00", "10", "20", "30", "40", "50"],
            width=4, state="readonly"
        )
        min_combo.pack(side=tk.LEFT)

        # 예약 버튼
        self.btn_schedule = ttk.Button(
            schedule_row, text="⏰ 예약", width=8,
            command=self._on_schedule_start
        )
        self.btn_schedule.pack(side=tk.LEFT, padx=(15, 5))

        # 예약 취소 버튼
        self.btn_schedule_cancel = ttk.Button(
            schedule_row, text="예약 취소", width=10,
            command=self._on_schedule_cancel, state="disabled"
        )
        self.btn_schedule_cancel.pack(side=tk.LEFT)

        # ===== 사용 방법 =====
        info_frame = ttk.LabelFrame(self.tab_full_auto, text="사용 전 확인", padding="5")
        info_frame.pack(fill=tk.X)

        info_text = "① 설정 탭에서 계정 정보 저장  ② 연수원 선택 확인  ③ 시작 클릭"
        ttk.Label(info_frame, text=info_text, font=("맑은 고딕", 9)).pack(anchor=tk.W)

    def _toggle_password_visibility(self):
        """비밀번호 보기/숨기기 토글"""
        if self.show_pw_var.get():
            self.full_auto_pw_entry.config(show="")
        else:
            self.full_auto_pw_entry.config(show="*")

    def _load_saved_credential(self):
        """저장된 계정 정보 불러오기"""
        if CREDENTIAL_MANAGER_AVAILABLE and has_credentials():
            username, password = get_credentials()
            if username:
                self.full_auto_id_var.set(username)
            if password:
                self.full_auto_pw_var.set(password)

    def _save_credential(self):
        """계정 정보 저장"""
        username = self.full_auto_id_var.get().strip()
        password = self.full_auto_pw_var.get().strip()

        if not username or not password:
            messagebox.showwarning("경고", "아이디와 비밀번호를 모두 입력해주세요.")
            return

        if CREDENTIAL_MANAGER_AVAILABLE:
            if save_credentials(username, password):
                self.log_queue.put("[알림] 계정 정보가 저장되었습니다.")
                messagebox.showinfo("완료", "계정 정보가 암호화되어 저장되었습니다.")
            else:
                messagebox.showerror("오류", "계정 저장에 실패했습니다.")
        else:
            messagebox.showerror("오류", "계정 관리자를 불러올 수 없습니다.")

    def _clear_credential(self):
        """계정 정보 삭제"""
        result = messagebox.askyesno(
            "확인",
            "저장된 계정 정보를 삭제하시겠습니까?"
        )
        if result:
            if CREDENTIAL_MANAGER_AVAILABLE:
                if clear_credentials():
                    self.full_auto_id_var.set("")
                    self.full_auto_pw_var.set("")
                    self.log_queue.put("[알림] 계정 정보가 삭제되었습니다.")
                else:
                    messagebox.showerror("오류", "계정 삭제에 실패했습니다.")

    def _on_full_auto_start(self):
        """완전 자동화 시작 버튼 클릭"""
        username = self.full_auto_id_var.get().strip()
        password = self.full_auto_pw_var.get().strip()

        if not username or not password:
            messagebox.showwarning(
                "계정 정보 필요",
                "설정 탭에서 아이디와 비밀번호를 입력해주세요."
            )
            # 설정 탭으로 이동
            self.notebook.select(self.tab_settings)
            return

        if self.full_auto_start_callback:
            auto_next = self.auto_next_var.get()
            # 체크박스가 체크되어 있으면 편리모드로 시작
            use_convenience = self.start_with_convenience_var.get() or self.is_convenience_mode
            # URL도 함께 전달
            url = self.url_var.get().strip()
            success = self.full_auto_start_callback(username, password, auto_next, url, use_convenience)
            if success:
                self._update_full_auto_ui(True)
                # 편리모드로 시작 체크박스가 체크되어 있으면 UI도 업데이트
                if self.start_with_convenience_var.get():
                    self._update_convenience_ui(True)
            else:
                messagebox.showerror("오류", "완전 자동화 시작에 실패했습니다.")

    def _on_full_auto_stop(self):
        """완전 자동화 중지 버튼 클릭"""
        if self.full_auto_stop_callback:
            self.full_auto_stop_callback()
        self._update_full_auto_ui(False)
        # 편리모드 상태도 초기화 (full_automation.py에서 창 복귀됨)
        if self.is_convenience_mode:
            self._update_convenience_ui(False)

    def _update_full_auto_ui(self, is_running):
        """완전 자동화 UI 상태 업데이트"""
        self.is_full_auto_running = is_running
        if is_running:
            self.btn_full_auto_start.config(state="disabled")
            self.btn_full_auto_stop.config(state="normal")
            self.status_text.set("완전 자동화 실행 중...")
        else:
            self.btn_full_auto_start.config(state="normal")
            self.btn_full_auto_stop.config(state="disabled")
            # 예약 상태일 때는 다음 예약 시간 표시
            if self.is_scheduled and self.scheduled_time:
                time_str = self.scheduled_time.strftime("%Y-%m-%d %H:%M")
                self.status_text.set(f"⏰ 다음 예약: {time_str}에 자동 실행")
            else:
                self.status_text.set("완전 자동화가 종료되었습니다.")

    def _on_schedule_start(self):
        """예약 실행 시작"""
        from datetime import datetime, timedelta

        # 계정 확인
        username = self.full_auto_id_var.get().strip()
        password = self.full_auto_pw_var.get().strip()
        if not username or not password:
            messagebox.showwarning(
                "계정 정보 필요",
                "설정 탭에서 계정 정보를 먼저 입력해주세요."
            )
            self.notebook.select(self.tab_settings)
            return

        # 선택된 시간
        hour = int(self.schedule_hour_var.get())
        minute = int(self.schedule_min_var.get())

        # 랜덤 오프셋 (0~10분)
        import random
        self.schedule_random_offset = random.randint(0, 10)

        # 예약 시간 계산
        now = datetime.now()
        scheduled = now.replace(hour=hour, minute=minute, second=0, microsecond=0)

        # 오늘 시간이 이미 지났으면 내일로
        if scheduled <= now:
            scheduled += timedelta(days=1)

        self.scheduled_time = scheduled
        self.is_scheduled = True

        # UI 업데이트
        self.btn_schedule.config(state="disabled")
        self.btn_schedule_cancel.config(state="normal")
        self.btn_full_auto_start.config(state="disabled")

        # 상태 표시 (하단 상태바에 표시)
        time_str = scheduled.strftime("%Y-%m-%d %H:%M")
        self.status_text.set(f"⏰ 예약됨: {time_str}에 자동 실행")
        self.log_queue.put(f"[예약] {time_str}에 자동 실행 예약됨")

        # 타이머 시작 (30초마다 체크)
        self._check_schedule()

    def _on_schedule_cancel(self):
        """예약 취소"""
        self.is_scheduled = False
        self.scheduled_time = None

        # 타이머 취소
        if self.schedule_check_id:
            self.after_cancel(self.schedule_check_id)
            self.schedule_check_id = None

        # UI 업데이트
        self.btn_schedule.config(state="normal")
        self.btn_schedule_cancel.config(state="disabled")
        if not self.is_full_auto_running:
            self.btn_full_auto_start.config(state="normal")

        self.status_text.set("예약이 취소되었습니다.")
        self.log_queue.put("[예약] 예약이 취소되었습니다.")

    def _check_schedule(self):
        """예약 시간 체크 (30초마다)"""
        from datetime import datetime, timedelta

        if not self.is_scheduled or not self.scheduled_time:
            return

        now = datetime.now()

        # 실행 시간 = 예약 시간 + 랜덤 오프셋
        actual_run_time = self.scheduled_time + timedelta(minutes=self.schedule_random_offset)

        if now >= actual_run_time:
            # 실행 시간 도달!
            self.log_queue.put("[예약] 예약 시간 도달 - 완전 자동화 시작!")

            # 다음 날 예약 준비
            import random
            self.scheduled_time += timedelta(days=1)
            self.schedule_random_offset = random.randint(0, 10)

            # 상태 업데이트 (다음 예약은 완전자동화 종료 후 하단 상태바에 표시됨)
            time_str = self.scheduled_time.strftime("%Y-%m-%d %H:%M")
            self.log_queue.put(f"[예약] 다음 예약: {time_str}")

            # 완전 자동화 실행
            self._on_full_auto_start()

        # 다음 체크 예약 (30초 후)
        self.schedule_check_id = self.after(30000, self._check_schedule)

    def _create_automation_tab(self):
        """자동화 탭 UI 구성"""
        # ===== 상단 헤더: 연수원 접속 버튼 (우측) =====
        header_frame = ttk.Frame(self.tab_automation)
        header_frame.pack(fill=tk.X, pady=(0, 10))

        # 좌측: 간단한 안내
        ttk.Label(header_frame, text="📚 교원연수 자동화",
                  font=("맑은 고딕", 10, "bold")).pack(side=tk.LEFT)

        # 우측: 연수원 접속 버튼
        self.btn_launch_chrome = ttk.Button(
            header_frame, text="🌐 연수원 접속",
            command=self._launch_chrome, width=14
        )
        self.btn_launch_chrome.pack(side=tk.RIGHT)

        # ===== 제어 버튼 =====
        control_frame = ttk.LabelFrame(self.tab_automation, text="자동화 제어", padding="10")
        control_frame.pack(fill=tk.X, pady=(0, 10))

        button_frame = ttk.Frame(control_frame)
        button_frame.pack(fill=tk.X)

        self.btn_start = ttk.Button(button_frame, text="▶ 자동화 시작 (F9)", width=18)
        self.btn_start.pack(side=tk.LEFT, padx=(0, 5))

        self.btn_stop = ttk.Button(button_frame, text="■ 자동화 중지 (F10)", width=18, state="disabled")
        self.btn_stop.pack(side=tk.LEFT, padx=(0, 5))

        # 편리모드 토글 버튼
        self.btn_convenience = ttk.Button(
            button_frame,
            text="🖥 편리모드 ON",
            width=14,
            command=self._on_convenience_toggle
        )
        self.btn_convenience.pack(side=tk.LEFT)

        # 편리모드 안내 다시 보지 않기 설정 (저장된 값 로드)
        self._convenience_settings = load_settings()
        self._skip_convenience_confirm = self._convenience_settings.get('skip_convenience_confirm', False)

        # ===== 설명 =====
        desc_frame = ttk.LabelFrame(self.tab_automation, text="기능 설명", padding="10")
        desc_frame.pack(fill=tk.X, pady=(0, 10))

        desc_text = ("• 강의실 창의 재생/다음/퀴즈 버튼 자동 클릭\n"
                     "• 15차시 한도 또는 강의 완료 시 자동 종료\n"
                     "• 편리모드: 창을 숨기고 백그라운드 자동화 (컴퓨터 사용 가능)\n"
                     "  → '연수원 접속' 버튼으로 접속해야 작동\n"
                     "  → 연수원 주소는 설정 탭에서 변경 가능")
        ttk.Label(desc_frame, text=desc_text, font=("맑은 고딕", 9), justify=tk.LEFT).pack(anchor=tk.W)

        # ===== 사용 방법 =====
        info_frame = ttk.LabelFrame(self.tab_automation, text="사용 방법", padding="10")
        info_frame.pack(fill=tk.X)

        info_text = "① 연수원 접속 → ② 강의실 열기 → ③ 자동화 시작 (F9)"
        ttk.Label(info_frame, text=info_text, font=("맑은 고딕", 9), justify=tk.LEFT).pack(anchor=tk.W)

    def _create_quiz_tab(self):
        """퀴즈 풀이 탭 UI 구성"""
        # 설명
        desc_frame = ttk.LabelFrame(self.tab_quiz, text="설명", padding="10")
        desc_frame.pack(fill=tk.X, pady=(0, 10))

        desc_text = "현재 화면의 퀴즈를 AI가 분석하여\n정답을 찾아 자동으로 클릭합니다."
        ttk.Label(desc_frame, text=desc_text, font=("맑은 고딕", 9)).pack()

        # 제어 버튼
        control_frame = ttk.LabelFrame(self.tab_quiz, text="제어", padding="10")
        control_frame.pack(fill=tk.X, pady=(0, 10))

        button_frame = ttk.Frame(control_frame)
        button_frame.pack(fill=tk.X)

        self.btn_solve_quiz = ttk.Button(
            button_frame,
            text="🔍 퀴즈 풀이 실행",
            width=18,
            command=self._on_solve_quiz
        )
        self.btn_solve_quiz.pack(side=tk.LEFT, padx=(0, 10))

        self.btn_stop_quiz = ttk.Button(
            button_frame,
            text="■ 퀴즈 풀이 중지",
            width=18,
            state="disabled",
            command=self._on_stop_quiz
        )
        self.btn_stop_quiz.pack(side=tk.LEFT)

        # 사용 방법
        info_frame = ttk.LabelFrame(self.tab_quiz, text="사용 방법", padding="10")
        info_frame.pack(fill=tk.X)

        info_text = ("1. 퀴즈가 표시된 창을 화면에 띄우세요\n"
                     "2. '퀴즈 풀이 실행' 버튼 클릭\n"
                     "3. 3초 카운트다운 동안 퀴즈 창을 활성화하세요\n"
                     "   (다른 창에 가려지지 않도록)\n"
                     "4. 풀이 중에는 컴퓨터를 사용하지 마세요")
        ttk.Label(info_frame, text=info_text, font=("맑은 고딕", 9), justify=tk.LEFT).pack(anchor=tk.W)

    def _create_settings_tab(self):
        """설정 탭 UI 구성"""
        # ===== 계정 설정 (완전 자동화용) =====
        account_frame = ttk.LabelFrame(self.tab_settings, text="계정 설정 (완전 자동화용)", padding="10")
        account_frame.pack(fill=tk.X, pady=(0, 10))

        # 아이디
        row1 = ttk.Frame(account_frame)
        row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text="아이디:", width=10).pack(side=tk.LEFT)
        self.full_auto_id_var = tk.StringVar()
        self.full_auto_id_entry = ttk.Entry(row1, textvariable=self.full_auto_id_var, width=20)
        self.full_auto_id_entry.pack(side=tk.LEFT, padx=5)

        # 비밀번호
        row2 = ttk.Frame(account_frame)
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="비밀번호:", width=10).pack(side=tk.LEFT)
        self.full_auto_pw_var = tk.StringVar()
        self.full_auto_pw_entry = ttk.Entry(row2, textvariable=self.full_auto_pw_var, width=20, show="*")
        self.full_auto_pw_entry.pack(side=tk.LEFT, padx=5)

        # 비밀번호 보기 체크박스
        self.show_pw_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row2, text="보기", variable=self.show_pw_var,
                        command=self._toggle_password_visibility).pack(side=tk.LEFT)

        # 저장/삭제 버튼 + 옵션
        row3 = ttk.Frame(account_frame)
        row3.pack(fill=tk.X, pady=(5, 0))
        ttk.Label(row3, text="", width=10).pack(side=tk.LEFT)

        self.btn_save_credential = ttk.Button(
            row3, text="저장", width=6, command=self._save_credential
        )
        self.btn_save_credential.pack(side=tk.LEFT, padx=(5, 5))

        self.btn_clear_credential = ttk.Button(
            row3, text="삭제", width=6, command=self._clear_credential
        )
        self.btn_clear_credential.pack(side=tk.LEFT)

        # 다음 강의 자동 시작 옵션
        row4 = ttk.Frame(account_frame)
        row4.pack(fill=tk.X, pady=(5, 0))
        self.auto_next_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(row4, text="강의 완료 후 다음 강의 자동 시작",
                        variable=self.auto_next_var).pack(anchor=tk.W)

        # 저장된 계정 불러오기
        self._load_saved_credential()

        # ===== 연수원 설정 =====
        site_frame = ttk.LabelFrame(self.tab_settings, text="연수원 설정", padding="10")
        site_frame.pack(fill=tk.X, pady=(0, 10))

        # 연수원 선택
        row1 = ttk.Frame(site_frame)
        row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text="연수원:", width=10).pack(side=tk.LEFT)

        self.site_presets = {
            "전북교육연수포털": "https://www.jbstudy.kr/",
            "중앙교육연수원": "https://www.neti.go.kr/",
            "서울교육연수원": "https://www.seti.go.kr/",
            "부산교육연수원": "https://edu.beti.go.kr/",
            "대구교육연수원": "https://edu.deti.or.kr/",
            "인천교육연수원": "https://www.ieti.or.kr/",
            "광주교육연수원": "https://eduup.gen.go.kr/",
            "대전교육연수원": "https://www.teti.kr/",
            "울산교육연수원": "https://edu.ueti.or.kr/",
            "세종교육원": "https://www.sjti.kr/",
            "경기(남부)연수원": "https://www.gtie.go.kr/",
            "경기(율곡)연수원": "https://www.yulgog.org/",
            "강원교육연수원": "https://www.geti.or.kr/",
            "충북교육연수포털": "https://edu.cbe.go.kr/",
            "충남교육연수원": "https://www.ceti.or.kr/",
            "전남교육연수포털": "https://www.jnstudy.kr/",
            "경북교육연수원": "https://www.gbeti.or.kr/",
            "경남교육연수포털": "https://www.gneti.or.kr/",
            "제주(탐라교육원)": "https://www.tamna.or.kr/",
            "직접 입력": ""
        }

        # 저장된 연수원 불러오기
        self._site_settings = load_settings()
        saved_site = self._site_settings.get('selected_site', '전북교육연수포털')
        # 저장된 연수원이 프리셋에 없으면 기본값 사용
        if saved_site not in self.site_presets:
            saved_site = '전북교육연수포털'

        self.site_var = tk.StringVar(value=saved_site)
        self.site_combo = ttk.Combobox(
            row1, textvariable=self.site_var,
            values=list(self.site_presets.keys()),
            state="readonly", width=25
        )
        self.site_combo.pack(side=tk.LEFT, padx=5)
        self.site_combo.bind("<<ComboboxSelected>>", self._on_site_selected)

        # URL (저장된 연수원의 URL로 초기화)
        row2 = ttk.Frame(site_frame)
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="URL:", width=10).pack(side=tk.LEFT)

        # 직접 입력이면 저장된 custom_url 사용, 아니면 프리셋 URL 사용
        if saved_site == "직접 입력":
            initial_url = self._site_settings.get('custom_url', '')
            entry_state = "normal"
        else:
            initial_url = self.site_presets.get(saved_site, "")
            entry_state = "disabled"

        self.url_var = tk.StringVar(value=initial_url)
        self.url_entry = ttk.Entry(row2, textvariable=self.url_var, width=35, state=entry_state)
        self.url_entry.pack(side=tk.LEFT, padx=5)

        # 직접 입력 URL 저장 (포커스 벗어날 때)
        self.url_entry.bind("<FocusOut>", self._save_custom_url)

        ttk.Label(site_frame, text="※ 자동화 탭에서 '연수원 접속' 버튼으로 Chrome 실행",
                  font=("맑은 고딕", 8), foreground="gray").pack(anchor=tk.W, pady=(5, 0))

        # API 설정
        api_frame = ttk.LabelFrame(self.tab_settings, text="API 설정", padding="10")
        api_frame.pack(fill=tk.X, pady=(0, 10))

        # API 키 입력 행
        api_row1 = ttk.Frame(api_frame)
        api_row1.pack(fill=tk.X, pady=2)
        ttk.Label(api_row1, text="API 키:", width=8).pack(side=tk.LEFT)

        self.api_key_var = tk.StringVar()
        self.api_key_entry = ttk.Entry(api_row1, textvariable=self.api_key_var, width=22, show="*")
        self.api_key_entry.pack(side=tk.LEFT, padx=5)

        # 저장/삭제 버튼
        self.btn_save_api = ttk.Button(api_row1, text="저장", width=6, command=self._save_api_key)
        self.btn_save_api.pack(side=tk.LEFT, padx=2)

        self.btn_clear_api = ttk.Button(api_row1, text="삭제", width=6, command=self._clear_api_key)
        self.btn_clear_api.pack(side=tk.LEFT, padx=2)

        # API 키 없을 때 안내 영역
        self.api_help_frame = ttk.Frame(api_frame)
        self.api_help_label = ttk.Label(
            self.api_help_frame,
            text="ℹ API 한도 초과 시 개인 API 키를 발급받아 사용하세요.",
            font=("맑은 고딕", 8), foreground="gray"
        )
        self.api_help_label.pack(anchor=tk.W)

        self.btn_get_api_key = ttk.Button(
            self.api_help_frame, text="API 키 발급받으러 가기",
            command=lambda: __import__('webbrowser').open("https://aistudio.google.com/apikey")
        )
        self.btn_get_api_key.pack(anchor=tk.W, pady=(3, 0))

        # API 상태에 따라 UI 업데이트
        self._update_api_display()

        # 버전 정보
        version_frame = ttk.LabelFrame(self.tab_settings, text="정보", padding="10")
        version_frame.pack(fill=tk.X, pady=(0, 10))

        try:
            from config import __version__, APP_NAME
            version_text = f"{APP_NAME} v{__version__}"
        except ImportError:
            version_text = "DooClick"

        ttk.Label(version_frame, text=version_text, font=("맑은 고딕", 9)).pack(anchor=tk.W)
        ttk.Label(version_frame, text="교원 연수 자동화 프로그램", font=("맑은 고딕", 8), foreground="gray").pack(anchor=tk.W)

    def _update_scale_label(self, label, var):
        """슬라이더 값 변경 시 레이블 업데이트"""
        label.config(text=f"{var.get():.2f}")

    def _on_site_selected(self, event=None):
        """연수원 선택 시 URL 자동 입력 및 설정 저장"""
        site_name = self.site_var.get()

        if site_name == "직접 입력":
            # 직접 입력: 저장된 custom_url 불러오기
            self.url_entry.config(state="normal")
            saved_custom_url = self._site_settings.get('custom_url', '')
            self.url_var.set(saved_custom_url)
            self.url_entry.focus()
        else:
            # 프리셋 선택: URL 자동 입력
            url = self.site_presets.get(site_name, "")
            self.url_entry.config(state="normal")
            self.url_var.set(url)
            self.url_entry.config(state="disabled")

        # 선택한 연수원 저장
        self._site_settings['selected_site'] = site_name
        save_settings(self._site_settings)

    def _save_custom_url(self, event=None):
        """직접 입력 URL 저장 (포커스 벗어날 때)"""
        if self.site_var.get() == "직접 입력":
            custom_url = self.url_var.get().strip()
            self._site_settings['custom_url'] = custom_url
            save_settings(self._site_settings)

    def _launch_chrome(self):
        """Chrome 실행 (편리모드용 플래그 포함)"""
        import subprocess
        import shutil

        url = self.url_var.get().strip()
        if not url:
            messagebox.showwarning("경고", "URL을 입력해주세요.")
            return

        # Chrome 경로 찾기
        chrome_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe")
        ]

        chrome_path = None
        for path in chrome_paths:
            if os.path.exists(path):
                chrome_path = path
                break

        if not chrome_path:
            # PATH에서 찾기
            chrome_path = shutil.which("chrome")

        if not chrome_path:
            messagebox.showerror("오류", "Chrome을 찾을 수 없습니다.\nChrome이 설치되어 있는지 확인해주세요.")
            return

        # DooClick 전용 프로필 경로 (기존 Chrome과 완전 분리)
        import tempfile
        profile_dir = os.path.join(tempfile.gettempdir(), "DooClick_Chrome_Profile")

        # 편리모드용 플래그 + 별도 프로필
        flags = [
            f"--user-data-dir={profile_dir}",  # 별도 프로필 → 새 프로세스
            "--disable-backgrounding-occluded-windows",
            "--disable-renderer-backgrounding",
            "--disable-features=CalculateNativeWinOcclusion",
            "--disable-background-timer-throttling"
        ]

        try:
            cmd = [chrome_path] + flags + [url]
            subprocess.Popen(cmd)
            self.log_queue.put(f"[알림] Chrome 실행: {url}")
        except Exception as e:
            messagebox.showerror("오류", f"Chrome 실행 실패:\n{e}")

    def _save_settings(self):
        """설정 저장"""
        self.settings['confidence_threshold'] = round(self.confidence_var.get(), 2)
        self.settings['confidence_threshold_text'] = round(self.confidence_text_var.get(), 2)

        if save_settings(self.settings):
            # active_mode에 설정 적용
            self._apply_settings_to_active_mode()
            self.log_queue.put("[알림] 설정이 저장되었습니다.")
        else:
            self.log_queue.put("[오류] 설정 저장에 실패했습니다.")

    def _reset_settings(self):
        """설정을 기본값으로 복원"""
        if messagebox.askyesno("확인", "설정을 기본값으로 복원하시겠습니까?"):
            self.confidence_var.set(DEFAULT_SETTINGS['confidence_threshold'])
            self.confidence_text_var.set(DEFAULT_SETTINGS['confidence_threshold_text'])
            self._update_scale_label(self.confidence_label, self.confidence_var)
            self._update_scale_label(self.confidence_text_label, self.confidence_text_var)
            self._save_settings()

    def _apply_settings_to_active_mode(self):
        """active_mode 모듈에 설정 적용"""
        try:
            import active_mode
            active_mode.CONFIDENCE_THRESHOLD = self.settings['confidence_threshold']
            active_mode.CONFIDENCE_THRESHOLD_TEXT = self.settings['confidence_threshold_text']
        except Exception as e:
            print(f"[경고] 설정 적용 실패: {e}")

    def _create_status_bar(self):
        """하단 상태바 생성"""
        status_frame = ttk.Frame(self.main_frame)
        status_frame.pack(fill=tk.X, side=tk.BOTTOM, pady=(5, 0))

        ttk.Separator(status_frame, orient='horizontal').pack(fill=tk.X, pady=(0, 5))

        self.status_text = tk.StringVar()
        self.status_text.set("준비 완료. [F9]로 자동화를 시작하세요.")

        self.status_label = ttk.Label(
            status_frame,
            textvariable=self.status_text,
            font=("맑은 고딕", 9),
            foreground="gray"
        )
        self.status_label.pack(fill=tk.X)

    def _on_solve_quiz(self):
        """퀴즈 풀이 버튼 클릭 시"""
        if self.quiz_callback:
            self.status_text.set("퀴즈 풀이 중...")
            self.btn_solve_quiz.config(state="disabled")
            self.btn_stop_quiz.config(state="normal")
            self.quiz_callback()

    def _on_stop_quiz(self):
        """퀴즈 풀이 중지 버튼 클릭 시"""
        if self.quiz_stop_callback:
            self.quiz_stop_callback()
            self.status_text.set("퀴즈 풀이가 중지되었습니다.")
            self.btn_solve_quiz.config(state="normal")
            self.btn_stop_quiz.config(state="disabled")

    def update_quiz_ui_on_complete(self):
        """퀴즈 풀이 완료 시 UI 상태 변경"""
        self.btn_solve_quiz.config(state="normal")
        self.btn_stop_quiz.config(state="disabled")

    def process_log_queue(self):
        """로그 큐 처리 (로그 레벨별 색상 구분)"""
        try:
            message = None
            while not self.log_queue.empty():
                message = self.log_queue.get_nowait()
                # 자동 종료 신호 처리
                if message == "@@AUTO_STOP@@":
                    self.update_ui_on_stop()
                    message = None
                    continue
                # 메시지박스 신호 처리 (완전자동화 모드에서는 팝업 표시 안함)
                if message == "@@MSG_강의완료@@":
                    if not self.is_full_auto_running:
                        messagebox.showinfo("DooClick - 강의 완료",
                            "현재 강의가 완료되었습니다.\n\n(마지막 목차 도달)")
                    message = None
                    continue
                if message == "@@MSG_한도도달@@":
                    # 한도도달은 완전자동화 모드에서도 항상 표시
                    messagebox.showinfo("DooClick - 일일 한도 도달",
                        "오늘 연수 15차시를 모두 수강했습니다.\n\n내일 다시 시작해주세요.")
                    message = None
                    continue
                if message == "@@MSG_퀴즈완료@@":
                    messagebox.showinfo("DooClick - 퀴즈 완료",
                        "퀴즈 풀이가 끝났습니다.")
                    message = None
                    continue
                if message == "@@MSG_버튼없음@@":
                    messagebox.showwarning("DooClick - 퀴즈 오류",
                        "다음/제출 버튼을 찾을 수 없습니다.\n\n퀴즈 풀이가 중단되었습니다.")
                    message = None
                    continue
                # API 키 모두 한도 초과 시 상세 안내 팝업
                if "API 키가 모두 한도 초과" in message:
                    messagebox.showwarning(
                        "DooClick - API 한도 초과",
                        "모든 API 키가 한도 초과되었습니다.\n\n"
                        "해결 방법:\n"
                        "• 내일 다시 시도하거나\n"
                        "• 설정 탭에서 개인 API 키를 발급받아 저장하세요\n\n"
                        "(Google AI Studio에서 무료로 발급 가능)"
                    )
                    self.update_quiz_ui_on_complete()
                    message = None
                    continue
                # 기타 API 에러 시 팝업 표시
                api_errors = ["API 접근 권한", "API 인증 실패",
                              "Gemini 서버 점검", "Gemini 서버 오류", "HTTP 오류"]
                if any(err in message for err in api_errors):
                    messagebox.showerror("API 오류", message.replace("[오류] ", ""))
                    self.update_quiz_ui_on_complete()
            if message:
                self.status_text.set(message)
                # 로그 레벨별 색상 적용
                self._update_status_color(message)
        finally:
            self.after(100, self.process_log_queue)

    def _update_status_color(self, message):
        """메시지 내용에 따라 상태바 색상 변경"""
        if "[오류]" in message or "[ERROR]" in message:
            self.status_label.config(foreground="#c0392b")  # 빨간색 (오류)
        elif "[경고]" in message or "[주의]" in message or "[WARN]" in message:
            self.status_label.config(foreground="#e67e22")  # 주황색 (경고)
        elif "[알림]" in message or "[INFO]" in message:
            self.status_label.config(foreground="#2980b9")  # 파란색 (알림)
        elif "완료" in message or "성공" in message:
            self.status_label.config(foreground="#27ae60")  # 녹색 (성공)
        else:
            self.status_label.config(foreground="gray")  # 기본 회색

    def update_ui_on_start(self):
        """자동화 시작 시 UI 상태 변경"""
        self.btn_start.config(state="disabled")
        self.btn_stop.config(state="normal")
        self.status_text.set("자동화 실행 중...")

    def update_ui_on_stop(self):
        """자동화 중지 시 UI 상태 변경"""
        self.btn_start.config(state="normal")
        self.btn_stop.config(state="disabled")
        self.status_text.set("자동화가 중지되었습니다. [F9]로 다시 시작하세요.")

    def _on_convenience_toggle(self):
        """편리모드 토글 버튼 클릭 시 (일반 자동화 - 강의실만)"""
        if not self.is_convenience_mode:
            # 켜기
            if not self._skip_convenience_confirm:
                # 다시 보지 않기 체크박스가 있는 커스텀 다이얼로그
                dlg = tk.Toplevel(self)
                dlg.title("편리모드")
                dlg.resizable(False, False)
                dlg.transient(self)
                dlg.grab_set()

                # 마우스 커서 근처에 다이얼로그 표시
                mx, my = self.winfo_pointerxy()
                dlg.geometry(f"+{mx - 80}+{my + 10}")

                ttk.Label(dlg, text="편리모드를 시작하시겠습니까?\n\n"
                          "• 강의실 창이 화면 밖으로 이동합니다\n"
                          "• 백그라운드에서 자동화가 계속됩니다\n"
                          "• 종료하려면 다시 이 버튼을 누르세요",
                          font=("맑은 고딕", 9), justify=tk.LEFT
                ).pack(padx=20, pady=(15, 5))

                skip_var = tk.BooleanVar(value=False)
                ttk.Checkbutton(dlg, text="다시 보지 않기", variable=skip_var
                ).pack(padx=20, anchor=tk.W)

                confirmed = [False]

                def on_ok():
                    confirmed[0] = True
                    if skip_var.get():
                        self._skip_convenience_confirm = True
                        # 설정 저장
                        self._convenience_settings['skip_convenience_confirm'] = True
                        save_settings(self._convenience_settings)
                    dlg.destroy()

                btn_frame = ttk.Frame(dlg)
                btn_frame.pack(pady=(5, 15))
                ttk.Button(btn_frame, text="확인", width=8, command=on_ok).pack(side=tk.LEFT, padx=5)
                ttk.Button(btn_frame, text="취소", width=8, command=dlg.destroy).pack(side=tk.LEFT, padx=5)

                dlg.wait_window()
                if not confirmed[0]:
                    return

            # 편리모드 시작 (강의실만)
            if self.convenience_start_callback:
                success = self.convenience_start_callback()
                if success:
                    self._update_convenience_ui(True)
                else:
                    messagebox.showerror(
                        "오류",
                        "편리모드 시작에 실패했습니다.\n\n"
                        "• 강의실 창이 열려있는지 확인하세요"
                    )
        else:
            # 끄기 - 확인 없이 바로 종료
            if self.convenience_stop_callback:
                self.convenience_stop_callback()
            self._update_convenience_ui(False)

    def _on_full_auto_convenience_toggle(self):
        """편리모드 토글 버튼 클릭 시 (완전자동화 - 모든 창)"""
        if not self.is_convenience_mode:
            # 켜기 - 완전자동화용은 확인 없이 바로 실행
            if self.convenience_start_all_callback:
                success = self.convenience_start_all_callback()
                if success:
                    self._update_convenience_ui(True)
                else:
                    messagebox.showerror(
                        "오류",
                        "편리모드 시작에 실패했습니다.\n\n"
                        "• 강의실 또는 연수원 창이 열려있는지 확인하세요"
                    )
        else:
            # 끄기
            if self.convenience_stop_callback:
                self.convenience_stop_callback()
            self._update_convenience_ui(False)

    def _update_convenience_ui(self, is_active):
        """편리모드 UI 상태 업데이트 (자동화 탭 + 완전자동화 탭 동기화)"""
        self.is_convenience_mode = is_active
        if is_active:
            self.btn_convenience.config(text="🖥 편리모드 OFF")
            self.btn_full_auto_convenience.config(text="🖥 편리모드 OFF")
            self.status_text.set("편리모드 활성화 - 창이 화면 밖으로 이동됨")
        else:
            self.btn_convenience.config(text="🖥 편리모드 ON")
            self.btn_full_auto_convenience.config(text="🖥 편리모드 ON")
            self.status_text.set("편리모드 종료 - 창이 복귀됨")

    def force_stop_convenience_mode(self):
        """외부에서 편리모드 강제 종료 시 UI 업데이트"""
        self._update_convenience_ui(False)

    def _update_api_display(self):
        """저장된 API 키 표시 업데이트 - 입력필드 플레이스홀더 + 조건부 안내"""
        has_key = False

        if API_MANAGER_AVAILABLE:
            display = get_user_key_display()
            if display:
                has_key = True
                # 저장된 키가 있으면 마스킹된 키를 입력필드에 표시
                self.api_key_var.set("")
                self.api_key_entry.config(show="*")
                self._set_placeholder(display)
            else:
                self._set_placeholder("저장된 키 없음")
        else:
            self._set_placeholder("API 관리자 없음")

        # 키 없을 때만 안내 표시
        if has_key:
            self.api_help_frame.pack_forget()
        else:
            self.api_help_frame.pack(fill=tk.X, pady=(5, 0))

    def _set_placeholder(self, text):
        """입력필드에 플레이스홀더 텍스트 설정"""
        self.api_key_entry.config(show="")
        self.api_key_var.set(text)
        self.api_key_entry.config(foreground="gray")

        def on_focus_in(e):
            if self.api_key_var.get() in ("저장된 키 없음", "API 관리자 없음") or \
               self.api_key_var.get().startswith("****"):
                self.api_key_var.set("")
                self.api_key_entry.config(show="*", foreground="black")

        def on_focus_out(e):
            if not self.api_key_var.get().strip():
                self._update_api_display()

        # 기존 바인딩 제거 후 재설정
        self.api_key_entry.unbind("<FocusIn>")
        self.api_key_entry.unbind("<FocusOut>")
        self.api_key_entry.bind("<FocusIn>", on_focus_in)
        self.api_key_entry.bind("<FocusOut>", on_focus_out)

    def _save_api_key(self):
        """API 키 저장"""
        if not API_MANAGER_AVAILABLE:
            messagebox.showerror("오류", "API 관리자를 불러올 수 없습니다.")
            return

        api_key = self.api_key_var.get().strip()
        if not api_key or api_key in ("저장된 키 없음", "API 관리자 없음") or api_key.startswith("****"):
            messagebox.showwarning("경고", "API 키를 입력해주세요.")
            return

        # 기본 유효성 검사 (Gemini API 키 형식: AIza로 시작)
        if not api_key.startswith("AIza"):
            result = messagebox.askyesno(
                "확인",
                "Gemini API 키는 보통 'AIza'로 시작합니다.\n"
                "이 키를 그대로 저장하시겠습니까?"
            )
            if not result:
                return

        # 저장
        if save_user_api_key(api_key):
            self.api_key_var.set("")  # 입력창 비우기
            self._update_api_display()
            self.log_queue.put("[알림] API 키가 저장되었습니다.")
            messagebox.showinfo("완료", "API 키가 암호화되어 저장되었습니다.")
        else:
            messagebox.showerror("오류", "API 키 저장에 실패했습니다.")

    def _clear_api_key(self):
        """API 키 삭제"""
        if not API_MANAGER_AVAILABLE:
            messagebox.showerror("오류", "API 관리자를 불러올 수 없습니다.")
            return

        result = messagebox.askyesno(
            "확인",
            "저장된 API 키를 삭제하시겠습니까?\n\n"
            "삭제 후에는 기본 API 키가 사용됩니다."
        )
        if result:
            if save_user_api_key(None):
                self._update_api_display()
                self.log_queue.put("[알림] API 키가 삭제되었습니다.")
            else:
                messagebox.showerror("오류", "API 키 삭제에 실패했습니다.")

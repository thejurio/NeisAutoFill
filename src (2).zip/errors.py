# -*- coding: utf-8 -*-
# 파일: src/errors.py
# 역할: DooClick 커스텀 에러 클래스 정의
# 생성일: 2026-01-27

"""
에러 계층 구조:

DooClickError (기본)
├── AutomationError (자동화 관련)
│   ├── WindowNotFoundError (창 못 찾음)
│   └── ImageMatchError (이미지 매칭 실패)
├── QuizSolverError (퀴즈 풀이 관련)
│   ├── OCRError (OCR 실패)
│   ├── AIResponseError (AI 응답 실패)
│   └── AnswerNotFoundError (정답 위치 못 찾음)
└── ConfigError (설정 관련)
    └── APIKeyError (API 키 없음)
"""


class DooClickError(Exception):
    """DooClick 기본 에러 클래스"""

    def __init__(self, message, user_message=None):
        """
        Args:
            message: 개발자용 상세 에러 메시지 (로그용)
            user_message: 사용자에게 표시할 간단한 메시지 (UI용)
        """
        super().__init__(message)
        self.user_message = user_message or message

    def __str__(self):
        return f"{self.__class__.__name__}: {self.args[0]}"


# === 자동화 관련 에러 ===

class AutomationError(DooClickError):
    """자동화 작업 중 발생하는 에러"""
    pass


class WindowNotFoundError(AutomationError):
    """대상 창을 찾지 못함"""

    def __init__(self, window_title):
        super().__init__(
            f"'{window_title}' 창을 찾을 수 없습니다.",
            f"'{window_title}' 창을 열어주세요."
        )
        self.window_title = window_title


class ImageMatchError(AutomationError):
    """이미지 매칭 실패"""

    def __init__(self, image_name, reason="매칭 실패"):
        super().__init__(
            f"이미지 '{image_name}' 매칭 실패: {reason}",
            f"화면에서 '{image_name}'을 찾지 못했습니다."
        )
        self.image_name = image_name


# === 퀴즈 풀이 관련 에러 ===

class QuizSolverError(DooClickError):
    """퀴즈 풀이 중 발생하는 에러"""
    pass


class OCRError(QuizSolverError):
    """OCR(문자 인식) 실패"""

    def __init__(self, reason="텍스트 추출 불가"):
        super().__init__(
            f"OCR 실패: {reason}",
            "화면의 문제 텍스트를 읽지 못했습니다."
        )
        self.reason = reason


class AIResponseError(QuizSolverError):
    """AI 응답 실패"""

    def __init__(self, reason="응답 없음", is_timeout=False, is_network=False, is_retryable=False):
        if is_timeout:
            user_msg = "AI 응답 시간이 초과되었습니다. 잠시 후 다시 시도합니다."
        elif is_network:
            user_msg = "네트워크 연결을 확인해주세요."
        else:
            user_msg = "AI가 응답하지 못했습니다."

        super().__init__(f"AI 응답 실패: {reason}", user_msg)
        self.reason = reason
        self.is_timeout = is_timeout
        self.is_network = is_network
        self.is_retryable = is_retryable  # 재시도 가능 여부


class RetryableError(DooClickError):
    """재시도 가능한 에러 (429, 503, 타임아웃 등)"""

    def __init__(self, reason, retry_after=5):
        super().__init__(
            f"재시도 가능 에러: {reason}",
            f"{reason} ({retry_after}초 후 재시도)"
        )
        self.reason = reason
        self.retry_after = retry_after  # 재시도 대기 시간(초)


class AnswerNotFoundError(QuizSolverError):
    """정답 위치를 찾지 못함"""

    def __init__(self, answer_text):
        super().__init__(
            f"정답 '{answer_text}' 위치를 찾지 못함",
            f"정답 '{answer_text}'의 위치를 화면에서 찾지 못했습니다."
        )
        self.answer_text = answer_text


# === 설정 관련 에러 ===

class ConfigError(DooClickError):
    """설정 관련 에러"""
    pass


class APIKeyError(ConfigError):
    """API 키 미설정"""

    def __init__(self, api_name="API"):
        super().__init__(
            f"{api_name} 키가 설정되지 않았습니다.",
            f"{api_name} 키를 .env 파일에 설정해주세요."
        )
        self.api_name = api_name


# === 유틸리티 함수 ===

def get_user_friendly_message(error):
    """
    에러 객체에서 사용자 친화적 메시지를 추출합니다.

    Args:
        error: Exception 객체

    Returns:
        str: 사용자에게 표시할 메시지
    """
    if isinstance(error, DooClickError):
        return error.user_message

    # 알려진 외부 에러 처리
    error_str = str(error).lower()

    if "timeout" in error_str:
        return "요청 시간이 초과되었습니다. 잠시 후 다시 시도합니다."
    elif "connection" in error_str or "network" in error_str:
        return "네트워크 연결을 확인해주세요."
    elif "api" in error_str and "key" in error_str:
        return "API 키 설정을 확인해주세요."
    else:
        return f"오류가 발생했습니다: {type(error).__name__}"

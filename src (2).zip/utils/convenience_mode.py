# -*- coding: utf-8 -*-
"""
편리모드 유틸리티 모듈
- 창을 모니터 밖으로 이동하여 숨김
- 백그라운드 클릭 (SendMessage) 지원
- Chrome 플래그 필요: --disable-backgrounding-occluded-windows 등
"""

import win32gui
import win32con
import win32api
import time


# ============================================================
# 창 위치 관리
# ============================================================

def move_window_offscreen(hwnd, x=0, y=-3000):
    """
    창을 모니터 밖으로 이동 (Y축 위쪽으로)

    Args:
        hwnd: 창 핸들
        x, y: 이동할 좌표 (기본값: 화면 위쪽 밖, 듀얼모니터 호환)

    Returns:
        원래 위치 (left, top) 또는 None
    """
    try:
        # 현재 위치 저장
        rect = win32gui.GetWindowRect(hwnd)
        original_pos = (rect[0], rect[1])
        width = rect[2] - rect[0]
        height = rect[3] - rect[1]

        # 모니터 밖으로 이동
        win32gui.SetWindowPos(
            hwnd,
            win32con.HWND_TOP,
            x, y, width, height,
            win32con.SWP_NOSIZE | win32con.SWP_NOZORDER
        )

        print(f"[편리모드] 창 이동: {original_pos} → ({x}, {y})")
        return original_pos

    except Exception as e:
        print(f"[오류] 창 이동 실패: {e}")
        return None


def move_window_back(hwnd, x, y):
    """
    창을 원래 위치로 복귀

    Args:
        hwnd: 창 핸들
        x, y: 복귀할 좌표

    Returns:
        성공 여부
    """
    try:
        rect = win32gui.GetWindowRect(hwnd)
        width = rect[2] - rect[0]
        height = rect[3] - rect[1]

        win32gui.SetWindowPos(
            hwnd,
            win32con.HWND_TOP,
            x, y, width, height,
            win32con.SWP_NOSIZE | win32con.SWP_NOZORDER
        )

        print(f"[편리모드] 창 복귀: ({x}, {y})")
        return True

    except Exception as e:
        print(f"[오류] 창 복귀 실패: {e}")
        return False


# ============================================================
# 백그라운드 클릭 (SendMessage)
# ============================================================

def post_click(hwnd, x, y):
    """
    창에 백그라운드 클릭 메시지 전송 (창 위치 무관)

    Args:
        hwnd: 창 핸들
        x, y: 창 내 상대 좌표 (클라이언트 좌표)

    Returns:
        성공 여부
    """
    try:
        lParam = win32api.MAKELONG(x, y)
        win32gui.PostMessage(hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lParam)
        time.sleep(0.05)
        win32gui.PostMessage(hwnd, win32con.WM_LBUTTONUP, 0, lParam)
        return True
    except Exception as e:
        print(f"[오류] 백그라운드 클릭 실패: {e}")
        return False


def screen_to_client(hwnd, screen_x, screen_y):
    """
    화면 좌표를 창 클라이언트 좌표로 변환

    Args:
        hwnd: 창 핸들
        screen_x, screen_y: 화면 좌표

    Returns:
        (client_x, client_y) 또는 None
    """
    try:
        # 창의 클라이언트 영역 시작점
        client_rect = win32gui.GetClientRect(hwnd)
        window_rect = win32gui.GetWindowRect(hwnd)

        # 창 테두리/타이틀바 크기 계산
        border_x = ((window_rect[2] - window_rect[0]) - client_rect[2]) // 2
        title_bar_y = (window_rect[3] - window_rect[1]) - client_rect[3] - border_x

        # 클라이언트 좌표 계산
        client_x = screen_x - window_rect[0] - border_x
        client_y = screen_y - window_rect[1] - title_bar_y

        return (client_x, client_y)

    except Exception as e:
        print(f"[오류] 좌표 변환 실패: {e}")
        return None


# ============================================================
# 편리모드 관리자 클래스
# ============================================================

class ConvenienceMode:
    """
    편리모드 관리자
    - 창을 모니터 밖으로 이동하여 숨김
    - SendMessage로 백그라운드 클릭
    - Chrome 플래그 필요
    """

    def __init__(self):
        self.is_active = False
        self.target_hwnd = None
        self.original_position = None  # (x, y) 원래 창 위치

    def start(self, hwnd):
        """
        편리모드 시작 - 창을 모니터 밖으로 이동

        Args:
            hwnd: 이동할 창 핸들

        Returns:
            성공 여부
        """
        if self.is_active:
            print("[경고] 편리모드가 이미 활성화됨")
            return False

        if not win32gui.IsWindow(hwnd):
            print("[오류] 유효하지 않은 창 핸들")
            return False

        # 창을 모니터 밖으로 이동
        self.original_position = move_window_offscreen(hwnd)

        if self.original_position is None:
            return False

        self.target_hwnd = hwnd
        self.is_active = True

        print(f"[편리모드] 시작: hwnd={hwnd}")
        return True

    def stop(self):
        """
        편리모드 종료 - 창을 원래 위치로 복귀

        Returns:
            성공 여부
        """
        if not self.is_active:
            return True

        success = True

        # 창을 원래 위치로 복귀
        if self.target_hwnd and self.original_position:
            if win32gui.IsWindow(self.target_hwnd):
                success = move_window_back(
                    self.target_hwnd,
                    self.original_position[0],
                    self.original_position[1]
                )
            else:
                print("[경고] 창이 닫혔습니다")

        self.cleanup()
        print("[편리모드] 종료")
        return success

    def cleanup(self):
        """상태 초기화"""
        self.is_active = False
        self.target_hwnd = None
        self.original_position = None

    def click(self, screen_x, screen_y):
        """
        편리모드에서 클릭 수행 (SendMessage 사용)

        Args:
            screen_x, screen_y: 화면 좌표

        Returns:
            성공 여부
        """
        if not self.is_active or not self.target_hwnd:
            return False

        # 화면 좌표 → 클라이언트 좌표 변환
        client_coords = screen_to_client(self.target_hwnd, screen_x, screen_y)

        if client_coords is None:
            return False

        client_x, client_y = client_coords

        # 음수 좌표 체크 (창 영역 밖)
        if client_x < 0 or client_y < 0:
            print(f"[경고] 클릭 좌표가 창 영역 밖: ({client_x}, {client_y})")
            return False

        return post_click(self.target_hwnd, client_x, client_y)


# 전역 편리모드 인스턴스
_convenience_mode = ConvenienceMode()


def get_convenience_mode():
    """편리모드 인스턴스 반환"""
    return _convenience_mode


def is_available():
    """편리모드 사용 가능 여부 (항상 True - 가상 데스크톱 불필요)"""
    return True


# ============================================================
# 테스트
# ============================================================

if __name__ == '__main__':
    import pyautogui

    print("=" * 50)
    print("편리모드 테스트")
    print("=" * 50)

    # 강의실 창 찾기
    windows = pyautogui.getWindowsWithTitle('강의실')
    if not windows:
        print("\n강의실 창을 찾을 수 없습니다.")
        exit(1)

    hwnd = windows[0]._hWnd
    title = windows[0].title
    print(f"\n대상 창: '{title}' (hwnd={hwnd})")

    # 편리모드 시작
    mode = get_convenience_mode()

    print("\n[테스트 1] 편리모드 시작")
    if mode.start(hwnd):
        print("  → 성공: 창이 모니터 밖으로 이동됨")

        print("\n5초 대기 후 종료...")
        time.sleep(5)

        print("\n[테스트 2] 편리모드 종료")
        if mode.stop():
            print("  → 성공: 창이 원래 위치로 복귀됨")
        else:
            print("  → 실패")
    else:
        print("  → 실패")

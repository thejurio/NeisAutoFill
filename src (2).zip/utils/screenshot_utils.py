# -*- coding: utf-8 -*-
# 파일: src/utils/screenshot_utils.py
# 역할: 스크린샷 캡처 및 이미지 로드 공통 유틸리티
# 생성일: 2026-01-27
# 참고: active_mode.py, ocr_manager.py에서 중복 코드 통합

import win32api
import win32gui
import win32con
import win32ui
import numpy as np
import cv2
from PIL import Image


def screenshot_pywin32(region=None, output_format='pil'):
    """
    pywin32를 사용하여 듀얼 모니터를 포함한 화면을 캡처합니다.

    Args:
        region: (left, top, width, height) 튜플. None이면 전체 가상 데스크톱 캡처
        output_format: 'pil' (PIL Image) 또는 'cv2' (numpy BGR array)

    Returns:
        PIL.Image 또는 numpy.ndarray (BGR)

    Example:
        # 전체 화면 캡처 (PIL)
        img = screenshot_pywin32()

        # 특정 영역 캡처 (cv2)
        img = screenshot_pywin32(region=(0, 0, 800, 600), output_format='cv2')
    """
    # 캡처 영역 결정
    if region:
        left, top, width, height = region
    else:
        # 전체 가상 데스크톱 (듀얼 모니터 포함)
        width = win32api.GetSystemMetrics(win32con.SM_CXVIRTUALSCREEN)
        height = win32api.GetSystemMetrics(win32con.SM_CYVIRTUALSCREEN)
        left = win32api.GetSystemMetrics(win32con.SM_XVIRTUALSCREEN)
        top = win32api.GetSystemMetrics(win32con.SM_YVIRTUALSCREEN)

    # DC(Device Context) 생성
    hdesktop = win32gui.GetDesktopWindow()
    desktop_dc = win32gui.GetWindowDC(hdesktop)
    img_dc = win32ui.CreateDCFromHandle(desktop_dc)
    mem_dc = img_dc.CreateCompatibleDC()

    # 비트맵 생성 및 화면 복사
    screenshot = win32ui.CreateBitmap()
    screenshot.CreateCompatibleBitmap(img_dc, width, height)
    mem_dc.SelectObject(screenshot)
    mem_dc.BitBlt((0, 0), (width, height), img_dc, (left, top), win32con.SRCCOPY)

    # 비트맵 → PIL Image 변환
    signed_ints_array = screenshot.GetBitmapBits(True)
    pil_img = Image.frombuffer('RGB', (width, height), signed_ints_array, 'raw', 'BGRX', 0, 1)

    # 리소스 정리 (메모리 누수 방지)
    win32gui.DeleteObject(screenshot.GetHandle())
    mem_dc.DeleteDC()
    img_dc.DeleteDC()
    win32gui.ReleaseDC(hdesktop, desktop_dc)

    # 출력 포맷에 따라 반환
    if output_format == 'cv2':
        return cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)
    else:
        return pil_img


def imread_korean_path(filepath):
    """
    한글 경로를 지원하는 이미지 읽기 함수.

    cv2.imread()는 한글 경로를 지원하지 않으므로
    numpy.fromfile + cv2.imdecode 조합 사용.

    Args:
        filepath: 이미지 파일 경로 (한글 포함 가능)

    Returns:
        numpy.ndarray (BGR) 또는 None (파일 없음/읽기 실패)
    """
    try:
        img_array = np.fromfile(filepath, dtype=np.uint8)
        return cv2.imdecode(img_array, cv2.IMREAD_COLOR)
    except Exception:
        return None

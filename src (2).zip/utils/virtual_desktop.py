# -*- coding: utf-8 -*-
"""
캡처 및 편리모드 유틸리티 모듈
- 창 직접 캡처 (PrintWindow)
- 편리모드 지원 (모니터 밖 이동 방식)

Note: 이전 버전의 가상 데스크톱 방식은 Chrome 렌더링 문제로 폐기됨
      새 방식은 Chrome 플래그 + 모니터 밖 이동 사용
"""

import ctypes
import time

import win32gui
import win32ui
import win32con
import numpy as np
import cv2
from PIL import Image

# 편리모드 모듈 임포트
try:
    from utils.convenience_mode import (
        get_convenience_mode as _get_convenience_mode,
        is_available as _convenience_available,
        post_click, screen_to_client
    )
    CONVENIENCE_AVAILABLE = True
except ImportError:
    CONVENIENCE_AVAILABLE = False
    def _get_convenience_mode(): return None
    def _convenience_available(): return False


# ============================================================
# 창 직접 캡처 (PrintWindow API)
# ============================================================

def capture_window(hwnd, output_format='cv2', use_wgc=False):
    """
    특정 창만 캡처 (PrintWindow 사용)

    Args:
        hwnd: 창 핸들
        output_format: 'cv2' 또는 'pil'
        use_wgc: 사용 안 함 (하위 호환용)

    Returns:
        캡처된 이미지 (cv2 또는 PIL)
    """
    try:
        # 창 크기 가져오기
        left, top, right, bottom = win32gui.GetWindowRect(hwnd)
        width = right - left
        height = bottom - top

        if width <= 0 or height <= 0:
            return None

        # DC 생성
        hwnd_dc = win32gui.GetWindowDC(hwnd)
        mfc_dc = win32ui.CreateDCFromHandle(hwnd_dc)
        save_dc = mfc_dc.CreateCompatibleDC()

        # 비트맵 생성
        bitmap = win32ui.CreateBitmap()
        bitmap.CreateCompatibleBitmap(mfc_dc, width, height)
        save_dc.SelectObject(bitmap)

        # PrintWindow로 캡처 (PW_RENDERFULLCONTENT = 2)
        result = ctypes.windll.user32.PrintWindow(hwnd, save_dc.GetSafeHdc(), 2)

        if result == 0:
            # 실패 시 기본 BitBlt 시도
            save_dc.BitBlt((0, 0), (width, height), mfc_dc, (0, 0), win32con.SRCCOPY)

        # 비트맵 데이터 추출
        bmp_info = bitmap.GetInfo()
        bmp_str = bitmap.GetBitmapBits(True)

        # PIL 이미지로 변환
        pil_img = Image.frombuffer(
            'RGB',
            (bmp_info['bmWidth'], bmp_info['bmHeight']),
            bmp_str, 'raw', 'BGRX', 0, 1
        )

        # 정리
        win32gui.DeleteObject(bitmap.GetHandle())
        save_dc.DeleteDC()
        mfc_dc.DeleteDC()
        win32gui.ReleaseDC(hwnd, hwnd_dc)

        if output_format == 'cv2':
            return cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)
        else:
            return pil_img

    except Exception as e:
        print(f"[오류] 창 캡처 실패: {e}")
        return None


# ============================================================
# 편리모드 인터페이스 (하위 호환)
# ============================================================

def is_available():
    """편리모드 사용 가능 여부"""
    return CONVENIENCE_AVAILABLE and _convenience_available()


def get_convenience_mode():
    """편리모드 인스턴스 반환"""
    if CONVENIENCE_AVAILABLE:
        return _get_convenience_mode()
    return None


def click_in_virtual_desktop(hwnd, click_x, click_y, method='post_message'):
    """
    편리모드에서 클릭 수행 (SendMessage 사용)

    Args:
        hwnd: 창 핸들
        click_x, click_y: 화면 좌표
        method: 사용 안 함 (하위 호환용)

    Returns:
        성공 여부
    """
    if not CONVENIENCE_AVAILABLE:
        # 편리모드 불가 시 일반 클릭
        import pyautogui
        pyautogui.click(click_x, click_y)
        return True

    # hwnd가 있고 창이 화면 밖에 있으면 직접 SendMessage 클릭
    if hwnd:
        try:
            window_rect = win32gui.GetWindowRect(hwnd)
            # 창이 화면 밖(Y < -2000)에 있으면 편리모드
            if window_rect[1] < -2000:
                # 화면 좌표 → 클라이언트 좌표 변환
                client_coords = screen_to_client(hwnd, click_x, click_y)
                if client_coords:
                    client_x, client_y = client_coords
                    print(f"  (편리모드 클릭: 화면({click_x},{click_y}) → 클라이언트({client_x},{client_y}))")
                    return post_click(hwnd, client_x, client_y)
                else:
                    # 좌표 변환 실패 시 창 기준 상대 좌표로 시도
                    rel_x = click_x - window_rect[0]
                    rel_y = click_y - window_rect[1]
                    print(f"  (편리모드 클릭 폴백: 상대좌표({rel_x},{rel_y}))")
                    return post_click(hwnd, rel_x, rel_y)
        except Exception as e:
            print(f"  (편리모드 클릭 오류: {e})")

    # 편리모드 인스턴스 가져오기 (기존 방식 fallback)
    mode = _get_convenience_mode()
    if mode and mode.is_active:
        return mode.click(click_x, click_y)

    # 편리모드 비활성 시 일반 클릭
    import pyautogui
    pyautogui.click(click_x, click_y)
    return True


# ============================================================
# 테스트
# ============================================================

if __name__ == '__main__':
    import pyautogui

    print("=" * 50)
    print("캡처 및 편리모드 유틸리티 테스트")
    print("=" * 50)

    print(f"\n편리모드 사용 가능: {is_available()}")

    # 강의실 창 테스트
    windows = pyautogui.getWindowsWithTitle('강의실')
    if windows:
        win = windows[0]
        hwnd = win._hWnd
        print(f"\n강의실 창 발견: hwnd={hwnd}")

        # 창 캡처 테스트
        print("\n--- PrintWindow 캡처 테스트 ---")
        t1 = time.perf_counter()
        img = capture_window(hwnd, output_format='cv2')
        t2 = time.perf_counter()

        if img is not None:
            print(f"캡처 성공: {img.shape[1]}x{img.shape[0]}")
            print(f"캡처 시간: {(t2-t1)*1000:.1f}ms")

            cv2.imwrite('test_capture.png', img)
            print("test_capture.png 저장됨")
        else:
            print("캡처 실패")
    else:
        print("\n강의실 창 없음")

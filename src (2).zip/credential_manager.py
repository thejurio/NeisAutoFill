# -*- coding: utf-8 -*-
# 파일: src/credential_manager.py
# 역할: 연수원 계정 정보 암호화 저장/로드

import os
import sys
import json
import base64
import hashlib
import threading
from pathlib import Path

# 로거
try:
    from logger import log_info, log_warning, log_error, log_debug
except ImportError:
    def log_info(msg): print(f"[INFO] {msg}")
    def log_warning(msg): print(f"[WARN] {msg}")
    def log_error(msg, exc_info=False): print(f"[ERROR] {msg}")
    def log_debug(msg): print(f"[DEBUG] {msg}")


class CredentialManager:
    """
    연수원 계정 관리자 (암호화 저장)

    - 아이디/비밀번호를 머신별 고유 키로 암호화
    - settings.json에 저장
    """

    _APP_SECRET = "DooClick_V4_Credential_2026"

    def __init__(self, settings_path=None):
        if settings_path is None:
            if getattr(sys, 'frozen', False) or "__compiled__" in globals():
                self._settings_path = Path(sys.executable).parent / 'settings.json'
            else:
                self._settings_path = Path(__file__).parent.parent / 'settings.json'
        else:
            self._settings_path = Path(settings_path)

        # 암호화 키 (머신별 고유)
        self._cipher_key = self._generate_cipher_key()

        # 캐시된 계정 정보
        self._username = None
        self._password = None

        # 설정에서 계정 로드
        self._load_credentials()

    def _generate_cipher_key(self):
        """머신 고유 암호화 키 생성"""
        machine_id = f"{os.getenv('USERNAME', 'user')}_{os.getenv('COMPUTERNAME', 'pc')}"
        combined = f"{machine_id}_{self._APP_SECRET}"
        return hashlib.sha256(combined.encode()).digest()

    def _encrypt(self, plaintext):
        """문자열 암호화 (XOR + Base64)"""
        if not plaintext:
            return ""
        encrypted_bytes = bytes([
            ord(c) ^ self._cipher_key[i % len(self._cipher_key)]
            for i, c in enumerate(plaintext)
        ])
        return base64.b64encode(encrypted_bytes).decode('utf-8')

    def _decrypt(self, ciphertext):
        """암호화된 문자열 복호화"""
        if not ciphertext:
            return ""
        try:
            encrypted_bytes = base64.b64decode(ciphertext.encode('utf-8'))
            decrypted = ''.join([
                chr(b ^ self._cipher_key[i % len(self._cipher_key)])
                for i, b in enumerate(encrypted_bytes)
            ])
            return decrypted
        except Exception as e:
            log_error(f"복호화 실패: {e}")
            return ""

    def _load_credentials(self):
        """설정 파일에서 계정 정보 로드"""
        try:
            if self._settings_path.exists():
                with open(self._settings_path, 'r', encoding='utf-8') as f:
                    settings = json.load(f)

                encrypted_username = settings.get('credential_username', '')
                encrypted_password = settings.get('credential_password', '')

                if encrypted_username:
                    self._username = self._decrypt(encrypted_username)
                if encrypted_password:
                    self._password = self._decrypt(encrypted_password)

                if self._username:
                    log_info(f"계정 정보 로드됨: {self._username}")
        except Exception as e:
            log_error(f"계정 로드 실패: {e}")

    def save_credentials(self, username, password):
        """계정 정보 저장 (암호화)

        Args:
            username: 아이디
            password: 비밀번호

        Returns:
            bool: 성공 여부
        """
        try:
            settings = {}
            if self._settings_path.exists():
                with open(self._settings_path, 'r', encoding='utf-8') as f:
                    settings = json.load(f)

            if username and password:
                settings['credential_username'] = self._encrypt(username)
                settings['credential_password'] = self._encrypt(password)
                self._username = username
                self._password = password
                log_info(f"계정 정보 저장됨: {username}")
            else:
                # 삭제
                settings.pop('credential_username', None)
                settings.pop('credential_password', None)
                self._username = None
                self._password = None
                log_info("계정 정보 삭제됨")

            with open(self._settings_path, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            log_error(f"계정 저장 실패: {e}")
            return False

    def get_credentials(self):
        """저장된 계정 정보 반환

        Returns:
            tuple: (username, password) 또는 (None, None)
        """
        return (self._username, self._password)

    def has_credentials(self):
        """계정 정보 존재 여부"""
        return bool(self._username and self._password)

    def get_username_display(self):
        """아이디 표시용 (전체 표시)"""
        return self._username or ""

    def clear_credentials(self):
        """계정 정보 삭제"""
        return self.save_credentials(None, None)


# ========== 싱글톤 ==========
_manager_instance = None
_manager_lock = threading.Lock()


def get_credential_manager():
    """계정 관리자 싱글톤 인스턴스 반환 (스레드 안전)"""
    global _manager_instance
    if _manager_instance is None:
        with _manager_lock:
            if _manager_instance is None:
                _manager_instance = CredentialManager()
    return _manager_instance


# ========== 편의 함수 ==========

def save_credentials(username, password):
    """계정 정보 저장"""
    return get_credential_manager().save_credentials(username, password)


def get_credentials():
    """계정 정보 반환"""
    return get_credential_manager().get_credentials()


def has_credentials():
    """계정 정보 존재 여부"""
    return get_credential_manager().has_credentials()


def clear_credentials():
    """계정 정보 삭제"""
    return get_credential_manager().clear_credentials()


# ========== 테스트 ==========

if __name__ == '__main__':
    print("=== Credential Manager 테스트 ===\n")

    manager = CredentialManager()

    print(f"계정 존재: {manager.has_credentials()}")
    print(f"저장된 아이디: {manager.get_username_display()}")

    # 테스트 저장
    # manager.save_credentials("test_user", "test_password")
    # print(f"\n저장 후:")
    # print(f"계정 존재: {manager.has_credentials()}")
    # username, password = manager.get_credentials()
    # print(f"아이디: {username}, 비밀번호: {'*' * len(password) if password else '없음'}")

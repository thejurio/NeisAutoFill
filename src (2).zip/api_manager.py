# -*- coding: utf-8 -*-
# 파일: src/api_manager.py
# 역할: API 키 관리 (서버 기반 + 로컬 폴백)
# 수정일: 2026-01-29 (서버 방식 추가)

import os
import sys
import json
import base64
import hashlib
import threading
import requests
from pathlib import Path

# 로거
try:
    from logger import log_info, log_warning, log_error, log_debug
except ImportError:
    def log_info(msg): print(f"[INFO] {msg}")
    def log_warning(msg): print(f"[WARN] {msg}")
    def log_error(msg, exc_info=False): print(f"[ERROR] {msg}")
    def log_debug(msg): print(f"[DEBUG] {msg}")


# ========== 서버 설정 ==========
# GAS 웹앱 배포 후 아래 URL과 토큰 수정
API_SERVER_URL = "https://script.google.com/macros/s/AKfycbwVAZtMv21dgB1u6qEjoW0Iuf-dSVM_jjIHlbmhT-vQo7evaPEkvcLYfNWZKQjnnKpE/exec"
API_SERVER_TOKEN = "dooclick_secure_token_2026"  # GAS의 APP_TOKEN과 동일하게
SERVER_TIMEOUT = 10  # 서버 요청 타임아웃 (초)


class APIKeyManager:
    """
    API 키 관리자 (서버 + 로컬 하이브리드)

    우선순위:
    1. 사용자 키 (로컬 저장, 머신별 암호화)
    2. 서버 키 (GAS에서 가져옴)
    3. 로컬 프리셋 키 (폴백용)
    """

    _APP_SECRET = "DooClick_V4_SecretKey_2026"

    def __init__(self, settings_path=None):
        if settings_path is None:
            if getattr(sys, 'frozen', False) or "__compiled__" in globals():
                self._settings_path = Path(sys.executable).parent / 'settings.json'
            else:
                self._settings_path = Path(__file__).parent.parent / 'settings.json'
        else:
            self._settings_path = Path(settings_path)

        # 암호화 키 (사용자 키용 - 머신별 고유)
        self._cipher_key = self._generate_cipher_key()

        # 사용자 키
        self._user_key = None
        self._user_key_exhausted = False

        # 서버에서 받은 키
        self._server_key = None
        self._server_key_hint = None  # 마지막 4자리 (서버에 전달용)

        # 서버 사용 가능 여부
        self._server_available = bool(API_SERVER_URL)

        # 설정에서 사용자 키 로드
        self._load_user_key()

    def _generate_cipher_key(self):
        """머신 고유 암호화 키 생성"""
        machine_id = f"{os.getenv('USERNAME', 'user')}_{os.getenv('COMPUTERNAME', 'pc')}"
        combined = f"{machine_id}_{self._APP_SECRET}"
        return hashlib.sha256(combined.encode()).digest()

    def _encrypt(self, plaintext):
        """문자열 암호화 (XOR + Base64)"""
        if not plaintext:
            return ""
        encrypted_bytes = bytes([
            ord(c) ^ self._cipher_key[i % len(self._cipher_key)]
            for i, c in enumerate(plaintext)
        ])
        return base64.b64encode(encrypted_bytes).decode('utf-8')

    def _decrypt(self, ciphertext):
        """암호화된 문자열 복호화"""
        if not ciphertext:
            return ""
        try:
            encrypted_bytes = base64.b64decode(ciphertext.encode('utf-8'))
            decrypted = ''.join([
                chr(b ^ self._cipher_key[i % len(self._cipher_key)])
                for i, b in enumerate(encrypted_bytes)
            ])
            return decrypted
        except Exception as e:
            log_error(f"복호화 실패: {e}")
            return ""

    # ========== 사용자 키 관리 ==========

    def _load_user_key(self):
        """설정 파일에서 사용자 키 로드"""
        try:
            if self._settings_path.exists():
                with open(self._settings_path, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                encrypted_key = settings.get('api_key_encrypted', '')
                if encrypted_key:
                    self._user_key = self._decrypt(encrypted_key)
                    if self._user_key:
                        log_info(f"사용자 API 키 로드됨: ...{self._user_key[-4:]}")
        except Exception as e:
            log_error(f"사용자 키 로드 실패: {e}")

    def save_user_key(self, api_key):
        """사용자 API 키 저장 (암호화)"""
        try:
            settings = {}
            if self._settings_path.exists():
                with open(self._settings_path, 'r', encoding='utf-8') as f:
                    settings = json.load(f)

            if api_key:
                settings['api_key_encrypted'] = self._encrypt(api_key)
                self._user_key = api_key
                self._user_key_exhausted = False
                log_info(f"사용자 API 키 저장됨: ...{api_key[-4:]}")
            else:
                settings.pop('api_key_encrypted', None)
                self._user_key = None
                log_info("사용자 API 키 삭제됨")

            with open(self._settings_path, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            log_error(f"사용자 키 저장 실패: {e}")
            return False

    def get_user_key_display(self):
        """사용자 키 표시용 (마지막 4자리만)"""
        if self._user_key and len(self._user_key) >= 4:
            return f"****...{self._user_key[-4:]}"
        return ""

    def has_user_key(self):
        """사용자 키 존재 여부"""
        return bool(self._user_key)

    # ========== 서버 키 관리 ==========

    def _fetch_key_from_server(self):
        """서버에서 API 키 가져오기"""
        if not self._server_available:
            return None

        try:
            url = f"{API_SERVER_URL}?token={API_SERVER_TOKEN}&action=getKey"
            response = requests.get(url, timeout=SERVER_TIMEOUT)
            response.raise_for_status()

            # 응답이 JSON인지 확인
            content_type = response.headers.get('Content-Type', '')
            if 'application/json' not in content_type and 'text/javascript' not in content_type:
                # GAS는 text/javascript로 응답할 수 있음
                body_preview = response.text[:200]
                log_warning(f"서버 응답이 JSON이 아님 (Content-Type: {content_type})")
                log_debug(f"응답 내용: {body_preview}")
                return None

            data = response.json()
            if data.get('success'):
                self._server_key = data.get('apiKey')
                self._server_key_hint = data.get('keyHint')
                available = data.get('availableCount', '?')
                log_info(f"서버에서 API 키 수신: ...{self._server_key_hint} (남은 키: {available})")
                return self._server_key
            else:
                error = data.get('error', '알 수 없는 오류')
                log_warning(f"서버 키 요청 실패: {error}")
                return None

        except requests.exceptions.Timeout:
            log_warning("서버 응답 타임아웃")
            self._server_available = False
            return None
        except requests.exceptions.ConnectionError as e:
            log_warning(f"서버 연결 실패: {e}")
            self._server_available = False
            return None
        except (ValueError, KeyError) as e:
            # JSON 파싱 실패
            body_preview = response.text[:200] if 'response' in dir() else '(응답 없음)'
            log_warning(f"서버 응답 파싱 실패: {e}")
            log_debug(f"응답 내용: {body_preview}")
            return None
        except Exception as e:
            log_error(f"서버 키 요청 오류: {e}")
            return None

    def _report_exhausted_to_server(self):
        """서버에 키 한도 초과 알림"""
        if not self._server_available or not self._server_key_hint:
            return False

        try:
            url = f"{API_SERVER_URL}?token={API_SERVER_TOKEN}&action=markExhausted&keyHint={self._server_key_hint}"
            response = requests.get(url, timeout=SERVER_TIMEOUT)
            data = response.json()

            if data.get('success'):
                log_info(f"서버에 키 한도 초과 보고: ...{self._server_key_hint}")
                self._server_key = None
                self._server_key_hint = None
                return True
            return False

        except Exception as e:
            log_error(f"서버 보고 실패: {e}")
            return False

    # ========== 통합 키 관리 ==========

    def get_api_key(self):
        """
        사용 가능한 API 키 반환

        우선순위:
        1. 사용자 키 (한도 초과 아니면)
        2. 캐시된 서버 키 (이전에 받은 키 재사용)
        3. 서버에서 새 키 요청
        4. None
        """
        # 1. 사용자 키 우선
        if self._user_key and not self._user_key_exhausted:
            log_debug("사용자 API 키 사용")
            return self._user_key

        # 2. 캐시된 서버 키 재사용 (한도 초과 안 됐으면)
        if self._server_key:
            log_debug(f"캐시된 서버 키 사용: ...{self._server_key_hint}")
            return self._server_key

        # 3. 서버에서 새 키 요청
        if self._server_available:
            server_key = self._fetch_key_from_server()
            if server_key:
                return server_key

        # 4. 사용 가능한 키 없음
        log_warning("사용 가능한 API 키가 없습니다")
        return None

    def mark_key_exhausted(self):
        """현재 사용 중인 키를 한도 초과로 표시"""
        # 사용자 키 사용 중이었으면
        if self._user_key and not self._user_key_exhausted:
            self._user_key_exhausted = True
            log_warning("사용자 API 키 한도 초과 - 서버 키로 전환")
            return

        # 서버 키 사용 중이었으면
        if self._server_key:
            self._report_exhausted_to_server()

    def reset_exhausted_keys(self):
        """한도 초과 상태 초기화"""
        self._user_key_exhausted = False
        self._server_key = None
        self._server_key_hint = None
        self._server_available = bool(API_SERVER_URL)
        log_info("API 키 상태 초기화")

    def get_status(self):
        """API 키 상태 정보"""
        return {
            'has_user_key': self.has_user_key(),
            'user_key_display': self.get_user_key_display(),
            'user_key_exhausted': self._user_key_exhausted,
            'server_available': self._server_available,
            'server_configured': bool(API_SERVER_URL),
        }


# ========== 싱글톤 ==========
_manager_instance = None
_manager_lock = threading.Lock()


def get_api_manager():
    """API 관리자 싱글톤 인스턴스 반환 (스레드 안전)"""
    global _manager_instance
    if _manager_instance is None:
        with _manager_lock:
            # Double-checked locking
            if _manager_instance is None:
                _manager_instance = APIKeyManager()
    return _manager_instance


# ========== 편의 함수 ==========

def get_api_key():
    """현재 사용 가능한 API 키 반환"""
    return get_api_manager().get_api_key()


def mark_key_exhausted():
    """현재 키를 한도 초과로 표시"""
    get_api_manager().mark_key_exhausted()


def save_user_api_key(api_key):
    """사용자 API 키 저장"""
    return get_api_manager().save_user_key(api_key)


def get_user_key_display():
    """사용자 키 표시용 문자열"""
    return get_api_manager().get_user_key_display()


# ========== 테스트 ==========

if __name__ == '__main__':
    print("=== API Key Manager (서버 모드) ===\n")

    manager = APIKeyManager()
    status = manager.get_status()

    print(f"사용자 키 존재: {status['has_user_key']}")
    print(f"사용자 키 표시: {status['user_key_display']}")
    print(f"서버 설정됨: {status['server_configured']}")
    print(f"서버 사용 가능: {status['server_available']}")

    if not status['server_configured']:
        print("\n[주의] API_SERVER_URL이 설정되지 않았습니다.")
        print("GAS 웹앱 배포 후 URL을 설정하세요.")
    else:
        print("\n[테스트] 서버에서 키 가져오기...")
        key = manager.get_api_key()
        if key:
            print(f"받은 키: ...{key[-4:]}")
        else:
            print("키를 받지 못했습니다.")

﻿# -*- coding: utf-8 -*-
# 파일 이름: src/problem_solver.py
# 역할: OCR과 Gemini를 연동하여 '현재 활성화된 창'의 문제를 풉니다.

import time
import pyautogui
import ocr_manager
import gemini_solver

# --- 설정 (환경변수에서 로드) ---
try:
    from config import TARGET_WINDOW_TITLE_QUIZ, GEMINI_API_KEY
    TARGET_WINDOW_TITLE_SUBSTRING = TARGET_WINDOW_TITLE_QUIZ
except ImportError:
    import os
    TARGET_WINDOW_TITLE_SUBSTRING = "전북교육연수포털"
    GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY')

def solve_problem():
    """
    문제 풀이의 전체 과정을 지휘하는 메인 함수
    """
    print("--- 자동 문제 풀이 시작 ---")

    # 1. 현재 활성화된 창을 가져옵니다.
    print("1. 현재 활성화된 창을 확인합니다...")
    active_window = pyautogui.getActiveWindow()
    
    if not active_window:
        print(" -> 현재 활성화된 창이 없습니다. 문제 풀이를 중단합니다.")
        return
        
    # 2. 활성화된 창의 제목이 우리가 원하는 창이 맞는지 확인합니다.
    if TARGET_WINDOW_TITLE_SUBSTRING not in active_window.title:
        print(f" -> 현재 활성 창('{active_window.title}')은 목표가 아닙니다.")
        return
        
    # 3. 문제 풀이 영역을 활성 창의 영역으로 동적 설정합니다.
    problem_region = (active_window.left, active_window.top, active_window.width, active_window.height)
    print(f" -> 목표 창을 확인했습니다. 문제 풀이 영역: {problem_region}")

    # 4. '눈'을 사용하여 문제 영역의 모든 텍스트를 읽어옵니다.
    print(f"\n2. 화면 영역에서 문제 텍스트를 추출합니다...")
    question_text = ocr_manager.extract_text_from_region(problem_region)
    
    if not question_text or len(question_text.strip()) < 5:
        print(" -> 문제 영역에서 유의미한 텍스트를 읽어오지 못했습니다.")
        return

    print("\n[인식된 문제 텍스트]")
    print(question_text)
    print("-" * 20)

    # 5. '두뇌'에게 읽어온 텍스트를 보내 정답을 물어봅니다.
    print("3. Gemini에게 정답을 물어보는 중...")
    # api_key=None 전달 시 환경변수의 GEMINI_API_KEY 사용
    answer_text = gemini_solver.get_answer_from_gemini(None, question_text)
    
    if "오류 발생" in answer_text:
        print(f" -> AI 응답 생성에 실패했습니다: {answer_text}")
        return

    print(f"\n[Gemini가 찾은 정답]\n{answer_text}")
    print("-" * 20)
    
    # 6. (향후 과제) 화면에서 '정답 텍스트'의 위치를 찾아 클릭하는 로직
    print(f"4. (구현 필요) 화면에서 정답 '{answer_text}'의 위치를 찾아 클릭해야 합니다.")


# 이 파일이 직접 실행될 때, solve_problem() 함수를 호출합니다.
# src/ocr_manager.py 파일의 맨 아래 테스트 부분을 이 코드로 교체합니다.

if __name__ == '__main__':
    print("OCR 관리자 모듈 정밀 검사 테스트를 시작합니다.")
    print("자동으로 풀고 싶은 '시험창'을 화면에 띄워주세요.")
    
    # 테스트할 창의 제목을 지정합니다.
    TARGET_WINDOW_TITLE = "전북교육연수포털"
    
    print(f"5초 후에 '{TARGET_WINDOW_TITLE}' 창을 감지하고 OCR을 시도합니다...")
    time.sleep(5)

    # 1. 활성화된 창을 찾아 영역을 가져옵니다.
    active_window = pyautogui.getActiveWindow()
    if active_window and TARGET_WINDOW_TITLE in active_window.title:
        test_region = (active_window.left, active_window.top, active_window.width, active_window.height)
        print(f"'{active_window.title}' 창을 확인했습니다. 영역: {test_region}")
        
        # 2. (핵심) 분석할 이미지를 파일로 저장해서 우리 눈으로 확인합니다.
        try:
            screenshot = pyautogui.screenshot(region=test_region)
            debug_image_path = "ocr_debug_image.png"
            screenshot.save(debug_image_path)
            print(f"'{debug_image_path}' 파일로 분석 대상 이미지를 저장했습니다.")
        except Exception as e:
            print(f"스크린샷 저장 중 오류 발생: {e}")
            exit()

        # 3. 저장된 이미지 파일로부터 텍스트를 추출합니다.
        text = ocr_manager.extract_text_from_region(test_region)

        print("\n--- OCR 인식 결과 ---")
        if text:
            print(text)
        else:
            print("텍스트를 인식하지 못했습니다.")
        print("--------------------")

    else:
        print("활성화된 창이 '전북교육연수포털'이 아닙니다. 테스트를 중단합니다.")
﻿# -*- coding: utf-8 -*-
# 파일 이름: src/ocr_google.py (환경변수 인증 버전)
# 역할: Google Cloud Vision API를 이용한 OCR 처리

import os
import io
import time
import pyautogui
import cv2
import numpy as np
import win32api
import win32gui
import win32con
import win32ui
from PIL import Image
# google-cloud-vision 라이브러리를 사용합니다.
from google.cloud import vision

# --- Google Cloud 인증 설정 (환경변수 방식) ---
# 설정 방법:
#   Windows CMD: set GOOGLE_APPLICATION_CREDENTIALS=C:\path\to\your\credentials.json
#   Windows PowerShell: $env:GOOGLE_APPLICATION_CREDENTIALS="C:\path\to\your\credentials.json"
#
# 주의: 서비스 계정 키 파일(*.json)은 절대 Git에 커밋하지 마세요!
try:
    from config import GOOGLE_CREDENTIALS_PATH, validate_google_credentials
    if GOOGLE_CREDENTIALS_PATH:
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = GOOGLE_CREDENTIALS_PATH
except ImportError:
    # config 모듈이 없을 경우 환경변수 직접 확인
    if not os.environ.get('GOOGLE_APPLICATION_CREDENTIALS'):
        print("[경고] GOOGLE_APPLICATION_CREDENTIALS 환경변수가 설정되지 않았습니다.")


def screenshot_pywin32(region=None):
    """pywin32를 사용하여 안정적으로 화면을 캡처하여 Pillow 이미지 객체로 반환합니다."""
    if region:
        left, top, width, height = region
    else:
        width = win32api.GetSystemMetrics(win32con.SM_CXVIRTUALSCREEN)
        height = win32api.GetSystemMetrics(win32con.SM_CYVIRTUALSCREEN)
        left = win32api.GetSystemMetrics(win32con.SM_XVIRTUALSCREEN)
        top = win32api.GetSystemMetrics(win32con.SM_YVIRTUALSCREEN)
    hdesktop = win32gui.GetDesktopWindow()
    desktop_dc = win32gui.GetWindowDC(hdesktop)
    img_dc = win32ui.CreateDCFromHandle(desktop_dc)
    mem_dc = img_dc.CreateCompatibleDC()
    screenshot = win32ui.CreateBitmap()
    screenshot.CreateCompatibleBitmap(img_dc, width, height)
    mem_dc.SelectObject(screenshot)
    mem_dc.BitBlt((0, 0), (width, height), img_dc, (left, top), win32con.SRCCOPY)
    signed_ints_array = screenshot.GetBitmapBits(True)
    pil_img = Image.frombuffer('RGB', (width, height), signed_ints_array, 'raw', 'BGRX', 0, 1)
    win32gui.DeleteObject(screenshot.GetHandle())
    mem_dc.DeleteDC()
    img_dc.DeleteDC()
    win32gui.ReleaseDC(hdesktop, desktop_dc)
    return pil_img

def extract_text_from_image(pil_image):
    """google-cloud-vision 라이브러리를 사용하여 텍스트를 추출합니다."""
    try:
        client = vision.ImageAnnotatorClient()
        img_byte_arr = io.BytesIO()
        pil_image.save(img_byte_arr, format='PNG')
        content = img_byte_arr.getvalue()
        
        image = vision.Image(content=content)
        response = client.document_text_detection(image=image)
        
        if response.error.message:
            raise Exception(response.error.message)
        
        if response.full_text_annotation:
            return response.full_text_annotation.text.strip()
        return ""
    except Exception as e:
        print(f"\n[오류] Vision API 처리 중 문제가 발생했습니다: {e}")
        return ""

def find_problem_area_and_ocr(window_region):
    """창 스크린샷에서 문제 영역을 찾아 OCR을 수행하고, 텍스트를 반환합니다."""
    print("[1/5] 원본 창 스크린샷 저장 완료.")
    screenshot_pil = screenshot_pywin32(region=window_region)
    screenshot_pil.save("debug_01_original_window.png")
    
    screenshot_cv = cv2.cvtColor(np.array(screenshot_pil), cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(screenshot_cv, cv2.COLOR_BGR2GRAY)
    binary = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 11, 2)
    cv2.imwrite("debug_02_binary.png", binary)
    print("[2/5] 흑백 변환 이미지 저장 완료.")
    
    contours, _ = cv2.findContours(binary, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    if not contours: return None
    
    candidate_contours = []
    window_area = window_region[2] * window_region[3]
    for c in contours:
        area = cv2.contourArea(c)
        if area < (window_area * 0.05) or area > (window_area * 0.95):
            continue
        candidate_contours.append(c)
    
    if not candidate_contours:
        problem_contour = np.array([[0,0], [window_region[2], 0], [window_region[2], window_region[3]], [0, window_region[3]]])
    else:
        problem_contour = max(candidate_contours, key=cv2.contourArea)
        
    contour_img = screenshot_cv.copy()
    cv2.drawContours(contour_img, candidate_contours, -1, (0, 255, 0), 2)
    cv2.drawContours(contour_img, [problem_contour], -1, (255, 0, 0), 3)
    cv2.imwrite("debug_03_contours.png", contour_img)
    print("[3/5] 감지된 윤곽선 표시 이미지 저장 완료.")
    
    x, y, w, h = cv2.boundingRect(problem_contour)
    cropped_image_pil = screenshot_pil.crop((x, y, x + w, y + h))
    cropped_image_pil.save("debug_04_cropped.png")
    print("[4/5] 문제 영역만 잘라낸 이미지 저장 완료.")

    print("[5/5] Vision API에 텍스트 인식을 요청합니다...")
    extracted_text = extract_text_from_image(cropped_image_pil)
    print(" -> 요청 완료.")
    
    return extracted_text

# --- 독립 테스트용 코드 ---
if __name__ == '__main__':
    print("Google Vision OCR (환경변수 방식) 테스트를 시작합니다.")

    # 환경변수 확인
    creds_path = os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')
    if not creds_path:
        print("\n[오류] GOOGLE_APPLICATION_CREDENTIALS 환경변수가 설정되지 않았습니다.")
        print("설정 방법:")
        print("  Windows CMD: set GOOGLE_APPLICATION_CREDENTIALS=C:\\path\\to\\credentials.json")
        print("  Windows PowerShell: $env:GOOGLE_APPLICATION_CREDENTIALS=\"C:\\path\\to\\credentials.json\"")
        exit()
    else:
        # 경로만 표시 (파일 내용은 민감 정보)
        try:
            print(f"인증 파일: '{creds_path}'")
        except FileNotFoundError:
            print(f"[오류] '{JSON_PATH}' 파일을 찾을 수 없습니다. src 폴더에 파일이 있는지 확인해주세요.")
            exit()

        TARGET_WINDOW_TITLE = "전북교육연수포털"
        print(f"5초 후에 '{TARGET_WINDOW_TITLE}' 창을 감지하고 텍스트를 읽습니다...")
        time.sleep(5)
        
        active_window = pyautogui.getActiveWindow()
        if active_window and TARGET_WINDOW_TITLE in active_window.title:
            window_region = (active_window.left, active_window.top, active_window.width, active_window.height)
            print(f"'{active_window.title}' 창을 확인했습니다.")
            
            text = find_problem_area_and_ocr(window_region)
            
            print("\n--- OCR 인식 결과 (Google Cloud Vision) ---")
            if text:
                print(text)
            else:
                print("텍스트를 인식하지 못했습니다.")
            print("---------------------------------------")
        else:
            print("활성화된 창이 목표가 아닙니다.")
﻿# 파일 이름: src/convenience_mode.py
# 역할: '편리사용 모드'의 핵심 기술(백그라운드 클릭)을 테스트하는 프로토타입.

import win32gui
import win32con
import win32api
import time

# --- 설정 ---
TARGET_WINDOW_TITLE = "강의실"  # 창 제목에 이 단어가 '포함'된 창을 찾습니다.

# --- 새로운 창 탐색 함수 ---
def find_window_by_title_substring(title_substring):
    """
    주어진 문자열(substring)을 제목에 포함하는 첫 번째 창의 핸들(hwnd)을 찾습니다.
    """
    top_windows = []
    # EnumWindows: 현재 화면의 모든 최상위 창을 순회하는 함수
    # EnumWindowsProc: 각 창에 대해 실행될 콜백 함수. 여기서는 람다(lambda)로 간단히 구현
    win32gui.EnumWindows(lambda hwnd, _: top_windows.append(hwnd), None)
    
    for hwnd in top_windows:
        # 각 창의 제목을 가져와서, 찾으려는 문자열이 포함되어 있는지 확인
        if title_substring in win32gui.GetWindowText(hwnd):
            # 찾았으면 즉시 해당 핸들을 반환
            return hwnd
            
    # 모든 창을 다 찾아봐도 없으면 0을 반환
    return 0

# --- 백그라운드 클릭 함수 (이전과 동일) ---
def post_click(hwnd, x, y):
    """
    주어진 창(hwnd)의 특정 상대 좌표(x, y)에 백그라운드 클릭 신호를 보냅니다.
    """
    lParam = win32api.MAKELONG(x, y)
    win32gui.PostMessage(hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lParam)
    time.sleep(0.1)
    win32gui.PostMessage(hwnd, win32con.WM_LBUTTONUP, 0, lParam)
    print(f"'{hwnd}' 핸들을 가진 창의 ({x}, {y}) 좌표에 백그라운드 클릭 신호를 보냈습니다.")

# --- 메인 테스트 함수 ---
def test_convenience_mode():
    """편리사용 모드 테스트를 위한 메인 함수"""
    print("--- DOOCLICK V4.0.0: 편리사용 모드 프로토타입 (v1.1) 시작 ---")
    
    # 1. (수정됨) 새로운 함수를 사용하여 '강의실' 창의 핸들을 찾습니다.
    print(f"'{TARGET_WINDOW_TITLE}' 단어를 포함하는 창을 찾습니다...")
    hwnd = find_window_by_title_substring(TARGET_WINDOW_TITLE)
    
    if hwnd == 0:
        print(f"'{TARGET_WINDOW_TITLE}'을(를) 포함하는 창을 찾을 수 없습니다. 프로그램을 종료합니다.")
        return

    print(f"'{win32gui.GetWindowText(hwnd)}' 창을 찾았습니다 (핸들: {hwnd}).")
    
    # 2. 테스트할 좌표 설정 (이전과 동일)
    TEST_X = 943
    TEST_Y = 539
    
    print(f"5초 후에 ({TEST_X}, {TEST_Y}) 좌표를 백그라운드에서 클릭합니다...")
    time.sleep(5)
    
    # 3. 백그라운드 클릭 함수 호출 (이전과 동일)
    post_click(hwnd, TEST_X, TEST_Y)
    
    print("테스트 완료.")

if __name__ == '__main__':
    test_convenience_mode()
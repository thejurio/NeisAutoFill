﻿# -*- coding: utf-8 -*-
import pyautogui
import time
import os
import cv2
import numpy as np
import random
import ctypes

# --- 설정 ---
TARGET_WINDOW_TITLE = "강의실"
REF_FOLDER = 'ref'
SUPPORTED_SCALES = [100, 125, 150] 
CONFIDENCE_THRESHOLD = 0.8 

# --- 함수 정의 ---

def get_display_scaling():
    """현재 주 모니터의 디스플레이 배율을 감지합니다."""
    try:
        awareness = ctypes.c_int()
        ctypes.windll.shcore.GetProcessDpiAwareness(0, ctypes.byref(awareness))
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
        monitor = ctypes.windll.user32.MonitorFromPoint(0, 0)
        dpi_x, dpi_y = ctypes.c_uint(), ctypes.c_uint()
        ctypes.windll.shcore.GetDpiForMonitor(monitor, 0, ctypes.byref(dpi_x), ctypes.byref(dpi_y))
        scale = int(float(dpi_x.value) / 96 * 100)
        return scale
    except Exception as e:
        print(f"화면 배율 감지 중 오류 발생: {e}. 기본값 100으로 설정합니다.")
        return 100

def find_image_in_haystack(target_image_filename, scale_folder, haystack_img, search_region=None):
    """미리 찍어둔 스크린샷(haystack_img) 안에서 이미지를 찾습니다."""
    needle_path = os.path.join(REF_FOLDER, str(scale_folder), target_image_filename)
    if not os.path.exists(needle_path):
        return None
    try:
        needle_img = cv2.imread(needle_path)
        result = cv2.matchTemplate(haystack_img, needle_img, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(result)
        if max_val >= CONFIDENCE_THRESHOLD:
            print(f" (정보: {scale_folder}% 배율, '{target_image_filename}' 찾음) ", end='')
            needle_w, needle_h = needle_img.shape[1], needle_img.shape[0]
            if search_region:
                final_loc = (max_loc[0] + search_region[0], max_loc[1] + search_region[1], needle_w, needle_h)
                return final_loc
            else:
                return (max_loc[0], max_loc[1], needle_w, needle_h)
    except Exception:
        return None
    return None

def perform_human_click(location, target_name):
    """주어진 위치에 클릭하고, 마우스 위치 복원 및 랜덤 딜레이를 수행합니다."""
    print(f"\n[실행] -> '{target_name}' 클릭을 수행합니다.")
    original_position = pyautogui.position()
    center = pyautogui.center(location)
    pyautogui.moveTo(center) # 순간이동
    pyautogui.mouseDown()
    time.sleep(random.uniform(0.05, 0.15))
    pyautogui.mouseUp()
    pyautogui.moveTo(original_position) # 순간이동 복귀
    print(f"  (정보: 마우스 위치 {original_position} 복원)")
    delay_options = [(0.5, 2.0), (1.0, 4.0), (2.0, 5.0), (0.0, 6.0)]
    weights = [50, 30, 10, 10]
    chosen_range = random.choices(delay_options, weights=weights, k=1)[0]
    random_delay = random.uniform(chosen_range[0], chosen_range[1])
    print(f"  (정보: 클릭 후 {random_delay:.2f}초 대기)")
    time.sleep(random_delay)

# --- 메인 실행 로직 ---

def run_intelligent_active_mode():
    """'이중 확인' 로직이 포함된 최종 일반 모드 엔진."""
    print("--- DOOCLICK V4.0.0: 일반 모드 최종 버전 (v2.7 Double-Check) 시작 ---")
    
    current_scale = get_display_scaling()
    print(f"현재 감지된 화면 배율: {current_scale}%")
    if current_scale not in SUPPORTED_SCALES:
        print(f"경고: 감지된 배율({current_scale}%)은 지원 목록에 없습니다. 기본 100%로 작동합니다.")
        current_scale = 100
    
    IMAGE_FILES = ['1.png', '2.png', '3.png', '4.png', '5.png']

    while True:
        target_windows = pyautogui.getWindowsWithTitle(TARGET_WINDOW_TITLE)
        if not target_windows:
            print(f"'{TARGET_WINDOW_TITLE}' 창을 찾을 수 없습니다...", end='\r')
            time.sleep(1)
            continue

        target_window = target_windows[0]
        search_region = (target_window.left, target_window.top, target_window.width, target_window.height)
        
        print("\n화면 탐색 중... (1차 스냅샷)", end='')
        screenshot_image = pyautogui.screenshot(region=search_region)
        haystack_img = cv2.cvtColor(np.array(screenshot_image), cv2.COLOR_RGB2BGR)
        print(" -> ", end='')
        
        locations = {img: find_image_in_haystack(img, current_scale, haystack_img, search_region) for img in IMAGE_FILES}
        print("1차 탐색 완료.")

        # 최종 우선순위 로직 (이중 확인 기능 포함)
        if locations['1.png'] and locations['4.png'] and locations['5.png']:
            perform_human_click(locations['4.png'], '4.png')
            
        elif locations['2.png']:
            perform_human_click(locations['2.png'], '2.png')
            
        elif locations['3.png']:
            perform_human_click(locations['3.png'], '3.png')
            
        elif not locations['1.png'] and locations['5.png']:
            # [이중 확인 로직 시작] 1번은 없고 5번만 보이는 애매한 상황
            print("  (상황 감지: 1.png 없음, 5.png 있음. 이중 확인을 위해 잠시 대기합니다...)")
            time.sleep(random.uniform(0.5, 1.0)) # 0.5초~1초 대기
            
            print("  (재탐색: 2차 스냅샷)", end='')
            # 화면을 다시 찍어서 1번 이미지만 재확인
            screenshot_2nd = pyautogui.screenshot(region=search_region)
            haystack_2nd = cv2.cvtColor(np.array(screenshot_2nd), cv2.COLOR_RGB2BGR)
            location_1_reread = find_image_in_haystack('1.png', current_scale, haystack_2nd, search_region)
            print(" -> 재탐색 완료.")

            if location_1_reread:
                # 그 사이에 1번이 나타났다면, 진짜 규칙에 따라 4번을 클릭해야 함
                # (단, 4번이 여전히 보이는지 확인하는 것이 더 안전하지만, 일단은 4번이 있다고 가정)
                print("  (판단 변경: 1.png가 뒤늦게 발견되었습니다. 규칙에 따라 4.png를 클릭합니다.)")
                # 4번 이미지의 위치는 이전 스냅샷의 위치를 사용하거나, 다시 찾아야 함.
                # 여기서는 일관성을 위해 1차 탐색 시의 4번 위치를 사용.
                if locations['4.png']:
                    perform_human_click(locations['4.png'], '4.png')
                else:
                    print("  (오류: 4.png의 위치를 알 수 없어 행동을 취소합니다.)")

            else:
                # 재확인 후에도 1번이 없다면, 진짜로 5번만 있는 상황으로 최종 판단
                print("  (판단 확정: 1.png가 여전히 없습니다. 5.png를 클릭합니다.)")
                perform_human_click(locations['5.png'], '5.png')
        else:
            print("  (대기: 조건에 맞는 이미지를 찾지 못했습니다.)")
            time.sleep(1)

if __name__ == '__main__':
    run_intelligent_active_mode()
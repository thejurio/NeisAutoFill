# -*- coding: utf-8 -*-
# 파일 이름: src/launcher.py
# 역할: 랜덤 프로세스명으로 실행 (단일 파일 방식)
#
# 동작:
# 1. exe 실행 시 자기 자신을 랜덤 이름으로 temp에 복사
# 2. 복사본 실행 (랜덤 프로세스명)
# 3. 복사본에서 실제 프로그램 실행

import os
import sys
import shutil
import subprocess
import random
import tempfile
import glob

def is_compiled():
    """Nuitka 또는 PyInstaller로 빌드된 exe인지 확인"""
    # 1. PyInstaller 체크
    if getattr(sys, 'frozen', False):
        return True
    # 2. Nuitka 체크 (__compiled__는 메인 모듈에 있음)
    import __main__
    if hasattr(__main__, '__compiled__'):
        return True
    # 3. exe 파일로 실행 중인지 체크 (fallback)
    if sys.executable.lower().endswith('.exe') and not sys.executable.lower().endswith('python.exe'):
        return True
    return False


# 영어 단어처럼 보이는 랜덤 단어 생성용 음절
PREFIXES = ['pro', 'pre', 'con', 'com', 'dis', 'mis', 'sub', 'super', 'inter', 'trans', 'un', 're', 'de', 'ex', 'in', 'en', 'over', 'under', 'out', 'up']
ROOTS = ['ject', 'dict', 'duct', 'fer', 'form', 'graph', 'log', 'mit', 'port', 'scrib', 'spect', 'struct', 'tract', 'vert', 'vid', 'vis', 'aud', 'cap', 'ced', 'cept', 'cred', 'cur', 'fac', 'fect', 'fin', 'flex', 'flu', 'gen', 'gest', 'gress', 'hab', 'ject', 'jud', 'junct', 'lect', 'leg', 'loc', 'loqu', 'luc', 'man', 'mand', 'mem', 'ment', 'min', 'miss', 'mob', 'mot', 'nat', 'nom', 'not', 'nov', 'oper', 'ord', 'pand', 'par', 'path', 'ped', 'pel', 'pend', 'pet', 'plic', 'pon', 'pos', 'pot', 'prim', 'prob', 'quer', 'rect', 'rupt', 'sal', 'san', 'scend', 'sci', 'sec', 'sed', 'seg', 'sent', 'sequ', 'serv', 'sign', 'sim', 'sol', 'spec', 'stat', 'sti', 'strict', 'sum', 'tac', 'tain', 'tech', 'temp', 'ten', 'tend', 'term', 'terr', 'test', 'text', 'tort', 'val', 'ven', 'ver', 'voc', 'vol']
SUFFIXES = ['er', 'or', 'ion', 'tion', 'ation', 'ment', 'ness', 'ity', 'ty', 'al', 'ial', 'ly', 'ful', 'less', 'able', 'ible', 'ous', 'ive', 'ic', 'ist', 'ism', 'ize', 'ify', 'ant', 'ent', 'ary', 'ory', 'ure', 'age', 'dom', 'hood', 'ship']


def generate_random_name():
    """영어 단어처럼 보이는 랜덤 이름 생성"""
    # 랜덤하게 조합 방식 선택
    pattern = random.randint(1, 4)

    if pattern == 1:
        # prefix + root
        return random.choice(PREFIXES) + random.choice(ROOTS)
    elif pattern == 2:
        # root + suffix
        return random.choice(ROOTS) + random.choice(SUFFIXES)
    elif pattern == 3:
        # prefix + root + suffix
        return random.choice(PREFIXES) + random.choice(ROOTS) + random.choice(SUFFIXES)
    else:
        # root만
        return random.choice(ROOTS) + random.choice(ROOTS)


def get_marker_file():
    """마커 파일 경로 반환 (고정된 이름 없이 해시 기반)"""
    # 원본 exe 경로를 기반으로 고유 마커 파일명 생성
    import hashlib
    if is_compiled():
        base = os.path.dirname(sys.executable)
    else:
        base = os.path.dirname(os.path.abspath(__file__))

    # 경로 해시로 마커 파일명 생성 (탐지 방지)
    hash_val = hashlib.md5(base.encode()).hexdigest()[:8]
    return os.path.join(tempfile.gettempdir(), f'.{hash_val}.tmp')


def is_running_as_temp_copy():
    """임시 복사본으로 실행 중인지 확인"""
    if not is_compiled():
        return False  # 개발 모드

    temp_dir = tempfile.gettempdir().lower()
    exe_dir = os.path.dirname(sys.executable).lower()

    # temp 폴더에서 실행 중이면 복사본
    return temp_dir in exe_dir


def cleanup_old_temps():
    """이전 임시 파일 정리"""
    marker_file = get_marker_file()

    if os.path.exists(marker_file):
        try:
            with open(marker_file, 'r') as f:
                old_exe = f.read().strip()
            if os.path.exists(old_exe):
                os.remove(old_exe)
        except:
            pass

        try:
            os.remove(marker_file)
        except:
            pass


def launch_with_random_name():
    """랜덤 이름으로 자기 자신 복사 후 실행"""
    if not is_compiled():
        # 개발 모드: 그냥 main 실행
        return False

    # 이미 복사본으로 실행 중이면 메인 프로그램 실행
    if is_running_as_temp_copy():
        return False

    # 원본 exe에서 실행 중 -> 복사본 생성 후 실행
    original_exe = sys.executable
    original_dir = os.path.dirname(original_exe)

    # 이전 임시 파일 정리
    cleanup_old_temps()

    # 랜덤 이름으로 복사
    random_name = generate_random_name()
    temp_dir = tempfile.gettempdir()
    temp_exe = os.path.join(temp_dir, f'{random_name}.exe')

    try:
        shutil.copy2(original_exe, temp_exe)

        # 마커 파일에 경로 저장 (다음 실행 시 정리용)
        marker_file = get_marker_file()
        with open(marker_file, 'w') as f:
            f.write(temp_exe)

        # 복사본 실행 (원본 폴더를 작업 디렉토리로)
        subprocess.Popen(
            [temp_exe],
            cwd=original_dir,
            creationflags=subprocess.DETACHED_PROCESS
        )

        # 원본은 종료
        sys.exit(0)

    except Exception as e:
        print(f"[런처 오류] {e}")
        return False

    return True


def get_original_path():
    """원본 exe가 있는 경로 반환 (ref 폴더 등 접근용)"""
    if not is_compiled():
        # 개발 모드
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    if is_running_as_temp_copy():
        # 복사본에서 실행 중 -> 작업 디렉토리가 원본 경로
        return os.getcwd()
    else:
        # 원본에서 실행 중
        return os.path.dirname(sys.executable)

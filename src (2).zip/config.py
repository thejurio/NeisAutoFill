# -*- coding: utf-8 -*-
# 파일 이름: src/config.py
# 역할: 환경변수 및 설정값 중앙 관리 모듈

# --- 버전 정보 ---
__version__ = "4.11.0"
__version_info__ = (4, 11, 0)
APP_NAME = "DooClick"

import os
import sys
from pathlib import Path

# --- 프로젝트 경로 ---
def is_compiled():
    """Nuitka 또는 PyInstaller 빌드 여부 판별"""
    return getattr(sys, 'frozen', False) or "__compiled__" in globals()


def _is_running_from_temp():
    """임시 폴더에서 실행 중인지 확인 (launcher.py 복사본 실행 대응)"""
    import tempfile
    temp_dir = tempfile.gettempdir().lower()
    exe_dir = os.path.dirname(sys.executable).lower()
    return temp_dir in exe_dir


def get_project_root():
    """Nuitka/PyInstaller exe 빌드와 일반 Python 실행 모두 지원

    Note: launcher.py가 temp 폴더에 exe를 복사해서 실행하는 경우,
    sys.executable은 temp 폴더를 가리키므로 cwd(원본 폴더)를 사용
    """
    if is_compiled():
        if _is_running_from_temp():
            # temp에서 실행 중이면 작업 디렉토리(원본 폴더) 사용
            return Path(os.getcwd())
        return Path(sys.executable).parent
    else:
        return Path(__file__).parent.parent

PROJECT_ROOT = get_project_root()
SRC_DIR = PROJECT_ROOT / 'src'
REF_DIR = PROJECT_ROOT / 'ref'

# --- .env 파일 자동 로드 ---
# python-dotenv가 설치되어 있으면 .env 파일에서 환경변수 자동 로드
try:
    from dotenv import load_dotenv
    # 프로젝트 루트의 .env 파일 로드
    env_path = PROJECT_ROOT / '.env'
    if env_path.exists():
        load_dotenv(env_path)
        print(f"[config] .env 파일 로드 완료: {env_path}")
    else:
        print(f"[config] .env 파일 없음 (환경변수 직접 설정 필요)")
except ImportError:
    print("[config] python-dotenv 미설치. 환경변수를 직접 설정하세요.")

# --- API 키 설정 ---
# 환경변수에서 읽어오기 (없으면 None)
# 사용법:
#   1. .env 파일 생성 후 GEMINI_API_KEY=your_key 입력 (권장)
#   2. Windows CMD: set GEMINI_API_KEY=your_api_key_here
#   3. Windows PowerShell: $env:GEMINI_API_KEY="your_api_key_here"

GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY')
if GEMINI_API_KEY:
    masked = GEMINI_API_KEY[:8] + "..." + GEMINI_API_KEY[-4:]
    print(f"[config] API 키 로드됨: {masked}")
else:
    print("[config] API 키 없음!")

# Google Cloud Vision 인증 파일 경로
# 환경변수 GOOGLE_APPLICATION_CREDENTIALS로 설정
GOOGLE_CREDENTIALS_PATH = os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')

# --- 자동화 설정 ---
# 대상 창 제목
TARGET_WINDOW_TITLE = "강의실"
TARGET_WINDOW_TITLE_QUIZ = "전북교육연수포털"

# 이미지 매칭 설정
SUPPORTED_SCALES = [100, 125, 150]  # 지원하는 화면 배율
CONFIDENCE_THRESHOLD = 0.8          # 이미지 매칭 신뢰도 임계값
IMAGE_FILES = ['1.png', '2.png', '3.png', '4.png', '5.png']

# 클릭 동작 메시지 매핑
CLICK_MESSAGES = {
    '2.png': '퀴즈 버튼 클릭',
    '3.png': '확인버튼 클릭',
    '4.png': '다음 클릭',
    '5.png': '재생 클릭'
}

# --- Gemini 모델 설정 ---
# gemini-2.0-flash: 안정 버전 (한도 넉넉)
# gemini-2.5-flash: 최신 프리뷰 (한도 낮음)
GEMINI_MODEL = 'gemini-2.5-flash'
GEMINI_API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"


def validate_api_key():
    """API 키 설정 여부를 확인하고 경고 메시지 출력"""
    if not GEMINI_API_KEY:
        print("[경고] GEMINI_API_KEY 환경변수가 설정되지 않았습니다.")
        print("       AI 문제 풀이 기능을 사용하려면 환경변수를 설정하세요.")
        print("       예: set GEMINI_API_KEY=your_api_key_here")
        return False
    return True


def validate_google_credentials():
    """Google Cloud 인증 설정 여부를 확인"""
    if not GOOGLE_CREDENTIALS_PATH:
        print("[경고] GOOGLE_APPLICATION_CREDENTIALS 환경변수가 설정되지 않았습니다.")
        print("       Google Vision OCR 기능을 사용하려면 환경변수를 설정하세요.")
        return False
    if not os.path.exists(GOOGLE_CREDENTIALS_PATH):
        print(f"[경고] 인증 파일을 찾을 수 없습니다: {GOOGLE_CREDENTIALS_PATH}")
        return False
    return True


# --- 모듈 테스트 ---
if __name__ == '__main__':
    print("=== DooClick 설정 모듈 테스트 ===")
    print(f"프로젝트 루트: {PROJECT_ROOT}")
    print(f"소스 디렉토리: {SRC_DIR}")
    print(f"REF 디렉토리: {REF_DIR}")
    print()
    print("API 키 상태:")
    validate_api_key()
    print()
    print("Google Cloud 인증 상태:")
    validate_google_credentials()

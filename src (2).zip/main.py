# -*- coding: utf-8 -*-
# 파일 이름: src/main.py
# 역할: DooClick V4 메인 진입점

# === 최상단 에러 로깅 (import 실패도 캐치) ===
import sys
import os
import traceback
from datetime import datetime

def _get_crash_log_path():
    """크래시 로그 파일 경로 반환"""
    try:
        if getattr(sys, 'frozen', False) or "__compiled__" in globals():
            base = os.path.dirname(sys.executable)
        else:
            base = os.path.dirname(os.path.abspath(__file__))
            base = os.path.dirname(base)  # src → 프로젝트 루트

        log_dir = os.path.join(base, 'logs')
        os.makedirs(log_dir, exist_ok=True)
        return os.path.join(log_dir, 'crash.log')
    except:
        import tempfile
        return os.path.join(tempfile.gettempdir(), 'DooClick_crash.log')

def _crash_handler(exc_type, exc_value, exc_tb):
    """전역 예외 핸들러 - 모든 미처리 예외를 파일로 저장"""
    crash_log = _get_crash_log_path()
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    error_msg = ''.join(traceback.format_exception(exc_type, exc_value, exc_tb))

    try:
        with open(crash_log, 'a', encoding='utf-8') as f:
            f.write(f"\n{'='*60}\n")
            f.write(f"[{timestamp}] CRASH REPORT\n")
            f.write(f"{'='*60}\n")
            f.write(error_msg)
            f.write(f"\nPython: {sys.version}\n")
            f.write(f"Executable: {sys.executable}\n")
    except:
        pass  # 로그 저장 실패해도 무시

# 전역 예외 핸들러 등록
sys.excepthook = _crash_handler

# 시작 로그 기록
try:
    with open(_get_crash_log_path(), 'a', encoding='utf-8') as f:
        f.write(f"\n[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] DooClick 시작 시도\n")
except:
    pass

# === 실제 프로그램 시작 ===
import threading
from queue import Queue
import pyautogui
import active_mode
import hotkey_manager
import quiz_solver
from gui import App

# 완전 자동화 모듈
try:
    from full_automation import get_automation_manager, get_hidden_windows as get_full_auto_hidden_windows
    FULL_AUTO_AVAILABLE = True
except ImportError:
    FULL_AUTO_AVAILABLE = False
    def get_automation_manager(): return None
    def get_full_auto_hidden_windows(): return {}

# 버전 정보
from config import __version__, APP_NAME

# 편리모드 (모니터 밖 이동 방식)
try:
    from utils.virtual_desktop import get_convenience_mode, is_available as vd_available
    import win32gui
    import win32con
    CONVENIENCE_MODE_AVAILABLE = vd_available()
except ImportError:
    CONVENIENCE_MODE_AVAILABLE = False
    def get_convenience_mode(): return None

# 편리모드 - 다중 창 관리용
_convenience_hidden_windows = {}  # {hwnd: (original_x, original_y)}

# 로거 임포트
try:
    from logger import log_info, log_error, log_debug, log_warning
except ImportError:
    def log_info(msg): print(f"[INFO] {msg}")
    def log_error(msg, exc_info=False): print(f"[ERROR] {msg}")
    def log_debug(msg): print(f"[DEBUG] {msg}")
    def log_warning(msg): print(f"[WARN] {msg}")

# --- 전역 변수 ---
automation_thread = None
stop_event = threading.Event()
automation_lock = threading.Lock()  # 스레드 중복 실행 방지

quiz_thread = None
quiz_stop_event = threading.Event()


# --- 자동화 제어 함수 ---

def start_automation(app_instance):
    """자동화 시작"""
    global automation_thread, stop_event

    # Lock으로 동시 접근 방지
    if not automation_lock.acquire(blocking=False):
        app_instance.log_queue.put("[알림] 자동화 상태 변경 중입니다. 잠시 후 다시 시도하세요.")
        return

    try:
        # 이전 스레드가 아직 살아있으면 종료 대기
        if automation_thread and automation_thread.is_alive():
            if stop_event.is_set():
                app_instance.log_queue.put("[알림] 이전 자동화 종료 대기 중...")
                log_info("이전 자동화 스레드 종료 대기")
                automation_thread.join(timeout=3)
                if automation_thread.is_alive():
                    app_instance.log_queue.put("[경고] 이전 자동화가 아직 종료되지 않았습니다. 잠시 후 다시 시도하세요.")
                    log_warning("자동화 스레드 종료 타임아웃")
                    return
            else:
                app_instance.log_queue.put("[알림] 이미 자동화가 실행 중입니다.")
                log_warning("자동화 시작 요청 - 이미 실행 중")
                return

        log_info("자동화 시작")
        app_instance.update_ui_on_start()
        stop_event.clear()

        automation_thread = threading.Thread(
            target=active_mode.start_active_mode_loop,
            args=(app_instance.log_queue, stop_event),
            daemon=True
        )
        automation_thread.start()
    finally:
        automation_lock.release()


def stop_automation(app_instance):
    """자동화 중지"""
    global automation_thread

    if not automation_thread or not automation_thread.is_alive():
        app_instance.log_queue.put("[알림] 자동화가 실행 중이지 않습니다.")
        log_debug("자동화 중지 요청 - 실행 중 아님")
        return

    log_info("자동화 중지")
    stop_event.set()
    app_instance.update_ui_on_stop()

    # 백그라운드에서 스레드 종료 대기 (UI 블로킹 방지)
    def wait_for_thread():
        global automation_thread
        with automation_lock:
            if automation_thread:
                automation_thread.join(timeout=5)
                if not automation_thread.is_alive():
                    automation_thread = None  # 참조 정리

    threading.Thread(target=wait_for_thread, daemon=True).start()


# --- 퀴즈 풀이 함수 ---

def solve_quiz_manual(app_instance):
    """퀴즈 풀이 (수동 실행)"""
    global quiz_thread, quiz_stop_event

    if quiz_thread and quiz_thread.is_alive():
        app_instance.log_queue.put("[알림] 이미 퀴즈 풀이가 실행 중입니다.")
        log_warning("퀴즈 풀이 요청 - 이미 실행 중")
        return

    log_info("수동 퀴즈 풀이 시작")
    quiz_stop_event.clear()

    def run_quiz_solver():
        import time

        try:
            # 3초 카운트다운
            for i in range(3, 0, -1):
                if quiz_stop_event.is_set():
                    return
                app_instance.log_queue.put(f"{i}초 후 시작됩니다...")
                time.sleep(1)

            app_instance.log_queue.put("퀴즈 풀이 시작!")

            # 중지 확인
            if quiz_stop_event.is_set():
                return

            # 퀴즈 창 찾기 (jbstudy 또는 전북교육연수포털)
            quiz_window = None
            for title_keyword in ['jbstudy', '전북교육연수포털', '전북특별자치도교육청']:
                windows = pyautogui.getWindowsWithTitle(title_keyword)
                if windows:
                    quiz_window = windows[0]
                    break

            if not quiz_window:
                app_instance.log_queue.put("[오류] 퀴즈 창을 찾을 수 없습니다. (전북교육연수포털)")
                app_instance.update_quiz_ui_on_complete()
                return

            app_instance.log_queue.put(f"퀴즈 창 발견: {quiz_window.title[:30]}...")

            # 창 영역 설정
            search_region = (
                quiz_window.left,
                quiz_window.top,
                quiz_window.width,
                quiz_window.height
            )

            # 중지 확인
            if quiz_stop_event.is_set():
                return

            # AI 퀴즈 풀이 실행 (제출 버튼 클릭 또는 버튼 못 찾을 때까지 반복)
            # 종료 조건: is_last=True (제출 완료) 또는 success=False (버튼 못 찾음)
            solved = 0
            question_num = 0

            while True:
                question_num += 1

                # 중지 확인
                if quiz_stop_event.is_set():
                    app_instance.log_queue.put("퀴즈 풀이가 중지되었습니다.")
                    return

                app_instance.log_queue.put(f"--- 문제 {question_num} ---")
                log_info(f"[MAIN] === 문제 {question_num} 풀이 시작 ===")

                success, is_last = quiz_solver.solve_single_quiz(search_region, app_instance.log_queue)
                log_info(f"[MAIN] solve_single_quiz 결과: success={success}, is_last={is_last}")

                if success:
                    solved += 1
                    if is_last:
                        # 제출 버튼 클릭 완료 → 퀴즈 종료
                        log_info("[MAIN] >>> is_last=True, 제출 완료!")
                        app_instance.log_queue.put(f"퀴즈 완료! ({solved}문제 풀이)")
                        app_instance.log_queue.put("@@MSG_퀴즈완료@@")
                        return
                    log_info("[MAIN] 다음 문제로 진행")
                else:
                    # 다음/제출 버튼을 찾을 수 없음 → 퀴즈 종료
                    log_info("[MAIN] >>> success=False, 버튼 못 찾음!")
                    app_instance.log_queue.put(f"[중단] 다음/제출 버튼을 찾을 수 없습니다.")
                    app_instance.log_queue.put("@@MSG_버튼없음@@")
                    return

                # 다음 문제 로드 대기
                log_info("[MAIN] 다음 문제 로드 대기 (1.5초)")
                time.sleep(1.5)

        except Exception as e:
            if not quiz_stop_event.is_set():
                app_instance.log_queue.put(f"[오류] {str(e)}")
        finally:
            if not quiz_stop_event.is_set():
                app_instance.update_quiz_ui_on_complete()

    # 별도 스레드에서 실행 (UI 블로킹 방지)
    quiz_thread = threading.Thread(target=run_quiz_solver, daemon=True)
    quiz_thread.start()


def stop_quiz(app_instance):
    """퀴즈 풀이 중지"""
    global quiz_stop_event

    if not quiz_thread or not quiz_thread.is_alive():
        app_instance.log_queue.put("[알림] 퀴즈 풀이가 실행 중이지 않습니다.")
        log_debug("퀴즈 중지 요청 - 실행 중 아님")
        return

    log_info("퀴즈 풀이 중지")
    quiz_stop_event.set()
    app_instance.log_queue.put("퀴즈 풀이 중지 요청...")


# --- 편리모드 함수 ---

# 숨길 창 키워드
CONVENIENCE_KEYWORDS_CLASSROOM = ['강의실']  # 일반 자동화용 (강의실만)
CONVENIENCE_KEYWORDS_ALL = ['강의실', 'jbstudy', '전북교육연수포털', '전북특별자치도교육청', 'Chrome']  # 완전자동화용


def _hide_single_window(hwnd, log_queue=None):
    """단일 창을 화면 밖으로 숨기기"""
    global _convenience_hidden_windows
    try:
        if not win32gui.IsWindow(hwnd):
            return False
        if hwnd in _convenience_hidden_windows:
            return True  # 이미 숨김

        rect = win32gui.GetWindowRect(hwnd)
        original_pos = (rect[0], rect[1])
        width = rect[2] - rect[0]
        height = rect[3] - rect[1]

        win32gui.SetWindowPos(
            hwnd, win32con.HWND_TOP,
            0, -3000, width, height,
            win32con.SWP_NOSIZE | win32con.SWP_NOZORDER
        )
        _convenience_hidden_windows[hwnd] = original_pos
        log_debug(f"[편리모드] 창 숨김: hwnd={hwnd}")
        return True
    except Exception as e:
        log_warning(f"창 숨기기 실패: {e}")
        return False


def _show_all_convenience_windows(log_queue=None):
    """숨긴 모든 창 복귀"""
    global _convenience_hidden_windows
    for hwnd, (x, y) in list(_convenience_hidden_windows.items()):
        try:
            if win32gui.IsWindow(hwnd):
                rect = win32gui.GetWindowRect(hwnd)
                width = rect[2] - rect[0]
                height = rect[3] - rect[1]
                win32gui.SetWindowPos(
                    hwnd, win32con.HWND_TOP,
                    x, y, width, height,
                    win32con.SWP_NOSIZE | win32con.SWP_NOZORDER
                )
                log_debug(f"[편리모드] 창 복귀: hwnd={hwnd}")
        except:
            pass
    _convenience_hidden_windows.clear()
    if log_queue:
        log_queue.put("[편리모드] 모든 창 복귀됨")


def start_convenience_mode(app_instance, hide_all=False):
    """편리모드 시작

    Args:
        app_instance: App 인스턴스
        hide_all: True면 모든 관련 창 숨김 (완전자동화), False면 강의실만 (일반 자동화)
    """
    global _convenience_hidden_windows

    if not CONVENIENCE_MODE_AVAILABLE:
        app_instance.log_queue.put("[오류] 편리모드를 사용할 수 없습니다.")
        log_error("편리모드 시작 실패")
        return False

    # 모드에 따라 키워드 선택
    keywords = CONVENIENCE_KEYWORDS_ALL if hide_all else CONVENIENCE_KEYWORDS_CLASSROOM
    hidden_count = 0

    def enum_callback(hwnd, _):
        nonlocal hidden_count
        if win32gui.IsWindowVisible(hwnd):
            try:
                title = win32gui.GetWindowText(hwnd)
                for kw in keywords:
                    if kw.lower() in title.lower():
                        if _hide_single_window(hwnd, app_instance.log_queue):
                            hidden_count += 1
                        break
            except:
                pass
        return True

    win32gui.EnumWindows(enum_callback, None)

    if hidden_count == 0:
        if hide_all:
            app_instance.log_queue.put("[오류] 숨길 창을 찾을 수 없습니다. (강의실 또는 연수포털)")
        else:
            app_instance.log_queue.put("[오류] 강의실 창을 찾을 수 없습니다.")
        log_error("편리모드 시작 실패 - 관련 창 없음")
        return False

    log_info(f"편리모드 시작 - {hidden_count}개 창 숨김 (hide_all={hide_all})")
    app_instance.log_queue.put(f"편리모드 시작됨 ({hidden_count}개 창 숨김)")
    return True


def stop_convenience_mode(app_instance):
    """편리모드 종료 (모든 창 복귀)"""
    if not CONVENIENCE_MODE_AVAILABLE:
        return

    restored_count = 0

    # 1. main.py에서 숨긴 창 복귀
    if _convenience_hidden_windows:
        _show_all_convenience_windows(app_instance.log_queue)
        restored_count += 1

    # 2. full_automation.py에서 숨긴 창도 복귀
    if FULL_AUTO_AVAILABLE:
        full_auto_hidden = get_full_auto_hidden_windows()
        if full_auto_hidden:
            for hwnd, (x, y) in list(full_auto_hidden.items()):
                try:
                    if win32gui.IsWindow(hwnd):
                        rect = win32gui.GetWindowRect(hwnd)
                        width = rect[2] - rect[0]
                        height = rect[3] - rect[1]
                        win32gui.SetWindowPos(
                            hwnd, win32con.HWND_TOP,
                            x, y, width, height,
                            win32con.SWP_NOSIZE | win32con.SWP_NOZORDER
                        )
                        log_debug(f"[편리모드] full_auto 창 복귀: hwnd={hwnd}")
                        restored_count += 1
                except:
                    pass
            full_auto_hidden.clear()

    if restored_count > 0:
        log_info("편리모드 종료")
        app_instance.log_queue.put("편리모드가 종료되었습니다. (창이 복귀됨)")
    else:
        log_debug("편리모드 종료 - 숨긴 창 없음")


# --- 완전 자동화 함수 ---

def start_full_automation(app_instance, username, password, auto_next_course, url=None, use_convenience=False):
    """완전 자동화 시작"""
    if not FULL_AUTO_AVAILABLE:
        app_instance.log_queue.put("[오류] 완전 자동화 모듈을 불러올 수 없습니다.")
        log_error("완전 자동화 모듈 없음")
        return False

    manager = get_automation_manager()
    if manager is None:
        app_instance.log_queue.put("[오류] 완전 자동화 매니저 초기화 실패")
        return False

    # URL 기본값
    if not url:
        url = "https://www.jbstudy.kr"

    log_info(f"완전 자동화 시작 - 사용자: {username}, 다음강의자동: {auto_next_course}, URL: {url}, 편리모드: {use_convenience}")

    success = manager.start(
        username=username,
        password=password,
        log_queue=app_instance.log_queue,
        auto_next_course=auto_next_course,
        url=url,
        use_convenience=use_convenience
    )

    if success:
        app_instance.log_queue.put("완전 자동화가 시작되었습니다.")
    else:
        app_instance.log_queue.put("[오류] 완전 자동화 시작 실패")

    return success


def stop_full_automation(app_instance):
    """완전 자동화 중지"""
    if not FULL_AUTO_AVAILABLE:
        return

    manager = get_automation_manager()
    if manager:
        manager.stop(app_instance.log_queue)
        log_info("완전 자동화 중지")


# --- 메인 함수 ---

def main():
    """메인 함수"""
    log_info(f"=== {APP_NAME} V{__version__} 시작 ===")

    # 앱 인스턴스 생성
    app = App(start_callback=None, stop_callback=None)

    # 콜백 연결
    app.start_callback = lambda: start_automation(app)
    app.stop_callback = lambda: stop_automation(app)
    app.quiz_callback = lambda: solve_quiz_manual(app)
    app.quiz_stop_callback = lambda: stop_quiz(app)
    app.convenience_start_callback = lambda: start_convenience_mode(app, hide_all=False)  # 일반: 강의실만
    app.convenience_start_all_callback = lambda: start_convenience_mode(app, hide_all=True)  # 완전자동화: 모든 창
    app.convenience_stop_callback = lambda: stop_convenience_mode(app)
    app.full_auto_start_callback = lambda u, p, a, url, conv=False: start_full_automation(app, u, p, a, url, conv)
    app.full_auto_stop_callback = lambda: stop_full_automation(app)

    # 버튼에 콜백 연결
    app.btn_start.config(command=app.start_callback)
    app.btn_stop.config(command=app.stop_callback)

    # 편리모드 사용 불가 시 버튼 비활성화
    if not CONVENIENCE_MODE_AVAILABLE:
        app.btn_convenience.config(state="disabled")
        app.btn_full_auto_convenience.config(state="disabled")
        log_warning("편리모드 비활성화")

    # 단축키 설정 (app 인스턴스 전달로 스레드 안전 호출)
    hotkey_manager.setup_hotkeys(
        start_func=app.start_callback,
        stop_func=app.stop_callback,
        app_instance=app
    )

    # 종료 핸들러
    app.protocol("WM_DELETE_WINDOW", lambda: on_closing(app))

    # UI 메인 루프 시작
    app.mainloop()


def on_closing(app):
    """프로그램 종료 시"""
    log_info(f"=== {APP_NAME} V{__version__} 종료 ===")

    # 단축키 정리
    hotkey_manager.cleanup_hotkeys()

    # 편리모드 종료 (창 복구) - main.py의 숨긴 창
    if CONVENIENCE_MODE_AVAILABLE and _convenience_hidden_windows:
        log_info("편리모드 자동 종료 - main 숨긴 창 복귀")
        _show_all_convenience_windows()

    # full_automation의 숨긴 창도 복귀
    if FULL_AUTO_AVAILABLE:
        full_auto_hidden = get_full_auto_hidden_windows()
        if full_auto_hidden:
            log_info("편리모드 자동 종료 - full_auto 숨긴 창 복귀")
            for hwnd, (x, y) in list(full_auto_hidden.items()):
                try:
                    if win32gui.IsWindow(hwnd):
                        rect = win32gui.GetWindowRect(hwnd)
                        width = rect[2] - rect[0]
                        height = rect[3] - rect[1]
                        win32gui.SetWindowPos(
                            hwnd, win32con.HWND_TOP,
                            x, y, width, height,
                            win32con.SWP_NOSIZE | win32con.SWP_NOZORDER
                        )
                except:
                    pass
            full_auto_hidden.clear()

    stop_automation(app)
    app.destroy()


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        log_error(f"프로그램 비정상 종료: {e}", exc_info=True)
        raise
